package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PatchDao {
    @Query("SELECT * FROM patches ORDER BY patchNumber ASC, id ASC")
    fun observeAllPatches(): Flow<List<PatchEntity>>

    @Query("SELECT * FROM patches ORDER BY patchNumber ASC, id ASC")
    suspend fun getAllPatchesOnce(): List<PatchEntity>

    @Query("SELECT * FROM patches WHERE id = :id LIMIT 1")
    suspend fun getPatchById(id: Long): PatchEntity?

    @Query("SELECT COALESCE(MAX(patchNumber), 0) FROM patches")
    suspend fun getMaxPatchNumber(): Int

    @Query("SELECT COUNT(*) FROM patches")
    suspend fun getPatchCount(): Int

    @Query("SELECT contentSignature FROM patches WHERE contentSignature != ''")
    suspend fun getAllSignatures(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPatch(patch: PatchEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPatches(patches: List<PatchEntity>): List<Long>

    @Update
    suspend fun updatePatch(patch: PatchEntity)

    @Update
    suspend fun updatePatches(patches: List<PatchEntity>)

    @Query("DELETE FROM patches WHERE id = :id")
    suspend fun deletePatchById(id: Long)

    @Query("DELETE FROM patches")
    suspend fun deleteAllPatches()

    @Transaction
    suspend fun deleteAndRenumber(id: Long) {
        deletePatchById(id)
        renumberSequentially()
    }

    @Transaction
    suspend fun renumberSequentially() {
        val remaining = getAllPatchesOnce()
        val updated = remaining.mapIndexedNotNull { index, entity ->
            val targetNumber = index + 1
            if (entity.patchNumber != targetNumber) entity.copy(patchNumber = targetNumber) else null
        }
        if (updated.isNotEmpty()) {
            updatePatches(updated)
        }
    }
}
