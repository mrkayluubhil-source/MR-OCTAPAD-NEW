package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.EffectsSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.octapadDataStore: DataStore<Preferences> by preferencesDataStore(name = "octapad_prefs")

class SettingsStore(private val context: Context) {

    private object Keys {
        val ACTIVE_PATCH_ID = longPreferencesKey("active_patch_id")
        val MASTER_VOLUME = floatPreferencesKey("fx_master_volume")
        val BASS_DB = floatPreferencesKey("fx_bass_db")
        val TREBLE_DB = floatPreferencesKey("fx_treble_db")
        val MASTER_PITCH = floatPreferencesKey("fx_master_pitch")
        val ECHO_LEVEL = floatPreferencesKey("fx_echo_level")
        val DELAY_MS = intPreferencesKey("fx_delay_ms")
        val DELAY_FEEDBACK = floatPreferencesKey("fx_delay_feedback")
        val REVERB_LEVEL = floatPreferencesKey("fx_reverb_level")
        val MIDI_CHANNEL = intPreferencesKey("midi_channel")
        val MIDI_IN_ENABLED = booleanPreferencesKey("midi_in_enabled")
        val MIDI_OUT_ENABLED = booleanPreferencesKey("midi_out_enabled")
    }

    val activePatchId: Flow<Long?> = context.octapadDataStore.data.map { prefs ->
        prefs[Keys.ACTIVE_PATCH_ID]
    }

    val effectsSettings: Flow<EffectsSettings> = context.octapadDataStore.data.map { prefs ->
        EffectsSettings(
            masterVolume = prefs[Keys.MASTER_VOLUME] ?: 0.85f,
            bassDb = prefs[Keys.BASS_DB] ?: 0.0f,
            trebleDb = prefs[Keys.TREBLE_DB] ?: 0.0f,
            masterPitchSemitones = prefs[Keys.MASTER_PITCH] ?: 0.0f,
            echoLevel = prefs[Keys.ECHO_LEVEL] ?: 0.0f,
            delayMs = prefs[Keys.DELAY_MS] ?: 260,
            delayFeedback = prefs[Keys.DELAY_FEEDBACK] ?: 0.35f,
            reverbLevel = prefs[Keys.REVERB_LEVEL] ?: 0.12f,
        )
    }

    val midiPreferences: Flow<Triple<Int, Boolean, Boolean>> = context.octapadDataStore.data.map { prefs ->
        Triple(
            prefs[Keys.MIDI_CHANNEL] ?: 10,
            prefs[Keys.MIDI_IN_ENABLED] ?: true,
            prefs[Keys.MIDI_OUT_ENABLED] ?: true,
        )
    }

    suspend fun saveActivePatchId(patchId: Long) {
        context.octapadDataStore.edit { prefs ->
            prefs[Keys.ACTIVE_PATCH_ID] = patchId
        }
    }

    suspend fun saveEffects(effects: EffectsSettings) {
        context.octapadDataStore.edit { prefs ->
            prefs[Keys.MASTER_VOLUME] = effects.masterVolume
            prefs[Keys.BASS_DB] = effects.bassDb
            prefs[Keys.TREBLE_DB] = effects.trebleDb
            prefs[Keys.MASTER_PITCH] = effects.masterPitchSemitones
            prefs[Keys.ECHO_LEVEL] = effects.echoLevel
            prefs[Keys.DELAY_MS] = effects.delayMs
            prefs[Keys.DELAY_FEEDBACK] = effects.delayFeedback
            prefs[Keys.REVERB_LEVEL] = effects.reverbLevel
        }
    }

    suspend fun saveMidiPreferences(channel: Int, inputEnabled: Boolean, outputEnabled: Boolean) {
        context.octapadDataStore.edit { prefs ->
            prefs[Keys.MIDI_CHANNEL] = channel.coerceIn(0, 16)
            prefs[Keys.MIDI_IN_ENABLED] = inputEnabled
            prefs[Keys.MIDI_OUT_ENABLED] = outputEnabled
        }
    }
}
