package com.example.data

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.util.Locale

class StorageManager(private val context: Context) {

    val samplesRootDir: File
        get() = File(context.filesDir, "samples").apply { mkdirs() }

    val stagingRootDir: File
        get() = File(context.filesDir, "import_staging").apply { mkdirs() }

    val spd30PreservedRootDir: File
        get() = File(context.filesDir, "spd30_preserved").apply { mkdirs() }

    fun getAvailableBytes(): Long {
        return try {
            val stat = StatFs(context.filesDir.absolutePath)
            stat.availableBytes
        } catch (_: Exception) {
            0L
        }
    }

    fun hasSufficientStorage(requiredBytes: Long, safetyMarginBytes: Long = MIN_FREE_MARGIN_BYTES): Boolean {
        val available = getAvailableBytes()
        if (available <= 0L) return true // Fallback if StatFs unavailable in test environment
        return available > (requiredBytes + safetyMarginBytes)
    }

    fun createBatchStagingDir(batchId: String): File {
        val safeBatch = sanitizeSegment(batchId)
        return File(stagingRootDir, safeBatch).apply { mkdirs() }
    }

    fun createBatchSampleDir(batchId: String): File {
        val safeBatch = sanitizeSegment(batchId)
        return File(samplesRootDir, safeBatch).apply { mkdirs() }
    }

    fun createSpd30PreservedDir(batchId: String): File {
        val safeBatch = sanitizeSegment(batchId)
        return File(spd30PreservedRootDir, safeBatch).apply { mkdirs() }
    }

    /**
     * Validates that a ZIP entry path resolves strictly inside [targetDir] to prevent Zip Slip attacks.
     */
    fun resolveSafeChildFile(targetDir: File, relativeEntryPath: String): File? {
        val normalized = relativeEntryPath.replace('\\', '/').trimStart('/')
        if (normalized.isBlank()) return null
        val candidate = File(targetDir, normalized)
        val canonicalRoot = targetDir.canonicalPath
        val canonicalTarget = candidate.canonicalPath
        if (canonicalTarget != canonicalRoot && !canonicalTarget.startsWith(canonicalRoot + File.separator)) {
            return null
        }
        return candidate
    }

    /**
     * Copies a SAF content URI stream into persistent app-private storage so we never rely on temporary URI permissions.
     */
    fun persistUriSample(uri: Uri, preferredDisplayName: String? = null): Result<File> {
        return runCatching {
            val displayName = (preferredDisplayName ?: queryDisplayName(uri) ?: "sample_${System.currentTimeMillis()}.wav")
            val sanitizedName = sanitizeFilename(displayName)
            val destDir = createBatchSampleDir("user_samples")
            val destFile = uniqueFile(destDir, sanitizedName)

            val uriSize = queryFileSize(uri)
            if (uriSize > 0L && !hasSufficientStorage(uriSize)) {
                val availMb = getAvailableBytes() / (1024 * 1024)
                val reqMb = (uriSize / (1024 * 1024)).coerceAtLeast(1)
                error("Insufficient device storage: ${availMb}MB free, requires ${reqMb}MB.")
            }

            val input = context.contentResolver.openInputStream(uri)
                ?: error("Unable to open selected audio file.")
            input.use { stream ->
                copyStreamWithStorageGuard(stream, destFile)
            }
            destFile
        }
    }

    fun copyStreamWithStorageGuard(input: InputStream, destination: File): Long {
        destination.parentFile?.mkdirs()
        var totalWritten = 0L
        var lastCheck = 0L
        val buffer = ByteArray(8192)
        FileOutputStream(destination).use { out ->
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                totalWritten += read
                if (totalWritten - lastCheck >= STORAGE_CHECK_INTERVAL_BYTES) {
                    lastCheck = totalWritten
                    if (!hasSufficientStorage(0L, MIN_FREE_MARGIN_BYTES)) {
                        error("Insufficient storage remaining while importing files.")
                    }
                }
                out.write(buffer, 0, read)
            }
            out.flush()
        }
        return totalWritten
    }

    fun persistStagingSample(stagedFile: File, batchSampleDir: File, relativeHint: String): File {
        val cleanRel = relativeHint.replace('\\', '/').trimStart('/')
            .split('/')
            .filter { it.isNotBlank() && it != "." && it != ".." }
            .joinToString("/") { sanitizeFilename(it) }
            .ifBlank { sanitizeFilename(stagedFile.name) }

        val target = resolveSafeChildFile(batchSampleDir, cleanRel)
            ?: uniqueFile(batchSampleDir, sanitizeFilename(stagedFile.name))
        target.parentFile?.mkdirs()
        if (stagedFile.canonicalPath == target.canonicalPath) return target

        val finalTarget = if (target.exists() && target.length() == stagedFile.length()) {
            target
        } else if (target.exists()) {
            uniqueFile(target.parentFile ?: batchSampleDir, target.name)
        } else {
            target
        }

        if (!stagedFile.renameTo(finalTarget)) {
            stagedFile.inputStream().use { input ->
                copyStreamWithStorageGuard(input, finalTarget)
            }
            stagedFile.delete()
        }
        return finalTarget
    }

    fun cleanupStagingDir(dir: File) {
        runCatching {
            if (dir.exists()) {
                dir.deleteRecursively()
            }
        }
    }

    fun cleanupOrphanedSamples(referencedPaths: Set<String>) {
        runCatching {
            val normalizedReferenced = referencedPaths.map { File(it).canonicalPath }.toSet()
            samplesRootDir.walkTopDown()
                .filter { it.isFile }
                .forEach { file ->
                    if (file.canonicalPath !in normalizedReferenced) {
                        file.delete()
                    }
                }
        }
    }

    fun queryDisplayName(uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        } catch (_: Exception) {
            null
        } ?: uri.lastPathSegment?.substringAfterLast('/')
    }

    fun queryFileSize(uri: Uri): Long {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (idx >= 0 && !cursor.isNull(idx)) cursor.getLong(idx) else -1L
                } else -1L
            } ?: -1L
        } catch (_: Exception) {
            -1L
        }
    }

    fun sha256Short(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
        return digest.take(8).joinToString("") { "%02x".format(Locale.US, it) }
    }

    private fun uniqueFile(dir: File, filename: String): File {
        var candidate = File(dir, filename)
        if (!candidate.exists()) return candidate
        val dot = filename.lastIndexOf('.')
        val stem = if (dot > 0) filename.substring(0, dot) else filename
        val ext = if (dot > 0) filename.substring(dot) else ""
        var counter = 1
        while (candidate.exists()) {
            candidate = File(dir, "${stem}_$counter$ext")
            counter++
        }
        return candidate
    }

    private fun sanitizeSegment(input: String): String {
        return input.replace(Regex("[^a-zA-Z0-9._-]"), "_").ifBlank { "batch" }
    }

    private fun sanitizeFilename(name: String): String {
        return name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "file.bin" }
    }

    companion object {
        private const val MIN_FREE_MARGIN_BYTES = 16L * 1024L * 1024L // 16 MB safety floor
        private const val STORAGE_CHECK_INTERVAL_BYTES = 4L * 1024L * 1024L
    }
}
