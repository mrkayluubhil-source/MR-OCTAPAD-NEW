package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.OctapadRecording

@Entity(tableName = "recordings")
data class RecordingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val patchId: Long,
    val patchName: String,
    val eventsJson: String,
    val durationMs: Long,
    val createdAt: Long,
    val isLooping: Boolean,
) {
    fun toDomain(): OctapadRecording = OctapadRecording(
        id = id,
        name = name,
        patchId = patchId,
        patchName = patchName,
        events = PatchSerializer.eventsFromJson(eventsJson),
        durationMs = durationMs,
        createdAt = createdAt,
        isLooping = isLooping,
    )

    companion object {
        fun fromDomain(rec: OctapadRecording): RecordingEntity = RecordingEntity(
            id = rec.id,
            name = rec.name,
            patchId = rec.patchId,
            patchName = rec.patchName,
            eventsJson = PatchSerializer.eventsToJson(rec.events),
            durationMs = rec.durationMs,
            createdAt = rec.createdAt,
            isLooping = rec.isLooping,
        )
    }
}
