package com.example.data

import com.example.model.EffectsSettings
import com.example.model.PadAssignment
import com.example.model.RecordedEvent
import org.json.JSONArray
import org.json.JSONObject

object PatchSerializer {

    fun padsToJson(pads: List<PadAssignment>): String {
        val arr = JSONArray()
        for (i in 0 until 8) {
            val pad = pads.getOrNull(i) ?: PadAssignment(padIndex = i)
            val obj = JSONObject().apply {
                put("padIndex", i)
                put("samplePath", pad.samplePath ?: JSONObject.NULL)
                put("sampleName", pad.sampleName)
                put("volume", pad.volume.toDouble())
                put("pitchSemitones", pad.pitchSemitones.toDouble())
                put("midiNote", pad.midiNote)
                put("pan", pad.pan.toDouble())
            }
            arr.put(obj)
        }
        return arr.toString()
    }

    fun padsFromJson(json: String): List<PadAssignment> {
        val result = MutableList(8) { idx -> PadAssignment(padIndex = idx) }
        return try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val padIndex = obj.optInt("padIndex", i).coerceIn(0, 7)
                val rawPath = if (obj.isNull("samplePath")) null else obj.optString("samplePath", "").ifBlank { null }
                result[padIndex] = PadAssignment(
                    padIndex = padIndex,
                    samplePath = rawPath,
                    sampleName = obj.optString("sampleName", ""),
                    volume = obj.optDouble("volume", 1.0).toFloat().coerceIn(0f, 1.5f),
                    pitchSemitones = obj.optDouble("pitchSemitones", 0.0).toFloat().coerceIn(-12f, 12f),
                    midiNote = obj.optInt("midiNote", PadAssignment.defaultMidiNoteForPad(padIndex)).coerceIn(0, 127),
                    pan = obj.optDouble("pan", 0.0).toFloat().coerceIn(-1f, 1f),
                )
            }
            result
        } catch (_: Exception) {
            result
        }
    }

    fun effectsToJson(effects: EffectsSettings): String {
        return JSONObject().apply {
            put("masterVolume", effects.masterVolume.toDouble())
            put("bassDb", effects.bassDb.toDouble())
            put("trebleDb", effects.trebleDb.toDouble())
            put("masterPitchSemitones", effects.masterPitchSemitones.toDouble())
            put("echoLevel", effects.echoLevel.toDouble())
            put("delayMs", effects.delayMs)
            put("delayFeedback", effects.delayFeedback.toDouble())
            put("reverbLevel", effects.reverbLevel.toDouble())
        }.toString()
    }

    fun effectsFromJson(json: String): EffectsSettings {
        return try {
            val obj = JSONObject(json)
            EffectsSettings(
                masterVolume = obj.optDouble("masterVolume", 0.85).toFloat().coerceIn(0f, 1f),
                bassDb = obj.optDouble("bassDb", 0.0).toFloat().coerceIn(-12f, 12f),
                trebleDb = obj.optDouble("trebleDb", 0.0).toFloat().coerceIn(-12f, 12f),
                masterPitchSemitones = obj.optDouble("masterPitchSemitones", 0.0).toFloat().coerceIn(-12f, 12f),
                echoLevel = obj.optDouble("echoLevel", 0.0).toFloat().coerceIn(0f, 1f),
                delayMs = obj.optInt("delayMs", 260).coerceIn(40, 800),
                delayFeedback = obj.optDouble("delayFeedback", 0.35).toFloat().coerceIn(0f, 0.75f),
                reverbLevel = obj.optDouble("reverbLevel", 0.12).toFloat().coerceIn(0f, 1f),
            )
        } catch (_: Exception) {
            EffectsSettings()
        }
    }

    fun eventsToJson(events: List<RecordedEvent>): String {
        val arr = JSONArray()
        for (event in events) {
            arr.put(
                JSONObject().apply {
                    put("padIndex", event.padIndex)
                    put("timestampMs", event.timestampMs)
                    put("velocity", event.velocity.toDouble())
                    put("midiNote", event.midiNote)
                }
            )
        }
        return arr.toString()
    }

    fun eventsFromJson(json: String): List<RecordedEvent> {
        return try {
            val arr = JSONArray(json)
            buildList(arr.length()) {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(
                        RecordedEvent(
                            padIndex = obj.optInt("padIndex", 0).coerceIn(0, 7),
                            timestampMs = obj.optLong("timestampMs", 0L).coerceAtLeast(0L),
                            velocity = obj.optDouble("velocity", 1.0).toFloat().coerceIn(0.05f, 1.0f),
                            midiNote = obj.optInt("midiNote", 36).coerceIn(0, 127),
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
