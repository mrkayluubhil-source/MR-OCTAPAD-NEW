package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [PatchEntity::class, RecordingEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class OctapadDatabase : RoomDatabase() {
    abstract fun patchDao(): PatchDao
    abstract fun recordingDao(): RecordingDao

    companion object {
        @Volatile
        private var instance: OctapadDatabase? = null

        fun getInstance(context: Context): OctapadDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    OctapadDatabase::class.java,
                    "mr_octapad_library.db",
                ).build().also { instance = it }
            }
        }
    }
}
