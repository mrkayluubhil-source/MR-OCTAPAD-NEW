package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.OctapadPatch
import com.example.model.PatchSourceType

@Entity(tableName = "patches")
data class PatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val patchNumber: Int,
    val name: String,
    val sourceType: String,
    val sourceFolder: String,
    val contentSignature: String,
    val padsJson: String,
    val effectsJson: String,
    val createdAt: Long,
    val updatedAt: Long,
    val isCustomEdited: Boolean,
) {
    fun toDomain(): OctapadPatch = OctapadPatch(
        id = id,
        patchNumber = patchNumber,
        name = name,
        sourceType = runCatching { PatchSourceType.valueOf(sourceType) }.getOrDefault(PatchSourceType.USER_CUSTOM),
        sourceFolder = sourceFolder,
        pads = PatchSerializer.padsFromJson(padsJson),
        effects = PatchSerializer.effectsFromJson(effectsJson),
        createdAt = createdAt,
        updatedAt = updatedAt,
        isCustomEdited = isCustomEdited,
    )

    companion object {
        fun fromDomain(patch: OctapadPatch, signature: String = ""): PatchEntity = PatchEntity(
            id = patch.id,
            patchNumber = patch.patchNumber,
            name = patch.name,
            sourceType = patch.sourceType.name,
            sourceFolder = patch.sourceFolder,
            contentSignature = signature,
            padsJson = PatchSerializer.padsToJson(patch.pads),
            effectsJson = PatchSerializer.effectsToJson(patch.effects),
            createdAt = patch.createdAt,
            updatedAt = patch.updatedAt,
            isCustomEdited = patch.isCustomEdited,
        )
    }
}
