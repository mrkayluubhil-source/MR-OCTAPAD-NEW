package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RecordingDao {
    @Query("SELECT * FROM recordings ORDER BY createdAt DESC")
    fun observeRecordings(): Flow<List<RecordingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecording(entity: RecordingEntity): Long

    @Update
    suspend fun updateRecording(entity: RecordingEntity)

    @Query("UPDATE recordings SET name = :newName WHERE id = :id")
    suspend fun renameRecording(id: Long, newName: String)

    @Query("UPDATE recordings SET isLooping = :looping WHERE id = :id")
    suspend fun updateLooping(id: Long, looping: Boolean)

    @Query("DELETE FROM recordings WHERE id = :id")
    suspend fun deleteRecording(id: Long)
}
