package com.example.importer

import com.example.model.PadAssignment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class McnParseResult(
    val patchName: String,
    val sourceFolder: String,
    val padAssignments: List<PadAssignment>,
    val missingSamples: List<String>,
)

/**
 * Parses .mcn folders and machine.cfg files across INI, JSON, colon-delimited, and positional formats.
 * Accurately matches sample references to extracted audio files and reports missing samples without inventing data.
 */
class McnPatchParser {

    fun parseMachineConfig(
        cfgFile: File,
        stagingRoot: File,
        audioLookup: AudioArchiveIndex,
    ): McnParseResult {
        val rawText = runCatching { cfgFile.readText(Charsets.UTF_8) }.getOrDefault("")
        val cfgDir = cfgFile.parentFile ?: stagingRoot
        val relFolder = cfgDir.relativeToOrSelf(stagingRoot).path.replace('\\', '/')
        val enclosingMcnName = findEnclosingMcnName(cfgDir, stagingRoot)
        val defaultName = buildDefaultPatchName(cfgDir, enclosingMcnName, stagingRoot)

        val trimmed = rawText.trim()
        if (trimmed.startsWith("{")) {
            parseJsonConfig(trimmed, defaultName, relFolder, cfgDir, audioLookup)?.let { return it }
        }

        return parseIniOrLineConfig(rawText, defaultName, relFolder, cfgDir, audioLookup)
    }

    fun buildPatchFromMcnFolder(
        folder: File,
        stagingRoot: File,
        audioFilesInFolder: List<File>,
        audioLookup: AudioArchiveIndex,
    ): McnParseResult {
        val relFolder = folder.relativeToOrSelf(stagingRoot).path.replace('\\', '/')
        val patchName = normalizeFolderName(folder.name)
        val pads = MutableList(8) { PadAssignment(padIndex = it) }
        val sortedAudio = audioFilesInFolder.sortedBy { it.name.lowercase() }
        for (i in 0 until minOf(8, sortedAudio.size)) {
            val file = sortedAudio[i]
            pads[i] = PadAssignment(
                padIndex = i,
                samplePath = file.absolutePath,
                sampleName = file.nameWithoutExtension,
            )
        }
        return McnParseResult(
            patchName = patchName,
            sourceFolder = relFolder,
            padAssignments = pads,
            missingSamples = emptyList(),
        )
    }

    private fun parseJsonConfig(
        jsonText: String,
        defaultName: String,
        relFolder: String,
        cfgDir: File,
        audioLookup: AudioArchiveIndex,
    ): McnParseResult? {
        return try {
            val obj = JSONObject(jsonText)
            val patchName = (obj.optString("name")
                .ifBlank { obj.optString("patchName") }
                .ifBlank { obj.optString("title") }
                .ifBlank { defaultName }).trim()

            val pads = MutableList(8) { PadAssignment(padIndex = it) }
            val missing = mutableListOf<String>()

            val array = obj.optJSONArray("pads") ?: obj.optJSONArray("samples") ?: obj.optJSONArray("channels")
            if (array != null) {
                for (i in 0 until minOf(8, array.length())) {
                    val elem = array.opt(i)
                    when (elem) {
                        is JSONObject -> {
                            val padIdx = resolvePadIndex(elem.optInt("pad", elem.optInt("index", i)), i)
                            val sampleRef = elem.optString("sample")
                                .ifBlank { elem.optString("file") }
                                .ifBlank { elem.optString("path") }
                                .ifBlank { elem.optString("wav") }
                                .ifBlank { elem.optString("sound") }
                            val vol = elem.optDouble("volume", elem.optDouble("gain", 1.0)).toFloat().coerceIn(0f, 1.5f)
                            val pitch = elem.optDouble("pitch", 0.0).toFloat().coerceIn(-12f, 12f)
                            val midi = elem.optInt("midiNote", elem.optInt("midi", PadAssignment.defaultMidiNoteForPad(padIdx))).coerceIn(0, 127)
                            assignResolvedSample(pads, padIdx, sampleRef, vol, pitch, midi, cfgDir, audioLookup, missing)
                        }
                        is String -> {
                            assignResolvedSample(pads, i, elem, 1.0f, 0f, PadAssignment.defaultMidiNoteForPad(i), cfgDir, audioLookup, missing)
                        }
                    }
                }
            } else {
                // Check flat keys pad1..pad8 or 1..8
                for (i in 0 until 8) {
                    val ref = findFlatJsonPadRef(obj, i)
                    if (!ref.isNullOrBlank()) {
                        assignResolvedSample(pads, i, ref, 1.0f, 0f, PadAssignment.defaultMidiNoteForPad(i), cfgDir, audioLookup, missing)
                    }
                }
            }

            fillRemainingFromFolderIfNeeded(pads, cfgDir)
            McnParseResult(patchName, relFolder, pads, missing.distinct())
        } catch (_: Exception) {
            null
        }
    }

    private fun parseIniOrLineConfig(
        rawText: String,
        defaultName: String,
        relFolder: String,
        cfgDir: File,
        audioLookup: AudioArchiveIndex,
    ): McnParseResult {
        var patchName = defaultName
        val pads = MutableList(8) { PadAssignment(padIndex = it) }
        val missing = mutableListOf<String>()
        var currentSectionPad: Int? = null
        var positionalIdx = 0

        val lines = rawText.lines()
        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("#") || line.startsWith(";") || line.startsWith("//")) continue

            // [Section] header e.g. [Pad 1], [PAD1], [Pad_0], [Bank1]
            if (line.startsWith("[") && line.endsWith("]")) {
                val sectionName = line.substring(1, line.length - 1).trim()
                currentSectionPad = parseSectionPadNumber(sectionName)
                continue
            }

            // Key = Value or Key : Value
            val sepIdx = when {
                line.contains('=') -> line.indexOf('=')
                line.contains(':') && !line.contains(":\\") -> line.indexOf(':')
                else -> -1
            }

            if (sepIdx > 0) {
                val key = line.substring(0, sepIdx).trim().lowercase()
                val value = line.substring(sepIdx + 1).trim().trim('"', '\'')
                if (value.isEmpty()) continue

                if (key in listOf("name", "patch", "patch_name", "patchname", "kit", "kit_name", "title") && currentSectionPad == null) {
                    patchName = value
                    continue
                }

                // Determine target pad from either key (pad1, sample2, sound_3, ch4) or active [Section]
                val keyPadIdx = parsePadIndexFromKey(key) ?: currentSectionPad
                if (keyPadIdx != null && keyPadIdx in 0..7) {
                    val existing = pads[keyPadIdx]
                    when {
                        key.contains("vol") || key.contains("gain") || key.contains("level") -> {
                            val parsedVol = parseVolume(value)
                            pads[keyPadIdx] = existing.copy(volume = parsedVol)
                        }
                        key.contains("pitch") || key.contains("tune") -> {
                            val parsedPitch = value.toFloatOrNull()?.coerceIn(-12f, 12f) ?: existing.pitchSemitones
                            pads[keyPadIdx] = existing.copy(pitchSemitones = parsedPitch)
                        }
                        key.contains("midi") || key.contains("note") -> {
                            val parsedMidi = value.toIntOrNull()?.coerceIn(0, 127) ?: existing.midiNote
                            pads[keyPadIdx] = existing.copy(midiNote = parsedMidi)
                        }
                        looksLikeAudioReference(value) || key.contains("sample") || key.contains("sound") ||
                            key.contains("file") || key.contains("wav") || key.contains("mp3") ||
                            key.contains("path") || key.startsWith("pad") -> {
                            assignResolvedSample(
                                pads, keyPadIdx, value,
                                existing.volume, existing.pitchSemitones, existing.midiNote,
                                cfgDir, audioLookup, missing
                            )
                        }
                    }
                    continue
                }

                // Fallback: if value itself is an audio filename even with an unrecognized key
                if (looksLikeAudioReference(value) && positionalIdx < 8) {
                    while (positionalIdx < 8 && pads[positionalIdx].hasSample) positionalIdx++
                    if (positionalIdx < 8) {
                        assignResolvedSample(
                            pads, positionalIdx, value, 1.0f, 0f,
                            PadAssignment.defaultMidiNoteForPad(positionalIdx),
                            cfgDir, audioLookup, missing
                        )
                        positionalIdx++
                    }
                }
            } else {
                // Pipe/comma separated or raw audio line
                val parts = line.split('|', ';').map { it.trim() }
                val audioToken = parts.firstOrNull { looksLikeAudioReference(it) }
                if (audioToken != null) {
                    val explicitIdx = parts.firstOrNull()?.toIntOrNull()?.let { n ->
                        if (n in 1..8) n - 1 else if (n in 0..7) n else null
                    }
                    val targetIdx = explicitIdx ?: run {
                        while (positionalIdx < 8 && pads[positionalIdx].hasSample) positionalIdx++
                        positionalIdx
                    }
                    if (targetIdx in 0..7) {
                        assignResolvedSample(
                            pads, targetIdx, audioToken, 1.0f, 0f,
                            PadAssignment.defaultMidiNoteForPad(targetIdx),
                            cfgDir, audioLookup, missing
                        )
                        if (explicitIdx == null) positionalIdx++
                    }
                }
            }
        }

        // If machine.cfg had fewer than 8 explicit references, auto-fill any unassigned pads from audio files in the same folder
        fillRemainingFromFolderIfNeeded(pads, cfgDir)

        return McnParseResult(
            patchName = patchName,
            sourceFolder = relFolder,
            padAssignments = pads,
            missingSamples = missing.distinct(),
        )
    }

    private fun assignResolvedSample(
        pads: MutableList<PadAssignment>,
        padIdx: Int,
        rawRef: String,
        volume: Float,
        pitch: Float,
        midiNote: Int,
        cfgDir: File,
        audioLookup: AudioArchiveIndex,
        missing: MutableList<String>,
    ) {
        val cleanRef = rawRef.trim().trim('"', '\'')
        if (cleanRef.isEmpty() || cleanRef.equals("none", ignoreCase = true) || cleanRef.equals("null", ignoreCase = true)) {
            return
        }
        val resolvedFile = audioLookup.resolveSample(cleanRef, cfgDir)
        if (resolvedFile != null) {
            pads[padIdx] = PadAssignment(
                padIndex = padIdx,
                samplePath = resolvedFile.absolutePath,
                sampleName = resolvedFile.nameWithoutExtension,
                volume = volume,
                pitchSemitones = pitch,
                midiNote = midiNote,
            )
        } else if (looksLikeAudioReference(cleanRef)) {
            missing.add("${cfgDir.name}/$cleanRef")
        }
    }

    private fun fillRemainingFromFolderIfNeeded(pads: MutableList<PadAssignment>, cfgDir: File) {
        val alreadyMappedPaths = pads.mapNotNull { it.samplePath }.toSet()
        val folderAudio = cfgDir.listFiles()
            ?.filter { it.isFile && isSupportedAudioFilename(it.name) && it.absolutePath !in alreadyMappedPaths }
            ?.sortedBy { it.name.lowercase() }
            ?: return

        var audioCursor = 0
        for (i in 0 until 8) {
            if (!pads[i].hasSample && audioCursor < folderAudio.size) {
                val file = folderAudio[audioCursor++]
                pads[i] = pads[i].copy(
                    samplePath = file.absolutePath,
                    sampleName = file.nameWithoutExtension,
                )
            }
        }
    }

    private fun findEnclosingMcnName(dir: File, stagingRoot: File): String? {
        var cur: File? = dir
        val rootPath = stagingRoot.canonicalPath
        while (cur != null && cur.canonicalPath.startsWith(rootPath)) {
            if (cur.name.endsWith(".mcn", ignoreCase = true)) {
                return normalizeFolderName(cur.name)
            }
            if (cur.canonicalPath == rootPath) break
            cur = cur.parentFile
        }
        return null
    }

    private fun buildDefaultPatchName(cfgDir: File, enclosingMcnName: String?, stagingRoot: File): String {
        val dirName = normalizeFolderName(cfgDir.name)
        return when {
            enclosingMcnName != null && cfgDir.name.endsWith(".mcn", ignoreCase = true) -> enclosingMcnName
            enclosingMcnName != null && dirName.isNotBlank() && !dirName.equals(enclosingMcnName, ignoreCase = true) ->
                "$enclosingMcnName - $dirName"
            enclosingMcnName != null -> enclosingMcnName
            cfgDir.canonicalPath != stagingRoot.canonicalPath -> dirName.ifBlank { "Imported Patch" }
            else -> "Imported Patch"
        }
    }

    private fun normalizeFolderName(name: String): String {
        return name.removeSuffix(".mcn").removeSuffix(".MCN").replace('_', ' ').trim().ifBlank { name }
    }

    private fun parseSectionPadNumber(sectionName: String): Int? {
        val match = Regex("(?:pad|slot|ch|channel|drum)[\\s_-]*(\\d+)", RegexOption.IGNORE_CASE).find(sectionName)
            ?: return null
        val num = match.groupValues[1].toIntOrNull() ?: return null
        return when {
            num in 1..8 -> num - 1
            num in 0..7 -> num
            else -> null
        }
    }

    private fun parsePadIndexFromKey(key: String): Int? {
        val match = Regex("(?:pad|sample|sound|wav|mp3|slot|ch|drum|vol|volume|pitch|midi|note)[\\s_-]*(\\d+)").find(key)
            ?: Regex("^(\\d+)$").find(key)
            ?: return null
        val num = match.groupValues[1].toIntOrNull() ?: return null
        return when {
            num in 1..8 -> num - 1
            num == 0 -> 0
            else -> null
        }
    }

    private fun resolvePadIndex(raw: Int, fallback: Int): Int {
        return when {
            raw in 0..7 -> raw
            raw == 8 -> 7
            else -> fallback.coerceIn(0, 7)
        }
    }

    private fun findFlatJsonPadRef(obj: JSONObject, idx: Int): String? {
        val keys = listOf("pad${idx + 1}", "pad_${idx + 1}", "sample${idx + 1}", "pad$idx", "${idx + 1}")
        for (k in keys) {
            val v = obj.optString(k, "")
            if (v.isNotBlank()) return v
        }
        return null
    }

    private fun parseVolume(raw: String): Float {
        val num = raw.toFloatOrNull() ?: return 1.0f
        return when {
            num > 1.5f -> (num / 100f).coerceIn(0f, 1.5f)
            else -> num.coerceIn(0f, 1.5f)
        }
    }

    companion object {
        private val AUDIO_EXTS = setOf("wav", "wave", "mp3", "ogg", "oga", "aac", "m4a", "flac")

        fun isSupportedAudioFilename(name: String): Boolean {
            val ext = name.substringAfterLast('.', "").lowercase()
            return ext in AUDIO_EXTS
        }

        fun looksLikeAudioReference(value: String): Boolean {
            val ext = value.substringAfterLast('.', "").lowercase()
            return ext in AUDIO_EXTS
        }
    }
}

/**
 * Fast multi-level audio sample lookup index across an extracted staging directory.
 */
class AudioArchiveIndex(private val stagingRoot: File, allAudioFiles: List<File>) {
    private val byRelativeLower = HashMap<String, File>(allAudioFiles.size)
    private val byFilenameLower = HashMap<String, MutableList<File>>(allAudioFiles.size)
    private val byStemLower = HashMap<String, MutableList<File>>(allAudioFiles.size)

    init {
        for (file in allAudioFiles) {
            val rel = file.relativeToOrSelf(stagingRoot).path.replace('\\', '/').lowercase()
            byRelativeLower[rel] = file
            val fname = file.name.lowercase()
            byFilenameLower.getOrPut(fname) { mutableListOf() }.add(file)
            val stem = file.nameWithoutExtension.lowercase()
            byStemLower.getOrPut(stem) { mutableListOf() }.add(file)
        }
    }

    fun resolveSample(reference: String, preferredDir: File): File? {
        val normalized = reference.replace('\\', '/').trim().trimStart('/')
        if (normalized.isEmpty()) return null

        // 1. Direct relative path from preferredDir
        val direct = File(preferredDir, normalized)
        if (direct.exists() && direct.isFile) return direct

        // Case-insensitive match inside preferredDir
        val justFilename = normalized.substringAfterLast('/')
        preferredDir.listFiles()?.firstOrNull {
            it.isFile && it.name.equals(justFilename, ignoreCase = true)
        }?.let { return it }

        // 2. Relative path from stagingRoot
        byRelativeLower[normalized.lowercase()]?.let { return it }

        // 3. Search inside preferredDir subtree or parent .mcn subtree
        val filenameCandidates = byFilenameLower[justFilename.lowercase()]
        if (!filenameCandidates.isNullOrEmpty()) {
            val prefPath = preferredDir.canonicalPath
            filenameCandidates.firstOrNull { it.canonicalPath.startsWith(prefPath) }?.let { return it }
            filenameCandidates.firstOrNull {
                val parent = preferredDir.parentFile?.canonicalPath ?: prefPath
                it.canonicalPath.startsWith(parent)
            }?.let { return it }
            return filenameCandidates.first()
        }

        // 4. Stem fallback
        val stem = justFilename.substringBeforeLast('.').lowercase()
        val stemCandidates = byStemLower[stem]
        if (!stemCandidates.isNullOrEmpty()) {
            val prefPath = preferredDir.canonicalPath
            return stemCandidates.firstOrNull { it.canonicalPath.startsWith(prefPath) } ?: stemCandidates.first()
        }

        return null
    }
}
