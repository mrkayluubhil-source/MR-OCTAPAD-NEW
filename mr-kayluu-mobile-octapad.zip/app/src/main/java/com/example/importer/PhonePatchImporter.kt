package com.example.importer

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.example.data.StorageManager
import com.example.model.ImportProgress
import com.example.model.OctapadPatch
import com.example.model.PadAssignment
import com.example.model.PatchSourceType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipException
import java.util.zip.ZipInputStream

/**
 * Streaming, unbounded importer supporting:
 *  - Large ZIP archives (e.g. New Ton 2026.zip with 1,341+ entries, 39 .mcn folders, 106 machine.cfg, 942 WAV, 29 MP3)
 *  - .MCN & machine.cfg folder trees via SAF OpenDocumentTree
 *  - Multi-file WAV / MP3 / OGG audio imports
 *  - JSON patch/collection imports
 *  - Genuine Roland SPD-30 BACKUP & KIT imports
 */
class PhonePatchImporter(
    private val context: Context,
    private val storageManager: StorageManager,
    private val patchManager: PatchManager,
    private val kitManager: KitManager,
    private val mcnParser: McnPatchParser = McnPatchParser(),
    private val spd30Importer: Spd30BackupImporter = Spd30BackupImporter(storageManager, kitManager),
) {
    private val _progress = MutableStateFlow(ImportProgress())
    val progress: StateFlow<ImportProgress> = _progress.asStateFlow()

    fun resetProgress() {
        _progress.value = ImportProgress()
    }

    /**
     * Checks whether a bundled asset (e.g. New Ton 2026.zip) exists in APK assets and imports it once on first launch.
     */
    suspend fun importBundledArchiveIfPresent(): Boolean {
        val assetNames = runCatching { context.assets.list("")?.toList().orEmpty() }.getOrDefault(emptyList())
        val targetAsset = assetNames.firstOrNull {
            it.equals("New Ton 2026.zip", ignoreCase = true) || it.endsWith(".zip", ignoreCase = true)
        } ?: return false

        return try {
            context.assets.open(targetAsset).use { stream ->
                importZipStream(stream, targetAsset)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun importZipUri(uri: Uri) = withContext(Dispatchers.IO) {
        val displayName = storageManager.queryDisplayName(uri) ?: "archive.zip"
        val fileSize = storageManager.queryFileSize(uri)
        if (fileSize > 0L && !storageManager.hasSufficientStorage(fileSize)) {
            val availMb = storageManager.getAvailableBytes() / (1024 * 1024)
            val reqMb = (fileSize / (1024 * 1024)).coerceAtLeast(1)
            _progress.value = ImportProgress(
                isImporting = false,
                stage = "Storage check failed",
                errorMessage = "Insufficient storage: ${availMb}MB available, archive requires at least ${reqMb}MB.",
                isCompleted = true,
            )
            return@withContext
        }

        val input = context.contentResolver.openInputStream(uri)
        if (input == null) {
            _progress.value = ImportProgress(
                isImporting = false,
                stage = "Open failed",
                errorMessage = "Unable to open selected ZIP archive from storage provider.",
                isCompleted = true,
            )
            return@withContext
        }

        input.use { stream ->
            importZipStream(stream, displayName)
        }
    }

    suspend fun importZipStream(inputStream: InputStream, archiveName: String) = withContext(Dispatchers.IO) {
        val batchId = "zip_${System.currentTimeMillis()}"
        val stagingDir = storageManager.createBatchStagingDir(batchId)
        val sampleDir = storageManager.createBatchSampleDir(batchId)

        val unsupportedFiles = mutableListOf<String>()
        val missingSamples = mutableListOf<String>()
        val preservedRawPaths = mutableListOf<String>()
        var processedEntries = 0
        var importedPatchCount = 0
        var duplicateCount = 0

        _progress.value = ImportProgress(
            isImporting = true,
            stage = "Streaming $archiveName...",
            processedEntries = 0,
            totalEntries = 0,
        )

        try {
            // Pass 1: Stream ZIP entries directly to staging directory without loading archive into RAM
            val zis = ZipInputStream(BufferedInputStream(inputStream, 32768))
            var entry: ZipEntry?
            while (true) {
                currentCoroutineContext().ensureActive()
                entry = try {
                    zis.nextEntry
                } catch (ze: ZipException) {
                    throw IllegalStateException("Corrupt ZIP entry encountered in $archiveName: ${ze.message}", ze)
                }
                if (entry == null) break

                val rawName = entry.name
                processedEntries++

                if (rawName.startsWith("__MACOSX/", ignoreCase = true) || rawName.endsWith(".DS_Store")) {
                    zis.closeEntry()
                    continue
                }

                val targetFile = storageManager.resolveSafeChildFile(stagingDir, rawName)
                if (targetFile == null) {
                    unsupportedFiles.add("$rawName (Rejected unsafe archive path)")
                    zis.closeEntry()
                    continue
                }

                if (entry.isDirectory) {
                    targetFile.mkdirs()
                } else {
                    storageManager.copyStreamWithStorageGuard(zis, targetFile)
                }
                zis.closeEntry()

                if (processedEntries % 15 == 0) {
                    _progress.value = _progress.value.copy(
                        stage = "Extracting ($processedEntries entries)...",
                        processedEntries = processedEntries,
                    )
                }
            }

            currentCoroutineContext().ensureActive()
            _progress.value = _progress.value.copy(
                stage = "Scanning extracted folders & configs...",
                processedEntries = processedEntries,
                totalEntries = processedEntries,
            )

            // Check if archive is a genuine Roland SPD-30 backup
            val spd30Detection = spd30Importer.detectSpd30Structure(stagingDir)
            if (spd30Detection.isSpd30Backup) {
                val spdResult = spd30Importer.importDetectedBackup(stagingDir, spd30Detection, batchId)
                unsupportedFiles.addAll(spdResult.unsupportedFiles)
                missingSamples.addAll(spdResult.missingSamples)
                preservedRawPaths.addAll(spdResult.preservedRawPaths)

                val existingSigs = patchManager.getExistingSignatures().toMutableSet()
                val toInsert = mutableListOf<OctapadPatch>()
                val toInsertSigs = mutableListOf<String>()
                for (p in spdResult.importedPatches) {
                    val sig = patchManager.computePatchSignature(p.name, p.sourceFolder, p.pads)
                    if (sig in existingSigs) {
                        duplicateCount++
                    } else {
                        existingSigs.add(sig)
                        toInsert.add(p)
                        toInsertSigs.add(sig)
                    }
                }
                if (toInsert.isNotEmpty()) {
                    patchManager.insertImportedBatch(toInsert, toInsertSigs)
                    importedPatchCount += toInsert.size
                }
            } else {
                // Reconstruct .mcn / machine.cfg / JSON / folder kits
                val result = reconstructDirectoryTree(
                    rootDir = stagingDir,
                    sampleDestDir = sampleDir,
                    archiveDisplayName = archiveName,
                    onStageUpdate = { msg, count ->
                        _progress.value = _progress.value.copy(
                            stage = msg,
                            importedPatches = count,
                        )
                    },
                )
                importedPatchCount += result.importedPatches
                duplicateCount += result.skippedDuplicates
                missingSamples.addAll(result.missingSamples)
                unsupportedFiles.addAll(result.unsupportedFiles)
            }

            _progress.value = ImportProgress(
                isImporting = false,
                stage = "Import complete",
                processedEntries = processedEntries,
                totalEntries = processedEntries,
                importedPatches = importedPatchCount,
                skippedDuplicates = duplicateCount,
                missingSamples = missingSamples.distinct(),
                unsupportedFiles = unsupportedFiles.distinct(),
                preservedRawPaths = preservedRawPaths,
                isCompleted = true,
            )
        } catch (ce: CancellationException) {
            _progress.value = ImportProgress(
                isImporting = false,
                stage = "Import cancelled",
                processedEntries = processedEntries,
                importedPatches = importedPatchCount,
                isCancelled = true,
                isCompleted = true,
            )
            throw ce
        } catch (e: Exception) {
            _progress.value = ImportProgress(
                isImporting = false,
                stage = "Import failed",
                processedEntries = processedEntries,
                importedPatches = importedPatchCount,
                missingSamples = missingSamples.distinct(),
                unsupportedFiles = unsupportedFiles.distinct(),
                errorMessage = e.message ?: "Unexpected error while importing $archiveName",
                isCompleted = true,
            )
        } finally {
            storageManager.cleanupStagingDir(stagingDir)
        }
    }

    /**
     * Imports an extracted folder tree (e.g. .MCN folder collection or Roland SPD-30 backup folder) picked via SAF OpenDocumentTree.
     */
    suspend fun importDocumentTree(treeUri: Uri, expectSpd30: Boolean = false) = withContext(Dispatchers.IO) {
        val batchId = "tree_${System.currentTimeMillis()}"
        val stagingDir = storageManager.createBatchStagingDir(batchId)
        val sampleDir = storageManager.createBatchSampleDir(batchId)
        var copiedCount = 0

        _progress.value = ImportProgress(
            isImporting = true,
            stage = "Scanning selected folder...",
        )

        try {
            copyDocumentTreeToStaging(treeUri, stagingDir) { count ->
                copiedCount = count
                if (count % 10 == 0) {
                    _progress.value = _progress.value.copy(
                        stage = "Reading folder files ($count)...",
                        processedEntries = count,
                    )
                }
            }

            val spdDetection = spd30Importer.detectSpd30Structure(stagingDir)
            if (spdDetection.isSpd30Backup) {
                val spdResult = spd30Importer.importDetectedBackup(stagingDir, spdDetection, batchId)
                val existingSigs = patchManager.getExistingSignatures().toMutableSet()
                val toInsert = mutableListOf<OctapadPatch>()
                val toInsertSigs = mutableListOf<String>()
                var dups = 0
                for (p in spdResult.importedPatches) {
                    val sig = patchManager.computePatchSignature(p.name, p.sourceFolder, p.pads)
                    if (sig in existingSigs) dups++ else {
                        existingSigs.add(sig)
                        toInsert.add(p)
                        toInsertSigs.add(sig)
                    }
                }
                if (toInsert.isNotEmpty()) {
                    patchManager.insertImportedBatch(toInsert, toInsertSigs)
                }
                _progress.value = ImportProgress(
                    isImporting = false,
                    stage = "SPD-30 backup processed",
                    processedEntries = copiedCount,
                    totalEntries = copiedCount,
                    importedPatches = toInsert.size,
                    skippedDuplicates = dups,
                    missingSamples = spdResult.missingSamples,
                    unsupportedFiles = spdResult.unsupportedFiles,
                    preservedRawPaths = spdResult.preservedRawPaths,
                    isCompleted = true,
                )
            } else if (expectSpd30) {
                _progress.value = ImportProgress(
                    isImporting = false,
                    stage = "SPD-30 structure not found",
                    processedEntries = copiedCount,
                    unsupportedFiles = listOf("Expected ROLAND/SPD-30/DATA01/BACKUP or ROLAND/SPD-30/DATA01/KIT folder hierarchy."),
                    errorMessage = "Selected folder does not contain a valid ROLAND/SPD-30/DATA01/BACKUP or KIT directory.",
                    isCompleted = true,
                )
            } else {
                val result = reconstructDirectoryTree(
                    rootDir = stagingDir,
                    sampleDestDir = sampleDir,
                    archiveDisplayName = "Folder Import",
                    onStageUpdate = { msg, count ->
                        _progress.value = _progress.value.copy(stage = msg, importedPatches = count)
                    },
                )
                _progress.value = result.copy(
                    isImporting = false,
                    stage = "Folder import complete",
                    processedEntries = copiedCount,
                    totalEntries = copiedCount,
                    isCompleted = true,
                )
            }
        } catch (ce: CancellationException) {
            _progress.value = ImportProgress(isImporting = false, stage = "Import cancelled", isCancelled = true, isCompleted = true)
            throw ce
        } catch (e: Exception) {
            _progress.value = ImportProgress(
                isImporting = false,
                stage = "Folder import failed",
                errorMessage = e.message ?: "Failed to import selected folder.",
                isCompleted = true,
            )
        } finally {
            storageManager.cleanupStagingDir(stagingDir)
        }
    }

    /**
     * Imports multi-selected WAV / MP3 / OGG samples into a playable 8-pad patch (or multiple 8-pad banks if >8 selected).
     */
    suspend fun importAudioFiles(uris: List<Uri>, label: String) = withContext(Dispatchers.IO) {
        if (uris.isEmpty()) return@withContext
        _progress.value = ImportProgress(isImporting = true, stage = "Importing ${uris.size} audio sample(s)...", totalEntries = uris.size)

        try {
            val persistedFiles = mutableListOf<File>()
            val unsupported = mutableListOf<String>()

            uris.forEachIndexed { index, uri ->
                currentCoroutineContext().ensureActive()
                val name = storageManager.queryDisplayName(uri) ?: "sample_${index + 1}.wav"
                if (!McnPatchParser.isSupportedAudioFilename(name)) {
                    unsupported.add("$name (Unsupported audio format)")
                } else {
                    val saved = storageManager.persistUriSample(uri, name).getOrElse { err ->
                        throw IllegalStateException(err.message ?: "Failed to copy $name")
                    }
                    persistedFiles.add(saved)
                }
                _progress.value = _progress.value.copy(processedEntries = index + 1)
            }

            val patches = mutableListOf<OctapadPatch>()
            val sigs = mutableListOf<String>()
            persistedFiles.chunked(8).forEachIndexed { bankIdx, chunk ->
                val pads = MutableList(8) { PadAssignment(padIndex = it) }
                chunk.forEachIndexed { padIdx, file ->
                    pads[padIdx] = PadAssignment(
                        padIndex = padIdx,
                        samplePath = file.absolutePath,
                        sampleName = file.nameWithoutExtension,
                    )
                }
                val baseName = if (chunk.size == 1) chunk.first().nameWithoutExtension else "$label Kit"
                val patchName = if (persistedFiles.size > 8) "$baseName ${bankIdx + 1}" else baseName
                val patch = OctapadPatch(
                    patchNumber = 0,
                    name = patchName,
                    sourceType = PatchSourceType.AUDIO_IMPORT,
                    sourceFolder = label,
                    pads = pads,
                )
                patches.add(patch)
                sigs.add(patchManager.computePatchSignature(patch.name, patch.sourceFolder, patch.pads))
            }

            if (patches.isNotEmpty()) {
                patchManager.insertImportedBatch(patches, sigs)
            }

            _progress.value = ImportProgress(
                isImporting = false,
                stage = "Samples imported",
                processedEntries = uris.size,
                totalEntries = uris.size,
                importedPatches = patches.size,
                unsupportedFiles = unsupported,
                isCompleted = true,
            )
        } catch (e: Exception) {
            _progress.value = ImportProgress(
                isImporting = false,
                stage = "Sample import failed",
                errorMessage = e.message ?: "Unable to import selected audio files.",
                isCompleted = true,
            )
        }
    }

    /**
     * Imports a JSON patch / bank collection picked via SAF.
     */
    suspend fun importJsonFile(uri: Uri) = withContext(Dispatchers.IO) {
        val filename = storageManager.queryDisplayName(uri) ?: "patch.json"
        _progress.value = ImportProgress(isImporting = true, stage = "Reading $filename...")
        try {
            val jsonText = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: error("Unable to read $filename")

            val allStoredAudio = storageManager.samplesRootDir.walkTopDown().filter { it.isFile }.toList()
            val index = AudioArchiveIndex(storageManager.samplesRootDir, allStoredAudio)
            val missing = mutableListOf<String>()

            val parsed = kitManager.parseJsonPatches(jsonText, filename.substringBeforeLast('.')) { ref ->
                val resolved = index.resolveSample(ref, storageManager.samplesRootDir)?.absolutePath
                if (resolved == null && McnPatchParser.looksLikeAudioReference(ref)) {
                    missing.add(ref)
                }
                resolved
            }

            if (parsed.isEmpty()) {
                _progress.value = ImportProgress(
                    isImporting = false,
                    stage = "No valid patches found",
                    errorMessage = "JSON file $filename did not contain recognizable patch or pad entries.",
                    isCompleted = true,
                )
                return@withContext
            }

            val existingSigs = patchManager.getExistingSignatures().toMutableSet()
            val toInsert = mutableListOf<OctapadPatch>()
            val sigs = mutableListOf<String>()
            var dups = 0
            for (p in parsed) {
                val sig = patchManager.computePatchSignature(p.name, p.sourceFolder, p.pads)
                if (sig in existingSigs) dups++ else {
                    existingSigs.add(sig)
                    toInsert.add(p)
                    sigs.add(sig)
                }
            }
            if (toInsert.isNotEmpty()) {
                patchManager.insertImportedBatch(toInsert, sigs)
            }

            _progress.value = ImportProgress(
                isImporting = false,
                stage = "JSON import complete",
                processedEntries = parsed.size,
                totalEntries = parsed.size,
                importedPatches = toInsert.size,
                skippedDuplicates = dups,
                missingSamples = missing.distinct(),
                isCompleted = true,
            )
        } catch (e: Exception) {
            _progress.value = ImportProgress(
                isImporting = false,
                stage = "JSON import failed",
                errorMessage = e.message ?: "Failed to parse JSON patch file.",
                isCompleted = true,
            )
        }
    }

    /**
     * Core batch reconstruction engine for .mcn folders, machine.cfg configs, JSON files, and loose folder audio.
     * Supports arbitrary entry counts and commits patches incrementally to Room.
     */
    internal suspend fun reconstructDirectoryTree(
        rootDir: File,
        sampleDestDir: File,
        archiveDisplayName: String,
        onStageUpdate: (String, Int) -> Unit,
    ): ImportProgress {
        val allFiles = rootDir.walkTopDown().filter { it.isFile }.toList()
        val cfgFiles = allFiles.filter { it.name.equals("machine.cfg", ignoreCase = true) }
            .sortedBy { it.canonicalPath.lowercase(Locale.US) }
        val mcnFolders = rootDir.walkTopDown()
            .filter { it.isDirectory && it.name.endsWith(".mcn", ignoreCase = true) }
            .sortedBy { it.canonicalPath.lowercase(Locale.US) }
            .toList()
        val jsonFiles = allFiles.filter { it.extension.equals("json", ignoreCase = true) }
        val audioFiles = allFiles.filter { McnPatchParser.isSupportedAudioFilename(it.name) }

        val unsupportedFiles = allFiles.filter { file ->
            !file.name.equals("machine.cfg", ignoreCase = true) &&
                !file.extension.equals("json", ignoreCase = true) &&
                !McnPatchParser.isSupportedAudioFilename(file.name) &&
                !file.extension.lowercase(Locale.US).let { it in setOf("txt", "ini", "cfg", "md", "xml") }
        }.map { file ->
            "${file.relativeToOrSelf(rootDir).path.replace('\\', '/')} (Unsupported file format)"
        }

        // Persist all audio files cleanly from staging to app-private samples storage FIRST, keeping relative paths intact
        val persistedAudioFiles = mutableListOf<File>()
        val stagingToPersistedMap = HashMap<String, File>(audioFiles.size)
        for (srcAudio in audioFiles) {
            currentCoroutineContext().ensureActive()
            val rel = srcAudio.relativeToOrSelf(rootDir).path.replace('\\', '/')
            val persisted = storageManager.persistStagingSample(srcAudio, sampleDestDir, rel)
            persistedAudioFiles.add(persisted)
            stagingToPersistedMap[srcAudio.canonicalPath] = persisted
        }

        // Build lookup index pointing directly to persisted sample files!
        val persistedIndex = AudioArchiveIndex(sampleDestDir, persistedAudioFiles)

        val reconstructedPatches = mutableListOf<Pair<OctapadPatch, String>>()
        val missingSamples = mutableListOf<String>()
        val coveredMcnDirs = HashSet<String>()
        val referencedPersistedPaths = HashSet<String>()

        // Helper to resolve staged cfgDir -> matching sampleDestDir subdirectory
        fun correspondingPersistedDir(stagingDir: File): File {
            val rel = stagingDir.relativeToOrSelf(rootDir).path.replace('\\', '/')
            return if (rel.isBlank() || rel == ".") sampleDestDir else File(sampleDestDir, rel)
        }

        // 1. Parse ALL machine.cfg files (e.g. all 106 machine.cfg across 39 .mcn folders)
        for (cfg in cfgFiles) {
            currentCoroutineContext().ensureActive()
            val cfgDir = cfg.parentFile ?: rootDir
            coveredMcnDirs.add(cfgDir.canonicalPath)
            val persistedDir = correspondingPersistedDir(cfgDir)
            val parsed = mcnParser.parseMachineConfig(cfg, rootDir, persistedIndex)
            // Also fill from persistedDir if cfgDir samples were moved to persistedDir
            val finalPads = fillUnassignedPadsFromDir(parsed.padAssignments, persistedDir)
            finalPads.mapNotNull { it.samplePath }.forEach { referencedPersistedPaths.add(it) }
            missingSamples.addAll(parsed.missingSamples)

            if (finalPads.any { it.hasSample }) {
                val patch = OctapadPatch(
                    patchNumber = 0,
                    name = parsed.patchName,
                    sourceType = PatchSourceType.ZIP_MCN,
                    sourceFolder = parsed.sourceFolder,
                    pads = finalPads,
                )
                val sig = patchManager.computePatchSignature(patch.name, patch.sourceFolder, patch.pads)
                reconstructedPatches.add(patch to sig)
            }
        }

        // 2. Check .mcn folders that had no machine.cfg inside them or their direct children
        for (mcnDir in mcnFolders) {
            currentCoroutineContext().ensureActive()
            val hasNestedCfg = cfgFiles.any { it.canonicalPath.startsWith(mcnDir.canonicalPath + File.separator) || it.parentFile?.canonicalPath == mcnDir.canonicalPath }
            if (hasNestedCfg) continue

            val persistedMcnDir = correspondingPersistedDir(mcnDir)
            val mcnAudio = persistedMcnDir.walkTopDown().filter { it.isFile && McnPatchParser.isSupportedAudioFilename(it.name) }.toList()
            if (mcnAudio.isEmpty()) continue

            mcnAudio.chunked(8).forEachIndexed { chunkIdx, chunk ->
                val result = mcnParser.buildPatchFromMcnFolder(mcnDir, rootDir, chunk, persistedIndex)
                val name = if (mcnAudio.size > 8) "${result.patchName} ${chunkIdx + 1}" else result.patchName
                result.padAssignments.mapNotNull { it.samplePath }.forEach { referencedPersistedPaths.add(it) }
                val patch = OctapadPatch(
                    patchNumber = 0,
                    name = name,
                    sourceType = PatchSourceType.ZIP_MCN,
                    sourceFolder = result.sourceFolder,
                    pads = result.padAssignments,
                )
                val sig = patchManager.computePatchSignature(patch.name, patch.sourceFolder, patch.pads)
                reconstructedPatches.add(patch to sig)
            }
        }

        // 3. Parse any JSON patch descriptors in archive
        for (jsonFile in jsonFiles) {
            currentCoroutineContext().ensureActive()
            val text = runCatching { jsonFile.readText(Charsets.UTF_8) }.getOrNull() ?: continue
            val persistedDir = correspondingPersistedDir(jsonFile.parentFile ?: rootDir)
            val jsonPatches = kitManager.parseJsonPatches(text, jsonFile.nameWithoutExtension) { ref ->
                persistedIndex.resolveSample(ref, persistedDir)?.absolutePath
            }
            for (jp in jsonPatches) {
                jp.pads.mapNotNull { it.samplePath }.forEach { referencedPersistedPaths.add(it) }
                if (jp.pads.any { it.hasSample }) {
                    val sig = patchManager.computePatchSignature(jp.name, jp.sourceFolder, jp.pads)
                    reconstructedPatches.add(jp to sig)
                }
            }
        }

        // 4. Group remaining unreferenced audio files by their folder (NEVER one patch per single audio file!)
        val unreferencedAudio = persistedAudioFiles.filter { it.absolutePath !in referencedPersistedPaths }
        if (unreferencedAudio.isNotEmpty()) {
            val byFolder = unreferencedAudio.groupBy { file ->
                file.parentFile?.relativeToOrSelf(sampleDestDir)?.path?.replace('\\', '/')
                    ?.takeIf { it.isNotBlank() && it != "." }
                    ?: archiveDisplayName.substringBeforeLast('.')
            }
            byFolder.toSortedMap().forEach { (folderRel, files) ->
                val cleanFolderName = folderRel.substringAfterLast('/')
                    .removeSuffix(".mcn")
                    .removeSuffix(".MCN")
                    .replace('_', ' ')
                    .trim()
                    .ifBlank { "Imported Kit" }

                files.sortedBy { it.name.lowercase(Locale.US) }.chunked(8).forEachIndexed { bankIdx, chunk ->
                    val pads = MutableList(8) { PadAssignment(padIndex = it) }
                    chunk.forEachIndexed { idx, file ->
                        pads[idx] = PadAssignment(
                            padIndex = idx,
                            samplePath = file.absolutePath,
                            sampleName = file.nameWithoutExtension,
                        )
                    }
                    val patchName = if (files.size > 8) "$cleanFolderName ${bankIdx + 1}" else cleanFolderName
                    val patch = OctapadPatch(
                        patchNumber = 0,
                        name = patchName,
                        sourceType = PatchSourceType.ZIP_MCN,
                        sourceFolder = folderRel,
                        pads = pads,
                    )
                    val sig = patchManager.computePatchSignature(patch.name, patch.sourceFolder, patch.pads)
                    reconstructedPatches.add(patch to sig)
                }
            }
        }

        // Commit incrementally in batches of 20 patches
        val existingSignatures = patchManager.getExistingSignatures().toMutableSet()
        var importedCount = 0
        var duplicateCount = 0

        val uniqueBatch = mutableListOf<Pair<OctapadPatch, String>>()
        for (pair in reconstructedPatches) {
            if (pair.second in existingSignatures) {
                duplicateCount++
            } else {
                existingSignatures.add(pair.second)
                uniqueBatch.add(pair)
            }
        }

        uniqueBatch.chunked(20).forEach { chunk ->
            currentCoroutineContext().ensureActive()
            val patches = chunk.map { it.first }
            val sigs = chunk.map { it.second }
            patchManager.insertImportedBatch(patches, sigs)
            importedCount += patches.size
            onStageUpdate("Saving patches ($importedCount/${uniqueBatch.size})...", importedCount)
        }

        return ImportProgress(
            importedPatches = importedCount,
            skippedDuplicates = duplicateCount,
            missingSamples = missingSamples.distinct(),
            unsupportedFiles = unsupportedFiles.distinct(),
        )
    }

    private fun fillUnassignedPadsFromDir(pads: List<PadAssignment>, dir: File): List<PadAssignment> {
        if (!dir.exists() || !dir.isDirectory) return pads
        val mutable = pads.toMutableList()
        val used = mutable.mapNotNull { it.samplePath }.toSet()
        val extraAudio = dir.listFiles()
            ?.filter { it.isFile && McnPatchParser.isSupportedAudioFilename(it.name) && it.absolutePath !in used }
            ?.sortedBy { it.name.lowercase(Locale.US) }
            .orEmpty()
        var cursor = 0
        for (i in 0 until 8) {
            if (!mutable[i].hasSample && cursor < extraAudio.size) {
                val f = extraAudio[cursor++]
                mutable[i] = mutable[i].copy(
                    samplePath = f.absolutePath,
                    sampleName = f.nameWithoutExtension,
                )
            }
        }
        return mutable
    }

    private suspend fun copyDocumentTreeToStaging(
        treeUri: Uri,
        stagingDir: File,
        onFileCopied: (Int) -> Unit,
    ) {
        val docId = DocumentsContract.getTreeDocumentId(treeUri)
        var counter = 0

        suspend fun walk(parentDocId: String, targetDir: File) {
            currentCoroutineContext().ensureActive()
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
            )
            context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                while (cursor.moveToNext()) {
                    currentCoroutineContext().ensureActive()
                    val childId = cursor.getString(idCol)
                    val childName = cursor.getString(nameCol) ?: continue
                    val mime = cursor.getString(mimeCol) ?: ""
                    val safeChild = storageManager.resolveSafeChildFile(targetDir, childName) ?: continue
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        safeChild.mkdirs()
                        walk(childId, safeChild)
                    } else {
                        val fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                        context.contentResolver.openInputStream(fileUri)?.use { stream ->
                            storageManager.copyStreamWithStorageGuard(stream, safeChild)
                            counter++
                            onFileCopied(counter)
                        }
                    }
                }
            }
        }

        walk(docId, stagingDir)
    }
}
