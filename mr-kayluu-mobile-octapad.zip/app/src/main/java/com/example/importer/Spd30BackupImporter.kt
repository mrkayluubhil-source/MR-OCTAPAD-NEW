package com.example.importer

import com.example.data.StorageManager
import com.example.model.OctapadPatch
import com.example.model.PadAssignment
import com.example.model.PatchSourceType
import java.io.File
import java.util.Locale

data class Spd30DetectionResult(
    val isSpd30Backup: Boolean,
    val hasBackupAllFolder: Boolean,
    val hasKitFolder: Boolean,
    val backupFiles: List<File>,
    val kitFiles: List<File>,
    val audioFiles: List<File>,
    val metadataFiles: List<File>,
)

data class Spd30ImportResult(
    val importedPatches: List<OctapadPatch>,
    val preservedRawPaths: List<String>,
    val unsupportedFiles: List<String>,
    val missingSamples: List<String>,
)

/**
 * Genuine Roland OCTAPAD SPD-30 Backup & Kit Importer.
 *
 * Strictly detects documented Roland SPD-30 directory hierarchies:
 *   - ROLAND/SPD-30/DATA01/BACKUP  (BACKUP ALL archives)
 *   - ROLAND/SPD-30/DATA01/KIT     (Individual KIT imports)
 *
 * Preserves all proprietary Roland binary files without inventing fake binary decoders,
 * reads any documented/readable metadata or accompanying audio files, and reports
 * exact unsupported proprietary binary structures transparently.
 */
class Spd30BackupImporter(
    private val storageManager: StorageManager,
    private val kitManager: KitManager,
) {

    fun detectSpd30Structure(rootDir: File): Spd30DetectionResult {
        val allFiles = rootDir.walkTopDown().filter { it.isFile }.toList()
        val backupFiles = mutableListOf<File>()
        val kitFiles = mutableListOf<File>()
        val audioFiles = mutableListOf<File>()
        val metadataFiles = mutableListOf<File>()
        var hasBackupDir = false
        var hasKitDir = false

        rootDir.walkTopDown().filter { it.isDirectory }.forEach { dir ->
            val rel = dir.relativeToOrSelf(rootDir).path.replace('\\', '/').uppercase(Locale.US)
            if (rel.endsWith("ROLAND/SPD-30/DATA01/BACKUP") || rel.contains("ROLAND/SPD-30/DATA01/BACKUP/")) {
                hasBackupDir = true
            }
            if (rel.endsWith("ROLAND/SPD-30/DATA01/KIT") || rel.contains("ROLAND/SPD-30/DATA01/KIT/")) {
                hasKitDir = true
            }
        }

        for (file in allFiles) {
            val rel = file.relativeToOrSelf(rootDir).path.replace('\\', '/').uppercase(Locale.US)
            when {
                rel.contains("ROLAND/SPD-30/DATA01/BACKUP") -> {
                    hasBackupDir = true
                    backupFiles.add(file)
                }
                rel.contains("ROLAND/SPD-30/DATA01/KIT") -> {
                    hasKitDir = true
                    kitFiles.add(file)
                }
            }
            if (McnPatchParser.isSupportedAudioFilename(file.name)) {
                audioFiles.add(file)
            } else if (file.extension.lowercase(Locale.US) in setOf("json", "cfg", "txt", "xml")) {
                metadataFiles.add(file)
            }
        }

        val detected = hasBackupDir || hasKitDir
        return Spd30DetectionResult(
            isSpd30Backup = detected,
            hasBackupAllFolder = hasBackupDir,
            hasKitFolder = hasKitDir,
            backupFiles = backupFiles,
            kitFiles = kitFiles,
            audioFiles = audioFiles,
            metadataFiles = metadataFiles,
        )
    }

    fun importDetectedBackup(
        rootDir: File,
        detection: Spd30DetectionResult,
        batchId: String,
    ): Spd30ImportResult {
        val preservedDir = storageManager.createSpd30PreservedDir(batchId)
        val batchSampleDir = storageManager.createBatchSampleDir(batchId)
        val preservedPaths = mutableListOf<String>()
        val unsupportedFiles = mutableListOf<String>()
        val missingSamples = mutableListOf<String>()
        val importedPatches = mutableListOf<OctapadPatch>()

        // Persist any audio samples present in the archive
        val persistedAudioIndex = AudioArchiveIndex(
            rootDir,
            detection.audioFiles.map { src ->
                val rel = src.relativeToOrSelf(rootDir).path.replace('\\', '/')
                storageManager.persistStagingSample(src, batchSampleDir, rel)
            },
        )

        // Preserve all original files inside ROLAND/SPD-30/DATA01/... intact
        val spdFiles = (detection.backupFiles + detection.kitFiles).distinctBy { it.canonicalPath }
        for (src in spdFiles) {
            val rel = src.relativeToOrSelf(rootDir).path.replace('\\', '/')
            val target = storageManager.resolveSafeChildFile(preservedDir, rel)
            if (target != null) {
                target.parentFile?.mkdirs()
                runCatching { src.copyTo(target, overwrite = true) }
                preservedPaths.add(target.absolutePath)
            }
        }

        // Parse any readable JSON/CFG metadata accompanying the backup
        for (meta in detection.metadataFiles) {
            if (meta.extension.equals("json", ignoreCase = true)) {
                val text = runCatching { meta.readText(Charsets.UTF_8) }.getOrNull() ?: continue
                val parsed = kitManager.parseJsonPatches(text, meta.nameWithoutExtension) { ref ->
                    persistedAudioIndex.resolveSample(ref, meta.parentFile ?: rootDir)?.absolutePath
                }
                importedPatches.addAll(
                    parsed.map {
                        it.copy(
                            sourceType = if (detection.hasBackupAllFolder) PatchSourceType.SPD30_BACKUP else PatchSourceType.SPD30_KIT,
                            sourceFolder = meta.relativeToOrSelf(rootDir).path.replace('\\', '/'),
                        )
                    }
                )
            }
        }

        // Inspect proprietary Roland binary files (.SPD / BKUP / KIT) without inventing undocumented formats
        for (file in spdFiles) {
            if (McnPatchParser.isSupportedAudioFilename(file.name)) continue
            if (file.extension.lowercase(Locale.US) in setOf("json", "txt")) continue

            val relPath = file.relativeToOrSelf(rootDir).path.replace('\\', '/')
            val readableLabel = extractVerifiedAsciiTitleIfPresent(file)
            val isKit = relPath.uppercase(Locale.US).contains("/KIT/")

            unsupportedFiles.add(
                "$relPath (Proprietary Roland SPD-30 binary format preserved at ${preservedDir.name}; " +
                    "internal wave/kit parameter decoding requires verified genuine SPD-30 binary spec/hardware test)"
            )

            // If there are matching external audio files or verified ASCII kit header, create a safe non-overwriting kit entry ONLY if audio samples match
            if (readableLabel != null && detection.audioFiles.isNotEmpty()) {
                val matchedPads = MutableList(8) { PadAssignment(padIndex = it) }
                val candidateSamples = detection.audioFiles.filter {
                    it.nameWithoutExtension.contains(readableLabel, ignoreCase = true)
                }.take(8)
                candidateSamples.forEachIndexed { idx, sampleFile ->
                    matchedPads[idx] = PadAssignment(
                        padIndex = idx,
                        samplePath = sampleFile.absolutePath,
                        sampleName = sampleFile.nameWithoutExtension,
                    )
                }
                if (matchedPads.any { it.hasSample }) {
                    importedPatches.add(
                        OctapadPatch(
                            patchNumber = 0,
                            name = readableLabel,
                            sourceType = if (isKit) PatchSourceType.SPD30_KIT else PatchSourceType.SPD30_BACKUP,
                            sourceFolder = relPath,
                            pads = matchedPads,
                        )
                    )
                }
            }
        }

        // If the SPD-30 folder contained bundled audio files not yet mapped into any patch, group by folder up to 8 pads
        if (importedPatches.isEmpty() && detection.audioFiles.isNotEmpty()) {
            val grouped = detection.audioFiles.groupBy { it.parentFile?.name ?: "SPD-30 Kit" }
            grouped.forEach { (folderName, files) ->
                files.chunked(8).forEachIndexed { chunkIdx, chunk ->
                    val pads = MutableList(8) { PadAssignment(padIndex = it) }
                    chunk.forEachIndexed { idx, f ->
                        val persisted = persistedAudioIndex.resolveSample(f.name, batchSampleDir) ?: f
                        pads[idx] = PadAssignment(
                            padIndex = idx,
                            samplePath = persisted.absolutePath,
                            sampleName = f.nameWithoutExtension,
                        )
                    }
                    val suffix = if (files.size > 8) " ${chunkIdx + 1}" else ""
                    importedPatches.add(
                        OctapadPatch(
                            patchNumber = 0,
                            name = "$folderName$suffix",
                            sourceType = if (detection.hasBackupAllFolder) PatchSourceType.SPD30_BACKUP else PatchSourceType.SPD30_KIT,
                            sourceFolder = "ROLAND/SPD-30/DATA01",
                            pads = pads,
                        )
                    )
                }
            }
        }

        return Spd30ImportResult(
            importedPatches = importedPatches,
            preservedRawPaths = preservedPaths,
            unsupportedFiles = unsupportedFiles,
            missingSamples = missingSamples,
        )
    }

    /**
     * Checks strictly for printable ASCII kit header text if present in a file without guessing binary offsets.
     */
    private fun extractVerifiedAsciiTitleIfPresent(file: File): String? {
        return try {
            val bytes = file.inputStream().use { input ->
                val buf = ByteArray(minOf(64L, file.length()).toInt())
                val read = input.read(buf)
                if (read > 0) buf.copyOf(read) else ByteArray(0)
            }
            // Only accept if file begins with a clear printable ASCII header signature like "SPD-30" or JSON
            val head = String(bytes, Charsets.US_ASCII)
            if (head.startsWith("{")) return null
            if (head.startsWith("SPD-30", ignoreCase = true)) {
                val printable = head.takeWhile { it in ' '..'~' }.trim()
                if (printable.length >= 4) printable else null
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }
}
