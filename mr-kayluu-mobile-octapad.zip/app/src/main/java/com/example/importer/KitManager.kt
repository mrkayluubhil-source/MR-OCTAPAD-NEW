package com.example.importer

import com.example.data.PatchSerializer
import com.example.model.EffectsSettings
import com.example.model.OctapadPatch
import com.example.model.PadAssignment
import com.example.model.PatchSourceType
import org.json.JSONArray
import org.json.JSONObject

/**
 * Coordinates kit/pad manipulation, previous/next index resolution, and JSON kit parsing/export.
 */
class KitManager {

    fun updatePadInPatch(
        patch: OctapadPatch,
        padIndex: Int,
        transform: (PadAssignment) -> PadAssignment,
    ): OctapadPatch {
        val idx = padIndex.coerceIn(0, 7)
        val updatedPads = patch.pads.toMutableList()
        while (updatedPads.size < 8) {
            updatedPads.add(PadAssignment(padIndex = updatedPads.size))
        }
        updatedPads[idx] = transform(updatedPads[idx]).copy(padIndex = idx)
        return patch.copy(
            pads = updatedPads,
            updatedAt = System.currentTimeMillis(),
            isCustomEdited = true,
        )
    }

    fun resolvePreviousPatch(patches: List<OctapadPatch>, activePatchId: Long?): OctapadPatch? {
        if (patches.isEmpty()) return null
        val idx = patches.indexOfFirst { it.id == activePatchId }
        return when {
            idx < 0 -> patches.first()
            idx == 0 -> patches.last()
            else -> patches[idx - 1]
        }
    }

    fun resolveNextPatch(patches: List<OctapadPatch>, activePatchId: Long?): OctapadPatch? {
        if (patches.isEmpty()) return null
        val idx = patches.indexOfFirst { it.id == activePatchId }
        return when {
            idx < 0 -> patches.first()
            idx >= patches.lastIndex -> patches.first()
            else -> patches[idx + 1]
        }
    }

    fun resolveAdjacentPatches(
        patches: List<OctapadPatch>,
        activePatchId: Long?,
    ): Pair<OctapadPatch?, OctapadPatch?> {
        if (patches.size <= 1) return null to null
        val prev = resolvePreviousPatch(patches, activePatchId)
        val next = resolveNextPatch(patches, activePatchId)
        return prev to next
    }

    fun parseJsonPatches(
        jsonText: String,
        fallbackName: String,
        resolveSampleByName: (String) -> String?,
    ): List<OctapadPatch> {
        val trimmed = jsonText.trim()
        if (trimmed.isEmpty()) return emptyList()

        return try {
            if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                buildList {
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        parseSingleJsonObject(obj, "$fallbackName ${i + 1}", resolveSampleByName)?.let { add(it) }
                    }
                }
            } else {
                val root = JSONObject(trimmed)
                val patchesArray = root.optJSONArray("patches") ?: root.optJSONArray("kits")
                if (patchesArray != null) {
                    buildList {
                        for (i in 0 until patchesArray.length()) {
                            val obj = patchesArray.optJSONObject(i) ?: continue
                            parseSingleJsonObject(obj, "$fallbackName ${i + 1}", resolveSampleByName)?.let { add(it) }
                        }
                    }
                } else {
                    listOfNotNull(parseSingleJsonObject(root, fallbackName, resolveSampleByName))
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parseSingleJsonObject(
        obj: JSONObject,
        fallbackName: String,
        resolveSampleByName: (String) -> String?,
    ): OctapadPatch? {
        val name = (obj.optString("name").ifBlank {
            obj.optString("patchName").ifBlank {
                obj.optString("title").ifBlank { fallbackName }
            }
        }).trim()

        val pads = MutableList(8) { idx -> PadAssignment(padIndex = idx) }
        val padsArray = obj.optJSONArray("pads") ?: obj.optJSONArray("samples") ?: obj.optJSONArray("slots")
        if (padsArray != null) {
            for (i in 0 until minOf(8, padsArray.length())) {
                val item = padsArray.opt(i)
                when (item) {
                    is JSONObject -> {
                        val idx = item.optInt("padIndex", item.optInt("pad", i)).let { raw ->
                            if (raw in 1..8 && padsArray.length() <= 8 && !item.has("padIndex")) raw - 1 else raw
                        }.coerceIn(0, 7)
                        val sampleRef = item.optString("samplePath")
                            .ifBlank { item.optString("sample") }
                            .ifBlank { item.optString("file") }
                            .ifBlank { item.optString("sampleName") }
                        val resolved = if (sampleRef.isNotBlank()) resolveSampleByName(sampleRef) else null
                        pads[idx] = PadAssignment(
                            padIndex = idx,
                            samplePath = resolved,
                            sampleName = item.optString("sampleName").ifBlank {
                                sampleRef.substringAfterLast('/').substringAfterLast('\\')
                            },
                            volume = item.optDouble("volume", 1.0).toFloat().coerceIn(0f, 1.5f),
                            pitchSemitones = item.optDouble("pitchSemitones", item.optDouble("pitch", 0.0))
                                .toFloat().coerceIn(-12f, 12f),
                            midiNote = item.optInt("midiNote", PadAssignment.defaultMidiNoteForPad(idx)).coerceIn(0, 127),
                            pan = item.optDouble("pan", 0.0).toFloat().coerceIn(-1f, 1f),
                        )
                    }
                    is String -> {
                        val resolved = resolveSampleByName(item)
                        pads[i] = PadAssignment(
                            padIndex = i,
                            samplePath = resolved,
                            sampleName = item.substringAfterLast('/').substringAfterLast('\\'),
                        )
                    }
                }
            }
        } else {
            // Check pad1..pad8 or 0..7 object keys
            for (i in 0 until 8) {
                val keyCandidates = listOf("pad${i + 1}", "pad_${i + 1}", "pad$i", "pad_$i", "${i + 1}")
                for (key in keyCandidates) {
                    if (obj.has(key)) {
                        val value = obj.opt(key)
                        if (value is String && value.isNotBlank()) {
                            val resolved = resolveSampleByName(value)
                            pads[i] = PadAssignment(
                                padIndex = i,
                                samplePath = resolved,
                                sampleName = value.substringAfterLast('/').substringAfterLast('\\'),
                            )
                        }
                        break
                    }
                }
            }
        }

        val fx = obj.optJSONObject("effects")?.let {
            PatchSerializer.effectsFromJson(it.toString())
        } ?: EffectsSettings()

        return OctapadPatch(
            patchNumber = 0, // Assigned sequentially by PatchManager on insert
            name = name,
            sourceType = PatchSourceType.JSON_IMPORT,
            sourceFolder = obj.optString("sourceFolder", ""),
            pads = pads,
            effects = fx,
        )
    }
}
