package com.example.importer

import com.example.data.PatchDao
import com.example.data.PatchEntity
import com.example.data.SettingsStore
import com.example.data.StorageManager
import com.example.model.OctapadPatch
import com.example.model.PadAssignment
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Manages the persistent unlimited Patch Library in Room with strict sequential numbering
 * (1, 2, 3, ..., 1000+) without leading zeros or arbitrary patch-count limits.
 */
class PatchManager(
    private val patchDao: PatchDao,
    private val storageManager: StorageManager,
    private val settingsStore: SettingsStore,
) {
    val patchesFlow: Flow<List<OctapadPatch>> = patchDao.observeAllPatches().map { entities ->
        entities.mapIndexed { index, entity ->
            // Ensure sequential 1-based numbering without leading zeros
            val domain = entity.toDomain()
            if (domain.patchNumber != index + 1) domain.copy(patchNumber = index + 1) else domain
        }
    }

    suspend fun getAllPatches(): List<OctapadPatch> {
        return patchDao.getAllPatchesOnce().mapIndexed { index, entity ->
            val domain = entity.toDomain()
            if (domain.patchNumber != index + 1) domain.copy(patchNumber = index + 1) else domain
        }
    }

    suspend fun getPatchCount(): Int = patchDao.getPatchCount()

    suspend fun getExistingSignatures(): Set<String> = patchDao.getAllSignatures().toHashSet()

    suspend fun savePatch(patch: OctapadPatch): OctapadPatch {
        val now = System.currentTimeMillis()
        val assignedNumber = if (patch.patchNumber > 0) {
            patch.patchNumber
        } else {
            patchDao.getMaxPatchNumber() + 1
        }
        val signature = computePatchSignature(patch.name, patch.sourceFolder, patch.pads)
        val updated = patch.copy(
            patchNumber = assignedNumber,
            updatedAt = now,
            isCustomEdited = true,
        )
        val entity = PatchEntity.fromDomain(updated, signature)
        return if (updated.id > 0L) {
            patchDao.updatePatch(entity)
            updated
        } else {
            val newId = patchDao.insertPatch(entity)
            val saved = updated.copy(id = newId)
            settingsStore.saveActivePatchId(newId)
            saved
        }
    }

    suspend fun insertImportedBatch(
        patches: List<OctapadPatch>,
        signatures: List<String>,
    ): List<Long> {
        if (patches.isEmpty()) return emptyList()
        var nextNumber = patchDao.getMaxPatchNumber() + 1
        val entities = patches.mapIndexed { idx, patch ->
            val number = nextNumber++
            val sig = signatures.getOrNull(idx) ?: computePatchSignature(patch.name, patch.sourceFolder, patch.pads)
            PatchEntity.fromDomain(
                patch.copy(patchNumber = number),
                signature = sig,
            )
        }
        return patchDao.insertPatches(entities)
    }

    suspend fun renamePatch(patchId: Long, newName: String) {
        val clean = newName.trim()
        if (clean.isEmpty()) return
        val existing = patchDao.getPatchById(patchId) ?: return
        patchDao.updatePatch(
            existing.copy(
                name = clean,
                updatedAt = System.currentTimeMillis(),
                isCustomEdited = true,
            )
        )
    }

    suspend fun deletePatch(patchId: Long) {
        patchDao.deleteAndRenumber(patchId)
        // Clean up any sample files no longer referenced by any remaining patch
        val remaining = patchDao.getAllPatchesOnce().map { it.toDomain() }
        val referencedPaths = remaining.flatMap { p ->
            p.pads.mapNotNull { it.samplePath }
        }.toSet()
        storageManager.cleanupOrphanedSamples(referencedPaths)
    }

    fun computePatchSignature(name: String, sourceFolder: String, pads: List<PadAssignment>): String {
        val padKey = pads.joinToString("|") { "${it.padIndex}:${it.sampleName}:${it.midiNote}" }
        return storageManager.sha256Short("${name.lowercase()}|${sourceFolder.lowercase()}|$padKey")
    }
}
