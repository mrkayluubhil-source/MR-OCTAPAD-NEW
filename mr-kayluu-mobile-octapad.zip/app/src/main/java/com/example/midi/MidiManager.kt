package com.example.midi

import android.content.Context
import android.content.pm.PackageManager
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager as AndroidMidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.example.model.MidiDeviceSummary
import com.example.model.MidiStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Real Android USB/Hardware MIDI system using android.media.midi.MidiManager.
 * Strictly excludes Bluetooth MIDI and never fabricates connection status.
 */
class MidiManager(
    private val context: Context,
    private val onNoteTrigger: (padNote: Int, velocity: Float) -> Unit,
) {
    private val systemMidiManager: AndroidMidiManager? =
        if (context.packageManager.hasSystemFeature(PackageManager.FEATURE_MIDI)) {
            context.getSystemService(Context.MIDI_SERVICE) as? AndroidMidiManager
        } else {
            null
        }

    private val mainHandler = Handler(Looper.getMainLooper())

    private val _status = MutableStateFlow(
        MidiStatus(
            isMidiSupported = systemMidiManager != null,
            lastEventLog = if (systemMidiManager != null) {
                "Waiting for USB MIDI device..."
            } else {
                "MIDI service not supported on this device"
            },
        )
    )
    val status: StateFlow<MidiStatus> = _status.asStateFlow()

    private val discoveredInfos = LinkedHashMap<Int, MidiDeviceInfo>()
    private var openInputDevice: MidiDevice? = null
    private var openOutputPort: MidiOutputPort? = null
    private var openOutputDevice: MidiDevice? = null
    private var openInputPort: MidiInputPort? = null
    private var lastPreferredDeviceName: String? = null

    private val incomingReceiver = object : MidiReceiver() {
        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
            parseMidiPacket(msg, offset, count)
        }
    }

    @Suppress("DEPRECATION")
    private val deviceCallback = object : AndroidMidiManager.DeviceCallback() {
        override fun onDeviceAdded(device: MidiDeviceInfo) {
            if (isBluetoothDevice(device)) return
            refreshDevices()
            // Reconnect automatically if previously selected or no active connection yet
            val name = extractDeviceName(device)
            if (lastPreferredDeviceName == name || openInputDevice == null || openOutputDevice == null) {
                autoConnectAvailable(device)
            }
        }

        override fun onDeviceRemoved(device: MidiDeviceInfo) {
            val removedId = device.id
            if (openInputDevice?.info?.id == removedId) {
                closeInputConnection()
            }
            if (openOutputDevice?.info?.id == removedId) {
                closeOutputConnection()
            }
            refreshDevices()
        }
    }

    fun start() {
        val mgr = systemMidiManager ?: return
        registerCallback(mgr)
        refreshDevices()
        discoveredInfos.values.firstOrNull()?.let { autoConnectAvailable(it) }
    }

    fun stop() {
        val mgr = systemMidiManager ?: return
        runCatching { mgr.unregisterDeviceCallback(deviceCallback) }
        closeInputConnection()
        closeOutputConnection()
    }

    @Suppress("DEPRECATION")
    private fun registerCallback(mgr: AndroidMidiManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            mgr.registerDeviceCallback(
                AndroidMidiManager.TRANSPORT_MIDI_BYTE_STREAM,
                { runnable -> mainHandler.post(runnable) },
                deviceCallback,
            )
        } else {
            mgr.registerDeviceCallback(deviceCallback, mainHandler)
        }
    }

    @Suppress("DEPRECATION")
    fun refreshDevices() {
        val mgr = systemMidiManager ?: return
        val devices: List<MidiDeviceInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            mgr.getDevicesForTransport(AndroidMidiManager.TRANSPORT_MIDI_BYTE_STREAM).toList()
        } else {
            mgr.devices.toList()
        }

        discoveredInfos.clear()
        val summaries = devices
            .filterNot(::isBluetoothDevice)
            .map { info ->
                discoveredInfos[info.id] = info
                val props = info.properties
                val manufacturer = props.getString(MidiDeviceInfo.PROPERTY_MANUFACTURER).orEmpty()
                val name = extractDeviceName(info)
                // Note: On Android MIDI, a device's output port sends MIDI OUT from hardware -> our app IN.
                // A device's input port receives MIDI IN from our app OUT -> hardware.
                MidiDeviceSummary(
                    id = info.id,
                    name = name,
                    manufacturer = manufacturer,
                    hasInput = info.outputPortCount > 0,
                    hasOutput = info.inputPortCount > 0,
                )
            }

        _status.update { current ->
            current.copy(
                connectedDevices = summaries,
                lastEventLog = if (summaries.isEmpty()) {
                    "No USB MIDI device connected"
                } else if (!current.isInputConnected && !current.isOutputConnected) {
                    "Detected ${summaries.size} USB MIDI device(s)"
                } else {
                    current.lastEventLog
                },
            )
        }
    }

    fun selectInputDevice(deviceId: Int) {
        val info = discoveredInfos[deviceId] ?: return
        lastPreferredDeviceName = extractDeviceName(info)
        openDeviceForInput(info)
    }

    fun selectOutputDevice(deviceId: Int) {
        val info = discoveredInfos[deviceId] ?: return
        lastPreferredDeviceName = extractDeviceName(info)
        openDeviceForOutput(info)
    }

    fun setChannel(channel: Int) {
        _status.update { it.copy(midiChannel = channel.coerceIn(0, 16)) }
    }

    fun setInputEnabled(enabled: Boolean) {
        _status.update { it.copy(isInputEnabled = enabled) }
    }

    fun setOutputEnabled(enabled: Boolean) {
        _status.update { it.copy(isOutputEnabled = enabled) }
    }

    fun sendNoteOn(note: Int, velocityFloat: Float) {
        val current = _status.value
        if (!current.isOutputEnabled) return
        val port = openInputPort ?: return
        val chIndex = if (current.midiChannel in 1..16) current.midiChannel - 1 else 9
        val statusByte = (0x90 or (chIndex and 0x0F)).toByte()
        val noteByte = note.coerceIn(0, 127).toByte()
        val velByte = (velocityFloat * 127f).toInt().coerceIn(1, 127).toByte()
        val buffer = byteArrayOf(statusByte, noteByte, velByte)
        runCatching {
            port.send(buffer, 0, buffer.size)
            _status.update {
                it.copy(lastEventLog = "TX Note $note Vel ${velByte.toInt() and 0xFF} Ch ${chIndex + 1}")
            }
        }.onFailure {
            closeOutputConnection()
            refreshDevices()
        }
    }

    private fun autoConnectAvailable(info: MidiDeviceInfo) {
        if (info.outputPortCount > 0 && openInputDevice == null) {
            openDeviceForInput(info)
        }
        if (info.inputPortCount > 0 && openOutputDevice == null) {
            openDeviceForOutput(info)
        }
    }

    private fun openDeviceForInput(info: MidiDeviceInfo) {
        val mgr = systemMidiManager ?: return
        if (info.outputPortCount <= 0) return
        closeInputConnection()
        mgr.openDevice(info, { device ->
            if (device == null) {
                _status.update { it.copy(isInputConnected = false, lastEventLog = "Failed to open MIDI IN") }
                return@openDevice
            }
            val port = device.openOutputPort(0)
            if (port == null) {
                runCatching { device.close() }
                return@openDevice
            }
            openInputDevice = device
            openOutputPort = port
            port.connect(incomingReceiver)
            _status.update {
                it.copy(
                    selectedInputDeviceId = info.id,
                    isInputConnected = true,
                    lastEventLog = "MIDI IN connected: ${extractDeviceName(info)}",
                )
            }
        }, mainHandler)
    }

    private fun openDeviceForOutput(info: MidiDeviceInfo) {
        val mgr = systemMidiManager ?: return
        if (info.inputPortCount <= 0) return
        closeOutputConnection()
        mgr.openDevice(info, { device ->
            if (device == null) {
                _status.update { it.copy(isOutputConnected = false, lastEventLog = "Failed to open MIDI OUT") }
                return@openDevice
            }
            val port = device.openInputPort(0)
            if (port == null) {
                runCatching { device.close() }
                return@openDevice
            }
            openOutputDevice = device
            openInputPort = port
            _status.update {
                it.copy(
                    selectedOutputDeviceId = info.id,
                    isOutputConnected = true,
                    lastEventLog = "MIDI OUT connected: ${extractDeviceName(info)}",
                )
            }
        }, mainHandler)
    }

    private fun closeInputConnection() {
        runCatching { openOutputPort?.disconnect(incomingReceiver) }
        runCatching { openOutputPort?.close() }
        runCatching { openInputDevice?.close() }
        openOutputPort = null
        openInputDevice = null
        _status.update { it.copy(isInputConnected = false, selectedInputDeviceId = null) }
    }

    private fun closeOutputConnection() {
        runCatching { openInputPort?.close() }
        runCatching { openOutputDevice?.close() }
        openInputPort = null
        openOutputDevice = null
        _status.update { it.copy(isOutputConnected = false, selectedOutputDeviceId = null) }
    }

    internal fun parseMidiPacket(msg: ByteArray, offset: Int, count: Int) {
        val current = _status.value
        if (!current.isInputEnabled) return
        var i = offset
        val end = (offset + count).coerceAtMost(msg.size)
        var runningStatus = 0

        while (i < end) {
            val b = msg[i].toInt() and 0xFF
            if (b >= 0xF8) {
                // Real-time messages (clock/active sensing) do not affect running status
                i++
                continue
            }
            if ((b and 0x80) != 0) {
                runningStatus = b
                i++
            }
            val statusType = runningStatus and 0xF0
            val channel = (runningStatus and 0x0F) + 1
            if (statusType == 0x90 || statusType == 0x80) {
                if (i + 1 >= end) break
                val note = msg[i].toInt() and 0x7F
                val velocity = msg[i + 1].toInt() and 0x7F
                i += 2

                val channelMatches = current.midiChannel == 0 || current.midiChannel == channel
                if (channelMatches && statusType == 0x90 && velocity > 0) {
                    val velFloat = (velocity / 127f).coerceIn(0.08f, 1.0f)
                    _status.update {
                        it.copy(lastEventLog = "RX Note $note Vel $velocity Ch $channel")
                    }
                    onNoteTrigger(note, velFloat)
                }
            } else if (statusType == 0xC0 || statusType == 0xD0) {
                i += 1
            } else if (statusType in listOf(0xA0, 0xB0, 0xE0)) {
                i += 2
            } else {
                i++
            }
        }
    }

    private fun isBluetoothDevice(info: MidiDeviceInfo): Boolean {
        return info.type == MidiDeviceInfo.TYPE_BLUETOOTH
    }

    private fun extractDeviceName(info: MidiDeviceInfo): String {
        val props = info.properties
        return props.getString(MidiDeviceInfo.PROPERTY_NAME)
            ?: props.getString(MidiDeviceInfo.PROPERTY_PRODUCT)
            ?: "USB MIDI #${info.id}"
    }
}
