package com.example.model

enum class PatchSourceType(val displayLabel: String) {
    ZIP_MCN("ZIP/.MCN"),
    SPD30_BACKUP("SPD-30 BACKUP"),
    SPD30_KIT("SPD-30 KIT"),
    JSON_IMPORT("JSON"),
    AUDIO_IMPORT("SAMPLES"),
    USER_CUSTOM("CUSTOM"),
}

enum class ActivePanel {
    PATCH_LIST,
    PATCH_LOAD,
    MIDI,
    PAD_EDIT,
    EFFECTS,
    RECORDING,
}

data class PadAssignment(
    val padIndex: Int, // 0..7 -> displayed as Pad 1..8 (never leading zeros)
    val samplePath: String? = null,
    val sampleName: String = "",
    val volume: Float = 1.0f, // 0.0f .. 1.5f
    val pitchSemitones: Float = 0.0f, // -12.0f .. +12.0f
    val midiNote: Int = defaultMidiNoteForPad(padIndex), // 0..127
    val pan: Float = 0.0f, // -1.0f .. +1.0f
) {
    val hasSample: Boolean get() = !samplePath.isNullOrBlank()
    val displayNumber: String get() = (padIndex + 1).toString()

    companion object {
        fun defaultMidiNoteForPad(padIndex: Int): Int = when (padIndex) {
            0 -> 36 // Kick
            1 -> 38 // Snare
            2 -> 42 // Closed Hi-Hat
            3 -> 46 // Open Hi-Hat
            4 -> 45 // Low Tom
            5 -> 47 // Mid Tom
            6 -> 49 // Crash Cymbal
            7 -> 51 // Ride Cymbal
            else -> 36 + padIndex
        }

        fun defaultPads(): List<PadAssignment> = (0 until 8).map { PadAssignment(padIndex = it) }
    }
}

data class EffectsSettings(
    val masterVolume: Float = 0.85f, // 0.0f .. 1.0f
    val bassDb: Float = 0.0f, // -12.0f .. +12.0f
    val trebleDb: Float = 0.0f, // -12.0f .. +12.0f
    val masterPitchSemitones: Float = 0.0f, // -12.0f .. +12.0f
    val echoLevel: Float = 0.0f, // 0.0f .. 1.0f
    val delayMs: Int = 260, // 40 .. 800 ms
    val delayFeedback: Float = 0.35f, // 0.0f .. 0.75f
    val reverbLevel: Float = 0.12f, // 0.0f .. 1.0f
)

data class OctapadPatch(
    val id: Long = 0L,
    val patchNumber: Int, // Strictly 1, 2, 3... (never leading zeros)
    val name: String,
    val sourceType: PatchSourceType = PatchSourceType.USER_CUSTOM,
    val sourceFolder: String = "",
    val pads: List<PadAssignment> = PadAssignment.defaultPads(),
    val effects: EffectsSettings = EffectsSettings(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isCustomEdited: Boolean = false,
) {
    val formattedNumber: String get() = patchNumber.toString()
    val assignedPadCount: Int get() = pads.count { it.hasSample }
}

data class ImportProgress(
    val isImporting: Boolean = false,
    val stage: String = "",
    val processedEntries: Int = 0,
    val totalEntries: Int = 0,
    val importedPatches: Int = 0,
    val skippedDuplicates: Int = 0,
    val missingSamples: List<String> = emptyList(),
    val unsupportedFiles: List<String> = emptyList(),
    val preservedRawPaths: List<String> = emptyList(),
    val errorMessage: String? = null,
    val isCompleted: Boolean = false,
    val isCancelled: Boolean = false,
)

data class RecordedEvent(
    val padIndex: Int,
    val timestampMs: Long,
    val velocity: Float,
    val midiNote: Int,
)

data class OctapadRecording(
    val id: Long = 0L,
    val name: String,
    val patchId: Long,
    val patchName: String,
    val events: List<RecordedEvent>,
    val durationMs: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val isLooping: Boolean = false,
)

data class MidiDeviceSummary(
    val id: Int,
    val name: String,
    val manufacturer: String,
    val hasInput: Boolean,
    val hasOutput: Boolean,
)

data class MidiStatus(
    val isMidiSupported: Boolean = false,
    val connectedDevices: List<MidiDeviceSummary> = emptyList(),
    val selectedInputDeviceId: Int? = null,
    val selectedOutputDeviceId: Int? = null,
    val isInputConnected: Boolean = false,
    val isOutputConnected: Boolean = false,
    val midiChannel: Int = 10, // 0 = OMNI, 1..16 = specific MIDI channel (10 = standard drums)
    val isInputEnabled: Boolean = true,
    val isOutputEnabled: Boolean = true,
    val lastEventLog: String = "No USB MIDI device connected",
)

fun gmDrumName(midiNote: Int): String = when (midiNote) {
    35 -> "Acoustic Bass"
    36 -> "Bass Drum 1"
    37 -> "Side Stick"
    38 -> "Acoustic Snare"
    39 -> "Hand Clap"
    40 -> "Electric Snare"
    41 -> "Low Floor Tom"
    42 -> "Closed Hi-Hat"
    43 -> "High Floor Tom"
    44 -> "Pedal Hi-Hat"
    45 -> "Low Tom"
    46 -> "Open Hi-Hat"
    47 -> "Low-Mid Tom"
    48 -> "Hi-Mid Tom"
    49 -> "Crash Cymbal 1"
    50 -> "High Tom"
    51 -> "Ride Cymbal 1"
    52 -> "Chinese Cymbal"
    53 -> "Ride Bell"
    54 -> "Tambourine"
    55 -> "Splash Cymbal"
    56 -> "Cowbell"
    57 -> "Crash Cymbal 2"
    60 -> "Hi Bongo"
    61 -> "Low Bongo"
    62 -> "Mute Hi Conga"
    63 -> "Open Hi Conga"
    64 -> "Low Conga"
    65 -> "High Timbale"
    66 -> "Low Timbale"
    69 -> "Cabasa"
    70 -> "Maracas"
    75 -> "Claves"
    else -> "Note $midiNote"
}
