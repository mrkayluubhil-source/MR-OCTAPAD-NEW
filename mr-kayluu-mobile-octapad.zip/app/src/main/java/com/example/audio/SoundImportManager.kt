package com.example.audio

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.util.LruCache
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min

data class StereoSample(
    val left: FloatArray,
    val right: FloatArray,
    val frameCount: Int,
) {
    val estimatedBytes: Int get() = frameCount * 8
}

/**
 * Decodes WAV (fast native RIFF PCM/float parser) and MP3/OGG/AAC/M4A/FLAC (via MediaExtractor + MediaCodec)
 * to 44.1 kHz stereo float PCM, backed by a bounded LRU memory cache so large libraries never exhaust RAM.
 */
class SoundImportManager(private val targetSampleRate: Int = 44100) {

    private val cacheBytesLimit = ((Runtime.getRuntime().maxMemory() / 6L).coerceIn(16L * 1024L * 1024L, 64L * 1024L * 1024L)).toInt()

    private val sampleCache = object : LruCache<String, StereoSample>(cacheBytesLimit) {
        override fun sizeOf(key: String, value: StereoSample): Int = value.estimatedBytes.coerceAtLeast(1)
    }

    fun getCachedOrDecode(filePath: String): StereoSample? {
        if (filePath.isBlank()) return null
        sampleCache.get(filePath)?.let { return it }

        val file = File(filePath)
        if (!file.exists() || !file.isFile || file.length() <= 0L) return null

        val decoded = decodeFileToStereoPcm(file) ?: return null
        if (decoded.estimatedBytes < cacheBytesLimit / 2) {
            sampleCache.put(filePath, decoded)
        }
        return decoded
    }

    fun preloadSample(filePath: String?) {
        if (filePath.isNullOrBlank()) return
        if (sampleCache.get(filePath) != null) return
        getCachedOrDecode(filePath)
    }

    fun evictSample(filePath: String) {
        sampleCache.remove(filePath)
    }

    fun clearCache() {
        sampleCache.evictAll()
    }

    fun decodeFileToStereoPcm(file: File): StereoSample? {
        val ext = file.extension.lowercase()
        if (ext == "wav" || ext == "wave") {
            decodeWavFast(file)?.let { return it }
        }
        return decodeWithMediaCodec(file)
    }

    /**
     * Pure-Kotlin RIFF/WAVE decoder supporting PCM 8/16/24/32-bit and IEEE Float 32-bit, mono & stereo.
     */
    internal fun decodeWavFast(file: File): StereoSample? {
        return try {
            BufferedInputStream(FileInputStream(file), 16384).use { input ->
                val header = ByteArray(12)
                if (input.read(header) != 12) return null
                val riff = String(header, 0, 4, Charsets.US_ASCII)
                val wave = String(header, 8, 4, Charsets.US_ASCII)
                if (riff != "RIFF" || wave != "WAVE") return null

                var audioFormat = 1
                var channels = 1
                var sampleRate = 44100
                var bitsPerSample = 16
                var rawData: ByteArray? = null

                val chunkHeader = ByteArray(8)
                while (true) {
                    val read = input.read(chunkHeader)
                    if (read < 8) break
                    val chunkId = String(chunkHeader, 0, 4, Charsets.US_ASCII)
                    val chunkSize = ByteBuffer.wrap(chunkHeader, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
                    if (chunkSize < 0 || chunkSize > MAX_WAV_CHUNK_BYTES) return null

                    when (chunkId) {
                        "fmt " -> {
                            val fmtBytes = readExact(input, chunkSize) ?: return null
                            if (fmtBytes.size < 16) return null
                            val bb = ByteBuffer.wrap(fmtBytes).order(ByteOrder.LITTLE_ENDIAN)
                            audioFormat = bb.short.toInt() and 0xFFFF
                            channels = bb.short.toInt() and 0xFFFF
                            sampleRate = bb.int
                            bb.int // byteRate
                            bb.short // blockAlign
                            bitsPerSample = bb.short.toInt() and 0xFFFF
                            // Only handle standard PCM (1) or IEEE Float (3) or WAVE_FORMAT_EXTENSIBLE (0xFFFE)
                            if (audioFormat != 1 && audioFormat != 3 && audioFormat != 0xFFFE) {
                                return null
                            }
                        }
                        "data" -> {
                            rawData = readExact(input, chunkSize) ?: return null
                            break
                        }
                        else -> {
                            val skipCount = chunkSize.toLong() + (chunkSize and 1)
                            skipExact(input, skipCount)
                        }
                    }
                    if (chunkId == "fmt " && (chunkSize and 1) == 1) {
                        skipExact(input, 1L)
                    }
                }

                val data = rawData ?: return null
                if (channels <= 0 || sampleRate <= 0 || bitsPerSample <= 0) return null

                val bytesPerSample = bitsPerSample / 8
                if (bytesPerSample <= 0) return null
                val frameAlign = bytesPerSample * channels
                val sourceFrames = (data.size / frameAlign).coerceAtMost(MAX_DECODED_FRAMES)
                if (sourceFrames <= 0) return null

                val srcL = FloatArray(sourceFrames)
                val srcR = FloatArray(sourceFrames)
                val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)

                for (f in 0 until sourceFrames) {
                    val sample0 = readSampleFloat(bb, f * frameAlign, bitsPerSample, audioFormat == 3)
                    val sample1 = if (channels >= 2) {
                        readSampleFloat(bb, f * frameAlign + bytesPerSample, bitsPerSample, audioFormat == 3)
                    } else {
                        sample0
                    }
                    srcL[f] = sample0
                    srcR[f] = sample1
                }

                resampleIfNeeded(srcL, srcR, sampleRate)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun readSampleFloat(bb: ByteBuffer, offset: Int, bitsPerSample: Int, isFloat: Boolean): Float {
        return when (bitsPerSample) {
            8 -> ((bb.get(offset).toInt() and 0xFF) - 128) / 128f
            16 -> bb.getShort(offset) / 32768f
            24 -> {
                val b0 = bb.get(offset).toInt() and 0xFF
                val b1 = bb.get(offset + 1).toInt() and 0xFF
                val b2 = bb.get(offset + 2).toInt() // signed high byte
                val v = (b2 shl 16) or (b1 shl 8) or b0
                v / 8388608f
            }
            32 -> {
                if (isFloat) bb.getFloat(offset).coerceIn(-1f, 1f)
                else (bb.getInt(offset) / 2147483648.0).toFloat()
            }
            else -> 0f
        }
    }

    private fun decodeWithMediaCodec(file: File): StereoSample? {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        return try {
            extractor.setDataSource(file.absolutePath)
            var audioTrackIndex = -1
            var trackFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    trackFormat = fmt
                    break
                }
            }
            if (audioTrackIndex < 0 || trackFormat == null) return null

            extractor.selectTrack(audioTrackIndex)
            val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: return null
            var srcSampleRate = trackFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var srcChannels = trackFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(trackFormat, null, null, 0)
            codec.start()

            val leftChunks = ArrayList<FloatArray>()
            val rightChunks = ArrayList<FloatArray>()
            var totalSourceFrames = 0
            var inputDone = false
            var outputDone = false
            val info = MediaCodec.BufferInfo()

            while (!outputDone && totalSourceFrames < MAX_DECODED_FRAMES) {
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)
                        if (inBuf != null) {
                            val sampleSize = extractor.readSampleData(inBuf, 0)
                            if (sampleSize < 0) {
                                codec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(inIdx, 0, sampleSize, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    outIdx >= 0 -> {
                        val outBuf = codec.getOutputBuffer(outIdx)
                        if (outBuf != null && info.size > 0) {
                            outBuf.position(info.offset)
                            outBuf.limit(info.offset + info.size)
                            val shortCount = info.size / 2
                            val frameCount = shortCount / srcChannels.coerceAtLeast(1)
                            if (frameCount > 0) {
                                val cL = FloatArray(frameCount)
                                val cR = FloatArray(frameCount)
                                val shortBuf = outBuf.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                                for (f in 0 until frameCount) {
                                    val sL = shortBuf.get() / 32768f
                                    val sR = if (srcChannels >= 2) shortBuf.get() / 32768f else sL
                                    if (srcChannels > 2) {
                                        for (extra in 2 until srcChannels) shortBuf.get()
                                    }
                                    cL[f] = sL
                                    cR[f] = sR
                                }
                                leftChunks.add(cL)
                                rightChunks.add(cR)
                                totalSourceFrames += frameCount
                            }
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            outputDone = true
                        }
                    }
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val outFmt = codec.outputFormat
                        if (outFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                            srcSampleRate = outFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        }
                        if (outFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                            srcChannels = outFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        }
                    }
                }
            }

            if (totalSourceFrames == 0) return null
            val mergedL = FloatArray(totalSourceFrames)
            val mergedR = FloatArray(totalSourceFrames)
            var offset = 0
            for (idx in leftChunks.indices) {
                val cL = leftChunks[idx]
                val cR = rightChunks[idx]
                System.arraycopy(cL, 0, mergedL, offset, cL.size)
                System.arraycopy(cR, 0, mergedR, offset, cR.size)
                offset += cL.size
            }
            resampleIfNeeded(mergedL, mergedR, srcSampleRate)
        } catch (_: Exception) {
            null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun resampleIfNeeded(srcL: FloatArray, srcR: FloatArray, srcRate: Int): StereoSample {
        if (srcRate == targetSampleRate || srcL.isEmpty()) {
            return StereoSample(srcL, srcR, srcL.size)
        }
        val ratio = srcRate.toDouble() / targetSampleRate.toDouble()
        val outFrames = ((srcL.size / ratio).toInt()).coerceIn(1, MAX_DECODED_FRAMES)
        val outL = FloatArray(outFrames)
        val outR = FloatArray(outFrames)
        val maxIdx = srcL.size - 1

        for (i in 0 until outFrames) {
            val pos = i * ratio
            val idx0 = pos.toInt().coerceIn(0, maxIdx)
            val idx1 = min(idx0 + 1, maxIdx)
            val frac = (pos - idx0).toFloat()
            outL[i] = srcL[idx0] + (srcL[idx1] - srcL[idx0]) * frac
            outR[i] = srcR[idx0] + (srcR[idx1] - srcR[idx0]) * frac
        }
        return StereoSample(outL, outR, outFrames)
    }

    private fun readExact(input: BufferedInputStream, length: Int): ByteArray? {
        val result = ByteArray(length)
        var total = 0
        while (total < length) {
            val read = input.read(result, total, length - total)
            if (read <= 0) return null
            total += read
        }
        return result
    }

    private fun skipExact(input: BufferedInputStream, count: Long) {
        var remaining = count
        while (remaining > 0) {
            val skipped = input.skip(remaining)
            if (skipped <= 0) {
                if (input.read() == -1) break
                remaining--
            } else {
                remaining -= skipped
            }
        }
    }

    companion object {
        private const val MAX_WAV_CHUNK_BYTES = 64 * 1024 * 1024
        private const val MAX_DECODED_FRAMES = 44100 * 30 // up to 30s per pad sample
    }
}
