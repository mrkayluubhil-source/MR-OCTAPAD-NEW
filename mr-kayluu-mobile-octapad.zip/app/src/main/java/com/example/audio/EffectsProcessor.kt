package com.example.audio

import com.example.model.EffectsSettings
import kotlin.math.tanh

/**
 * Real-time stereo DSP effects chain:
 * 1. Equalizer (Bass & Treble shelving filters)
 * 2. Stereo Echo / Delay line with warm low-pass feedback damping
 * 3. Schroeder Stereo Reverb (4 parallel damped comb filters + 2 all-pass diffusers per channel)
 * 4. Master Volume + soft-clipping limiter
 */
class EffectsProcessor(
    private val sampleRate: Int = 44100,
    val equalizerManager: EqualizerManager = EqualizerManager(sampleRate),
) {
    @Volatile
    var currentSettings: EffectsSettings = EffectsSettings()
        private set

    // Delay line up to 1000 ms
    private val maxDelaySamples = sampleRate
    private val delayBufL = FloatArray(maxDelaySamples)
    private val delayBufR = FloatArray(maxDelaySamples)
    private var delayWritePos = 0
    private var delayLpL = 0f
    private var delayLpR = 0f

    // Schroeder Reverb comb buffers (prime-ish lengths scaled for 44.1 kHz)
    private val combDelaysL = intArrayOf(1116, 1188, 1277, 1356)
    private val combDelaysR = intArrayOf(1139, 1211, 1300, 1379)
    private val combBufL = Array(4) { idx -> FloatArray(combDelaysL[idx]) }
    private val combBufR = Array(4) { idx -> FloatArray(combDelaysR[idx]) }
    private val combIdxL = IntArray(4)
    private val combIdxR = IntArray(4)
    private val combFilterL = FloatArray(4)
    private val combFilterR = FloatArray(4)

    // All-pass diffusers
    private val allpassDelaysL = intArrayOf(556, 441)
    private val allpassDelaysR = intArrayOf(579, 464)
    private val allpassBufL = Array(2) { idx -> FloatArray(allpassDelaysL[idx]) }
    private val allpassBufR = Array(2) { idx -> FloatArray(allpassDelaysR[idx]) }
    private val allpassIdxL = IntArray(2)
    private val allpassIdxR = IntArray(2)

    fun updateSettings(settings: EffectsSettings) {
        currentSettings = settings
        equalizerManager.updateEq(settings.bassDb, settings.trebleDb)
    }

    fun clearBuffers() {
        delayBufL.fill(0f)
        delayBufR.fill(0f)
        delayLpL = 0f
        delayLpR = 0f
        for (c in 0 until 4) {
            combBufL[c].fill(0f)
            combBufR[c].fill(0f)
            combFilterL[c] = 0f
            combFilterR[c] = 0f
        }
        for (a in 0 until 2) {
            allpassBufL[a].fill(0f)
            allpassBufR[a].fill(0f)
        }
        equalizerManager.resetState()
    }

    fun processStereoBuffer(left: FloatArray, right: FloatArray, frameCount: Int) {
        val fx = currentSettings

        // 1. EQ (Bass & Treble)
        equalizerManager.processStereoInPlace(left, right, frameCount)

        // 2. Echo / Delay + 3. Reverb + 4. Master Volume
        val echoMix = fx.echoLevel.coerceIn(0f, 1f)
        val delayFrames = ((fx.delayMs.coerceIn(40, 800) / 1000f) * sampleRate).toInt().coerceIn(1, maxDelaySamples - 1)
        val feedback = fx.delayFeedback.coerceIn(0f, 0.78f)
        val reverbMix = fx.reverbLevel.coerceIn(0f, 1f)
        val masterVol = fx.masterVolume.coerceIn(0f, 1.2f)

        val applyDelay = echoMix > 0.005f
        val applyReverb = reverbMix > 0.005f

        val combFeedback = 0.80f
        val damp = 0.25f

        for (i in 0 until frameCount) {
            var dryL = left[i]
            var dryR = right[i]

            // Echo / Delay (ping-pong subtle cross-feed)
            if (applyDelay) {
                var readPos = delayWritePos - delayFrames
                if (readPos < 0) readPos += maxDelaySamples

                val dL = delayBufL[readPos]
                val dR = delayBufR[readPos]

                // Gentle warm low-pass in feedback loop
                delayLpL = delayLpL * 0.35f + dL * 0.65f
                delayLpR = delayLpR * 0.35f + dR * 0.65f

                delayBufL[delayWritePos] = dryL + delayLpR * feedback
                delayBufR[delayWritePos] = dryR + delayLpL * feedback
                delayWritePos++
                if (delayWritePos >= maxDelaySamples) delayWritePos = 0

                dryL += dL * echoMix * 0.75f
                dryR += dR * echoMix * 0.75f
            }

            // Reverb
            if (applyReverb) {
                val reverbIn = (dryL + dryR) * 0.25f
                var outL = 0f
                var outR = 0f

                for (c in 0 until 4) {
                    val bufL = combBufL[c]
                    val idxL = combIdxL[c]
                    val yL = bufL[idxL]
                    combFilterL[c] = yL * (1f - damp) + combFilterL[c] * damp
                    bufL[idxL] = reverbIn + combFilterL[c] * combFeedback
                    combIdxL[c] = if (idxL + 1 >= bufL.size) 0 else idxL + 1
                    outL += yL

                    val bufR = combBufR[c]
                    val idxR = combIdxR[c]
                    val yR = bufR[idxR]
                    combFilterR[c] = yR * (1f - damp) + combFilterR[c] * damp
                    bufR[idxR] = reverbIn + combFilterR[c] * combFeedback
                    combIdxR[c] = if (idxR + 1 >= bufR.size) 0 else idxR + 1
                    outR += yR
                }

                for (a in 0 until 2) {
                    val aBufL = allpassBufL[a]
                    val aIdxL = allpassIdxL[a]
                    val bufOutL = aBufL[aIdxL]
                    val newOutL = -outL + bufOutL
                    aBufL[aIdxL] = outL + bufOutL * 0.5f
                    allpassIdxL[a] = if (aIdxL + 1 >= aBufL.size) 0 else aIdxL + 1
                    outL = newOutL

                    val aBufR = allpassBufR[a]
                    val aIdxR = allpassIdxR[a]
                    val bufOutR = aBufR[aIdxR]
                    val newOutR = -outR + bufOutR
                    aBufR[aIdxR] = outR + bufOutR * 0.5f
                    allpassIdxR[a] = if (aIdxR + 1 >= aBufR.size) 0 else aIdxR + 1
                    outR = newOutR
                }

                dryL = dryL * (1f - reverbMix * 0.35f) + outL * reverbMix * 0.45f
                dryR = dryR * (1f - reverbMix * 0.35f) + outR * reverbMix * 0.45f
            }

            // Master Volume + soft-clipping protection
            val scaledL = dryL * masterVol
            val scaledR = dryR * masterVol
            left[i] = if (scaledL > 0.95f || scaledL < -0.95f) tanh(scaledL.toDouble()).toFloat() else scaledL
            right[i] = if (scaledR > 0.95f || scaledR < -0.95f) tanh(scaledR.toDouble()).toFloat() else scaledR
        }
    }
}
