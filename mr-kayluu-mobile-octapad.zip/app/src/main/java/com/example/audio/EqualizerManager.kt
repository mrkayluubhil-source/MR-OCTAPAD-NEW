package com.example.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Real-time stereo 2-band Biquad Shelving Equalizer (Bass @ 120 Hz, Treble @ 6500 Hz).
 */
class EqualizerManager(private val sampleRate: Int = 44100) {

    private var bassGainDb: Float = 0f
    private var trebleGainDb: Float = 0f

    // Low-shelf coefficients
    private var lb0 = 1f
    private var lb1 = 0f
    private var lb2 = 0f
    private var la1 = 0f
    private var la2 = 0f

    // High-shelf coefficients
    private var hb0 = 1f
    private var hb1 = 0f
    private var hb2 = 0f
    private var ha1 = 0f
    private var ha2 = 0f

    // Stereo filter state (Low-shelf L/R, High-shelf L/R)
    private var lx1L = 0f
    private var lx2L = 0f
    private var ly1L = 0f
    private var ly2L = 0f
    private var lx1R = 0f
    private var lx2R = 0f
    private var ly1R = 0f
    private var ly2R = 0f

    private var hx1L = 0f
    private var hx2L = 0f
    private var hy1L = 0f
    private var hy2L = 0f
    private var hx1R = 0f
    private var hx2R = 0f
    private var hy1R = 0f
    private var hy2R = 0f

    @Synchronized
    fun updateEq(bassDb: Float, trebleDb: Float) {
        val clampedBass = bassDb.coerceIn(-12f, 12f)
        val clampedTreble = trebleDb.coerceIn(-12f, 12f)
        if (clampedBass != bassGainDb) {
            bassGainDb = clampedBass
            computeLowShelf(120.0, bassGainDb.toDouble())
        }
        if (clampedTreble != trebleGainDb) {
            trebleGainDb = clampedTreble
            computeHighShelf(6500.0, trebleGainDb.toDouble())
        }
    }

    @Synchronized
    fun resetState() {
        lx1L = 0f; lx2L = 0f; ly1L = 0f; ly2L = 0f
        lx1R = 0f; lx2R = 0f; ly1R = 0f; ly2R = 0f
        hx1L = 0f; hx2L = 0f; hy1L = 0f; hy2L = 0f
        hx1R = 0f; hx2R = 0f; hy1R = 0f; hy2R = 0f
    }

    @Synchronized
    fun processStereoInPlace(left: FloatArray, right: FloatArray, frameCount: Int) {
        val applyBass = kotlin.math.abs(bassGainDb) > 0.05f
        val applyTreble = kotlin.math.abs(trebleGainDb) > 0.05f
        if (!applyBass && !applyTreble) return

        for (i in 0 until frameCount) {
            var sL = left[i]
            var sR = right[i]

            if (applyBass) {
                val outL = lb0 * sL + lb1 * lx1L + lb2 * lx2L - la1 * ly1L - la2 * ly2L
                lx2L = lx1L; lx1L = sL; ly2L = ly1L; ly1L = outL
                sL = outL

                val outR = lb0 * sR + lb1 * lx1R + lb2 * lx2R - la1 * ly1R - la2 * ly2R
                lx2R = lx1R; lx1R = sR; ly2R = ly1R; ly1R = outR
                sR = outR
            }

            if (applyTreble) {
                val outL = hb0 * sL + hb1 * hx1L + hb2 * hx2L - ha1 * hy1L - ha2 * hy2L
                hx2L = hx1L; hx1L = sL; hy2L = hy1L; hy1L = outL
                sL = outL

                val outR = hb0 * sR + hb1 * hx1R + hb2 * hx2R - ha1 * hy1R - ha2 * hy2R
                hx2R = hx1R; hx1R = sR; hy2R = hy1R; hy1R = outR
                sR = outR
            }

            left[i] = sL
            right[i] = sR
        }
    }

    private fun computeLowShelf(freqHz: Double, gainDb: Double) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2.0 * PI * freqHz / sampleRate
        val cosW0 = cos(w0)
        val sinW0 = sin(w0)
        val alpha = sinW0 / 2.0 * sqrt((a + 1.0 / a) * (1.0 / 0.707 - 1.0) + 2.0)
        val twoSqrtAAlpha = 2.0 * sqrt(a) * alpha

        val a0 = (a + 1.0) + (a - 1.0) * cosW0 + twoSqrtAAlpha
        lb0 = ((a * ((a + 1.0) - (a - 1.0) * cosW0 + twoSqrtAAlpha)) / a0).toFloat()
        lb1 = ((2.0 * a * ((a - 1.0) - (a + 1.0) * cosW0)) / a0).toFloat()
        lb2 = ((a * ((a + 1.0) - (a - 1.0) * cosW0 - twoSqrtAAlpha)) / a0).toFloat()
        la1 = ((-2.0 * ((a - 1.0) + (a + 1.0) * cosW0)) / a0).toFloat()
        la2 = (((a + 1.0) + (a - 1.0) * cosW0 - twoSqrtAAlpha) / a0).toFloat()
    }

    private fun computeHighShelf(freqHz: Double, gainDb: Double) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2.0 * PI * freqHz / sampleRate
        val cosW0 = cos(w0)
        val sinW0 = sin(w0)
        val alpha = sinW0 / 2.0 * sqrt((a + 1.0 / a) * (1.0 / 0.707 - 1.0) + 2.0)
        val twoSqrtAAlpha = 2.0 * sqrt(a) * alpha

        val a0 = (a + 1.0) - (a - 1.0) * cosW0 + twoSqrtAAlpha
        hb0 = ((a * ((a + 1.0) + (a - 1.0) * cosW0 + twoSqrtAAlpha)) / a0).toFloat()
        hb1 = ((-2.0 * a * ((a - 1.0) + (a + 1.0) * cosW0)) / a0).toFloat()
        hb2 = ((a * ((a + 1.0) + (a - 1.0) * cosW0 - twoSqrtAAlpha)) / a0).toFloat()
        ha1 = ((2.0 * ((a - 1.0) - (a + 1.0) * cosW0)) / a0).toFloat()
        ha2 = (((a + 1.0) - (a - 1.0) * cosW0 - twoSqrtAAlpha) / a0).toFloat()
    }
}
