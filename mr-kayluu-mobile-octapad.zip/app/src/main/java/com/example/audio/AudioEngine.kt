package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Process
import com.example.model.EffectsSettings
import com.example.model.OctapadPatch
import com.example.model.PadAssignment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.pow

/**
 * Low-latency polyphonic PCM AudioEngine supporting up to 32 simultaneous pad voices,
 * real-time pitch shifting per pad + master pitch, stereo pan, velocity sensitivity,
 * and full real-time DSP effects (Equalizer + Echo + Delay + Reverb + Master Volume).
 */
class AudioEngine(
    val soundImportManager: SoundImportManager = SoundImportManager(SAMPLE_RATE),
    val effectsProcessor: EffectsProcessor = EffectsProcessor(SAMPLE_RATE),
) {
    private data class VoiceTrigger(
        val sample: StereoSample,
        val gainL: Float,
        val gainR: Float,
        val pitchRatio: Double,
    )

    private class ActiveVoice {
        var active = false
        var sample: StereoSample? = null
        var position = 0.0
        var step = 1.0
        var gainL = 1f
        var gainR = 1f
    }

    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val triggerQueue = ConcurrentLinkedQueue<VoiceTrigger>()
    private val voices = Array(MAX_POLYPHONY) { ActiveVoice() }
    private var nextStealSlot = 0

    @Volatile
    private var isRunning = false
    private var audioThread: Thread? = null

    @Volatile
    private var currentPads: List<PadAssignment> = PadAssignment.defaultPads()

    fun start() {
        if (isRunning) return
        isRunning = true
        audioThread = Thread(::runAudioLoop, "OctapadAudioMixer").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun stop() {
        isRunning = false
        audioThread?.join(400)
        audioThread = null
    }

    fun updateEffects(effects: EffectsSettings) {
        effectsProcessor.updateSettings(effects)
    }

    fun loadPatch(
        activePatch: OctapadPatch?,
        previousPatch: OctapadPatch? = null,
        nextPatch: OctapadPatch? = null,
    ) {
        currentPads = activePatch?.pads ?: PadAssignment.defaultPads()
        if (activePatch != null) {
            effectsProcessor.updateSettings(activePatch.effects)
        }
        // Background warm-cache active patch + adjacent patches for zero-latency switching
        engineScope.launch {
            activePatch?.pads?.forEach { pad ->
                soundImportManager.preloadSample(pad.samplePath)
            }
            previousPatch?.pads?.forEach { pad ->
                soundImportManager.preloadSample(pad.samplePath)
            }
            nextPatch?.pads?.forEach { pad ->
                soundImportManager.preloadSample(pad.samplePath)
            }
        }
    }

    /**
     * Triggers one of the 8 pads immediately without blocking the UI thread.
     * Supports simultaneous multi-finger hits across all 8 pads.
     */
    fun triggerPad(padIndex: Int, velocity: Float = 1.0f) {
        val pad = currentPads.getOrNull(padIndex) ?: return
        val path = pad.samplePath ?: return
        val cached = soundImportManager.getCachedOrDecode(path)
        if (cached != null) {
            enqueueSample(cached, pad, velocity)
        } else {
            engineScope.launch {
                val decoded = soundImportManager.getCachedOrDecode(path) ?: return@launch
                enqueueSample(decoded, pad, velocity)
            }
        }
    }

    /**
     * Previews an audio file directly (used inside Pad Edit Mode's PREVIEW SAMPLE button).
     */
    fun previewSample(samplePath: String?, volume: Float = 1.0f, pitchSemitones: Float = 0.0f) {
        if (samplePath.isNullOrBlank()) return
        engineScope.launch {
            val sample = soundImportManager.getCachedOrDecode(samplePath) ?: return@launch
            val tempPad = PadAssignment(padIndex = 0, samplePath = samplePath, volume = volume, pitchSemitones = pitchSemitones)
            enqueueSample(sample, tempPad, 1.0f)
        }
    }

    private fun enqueueSample(sample: StereoSample, pad: PadAssignment, velocity: Float) {
        if (!isRunning) start()
        val vel = velocity.coerceIn(0.05f, 1.0f)
        val totalGain = (pad.volume * vel).coerceIn(0f, 1.5f)
        val pan = pad.pan.coerceIn(-1f, 1f)
        val gainL = totalGain * (1f - pan.coerceAtLeast(0f))
        val gainR = totalGain * (1f + pan.coerceAtMost(0f))

        val totalSemitones = (pad.pitchSemitones + effectsProcessor.currentSettings.masterPitchSemitones)
            .coerceIn(-24f, 24f)
        val pitchRatio = 2.0.pow(totalSemitones / 12.0)

        triggerQueue.offer(
            VoiceTrigger(
                sample = sample,
                gainL = gainL,
                gainR = gainR,
                pitchRatio = pitchRatio,
            )
        )
    }

    private fun runAudioLoop() {
        runCatching { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO) }

        val minBufBytes = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT,
        ).coerceAtLeast(BUFFER_FRAMES * 4)

        val bufferBytes = minBufBytes.coerceAtMost(BUFFER_FRAMES * 8).coerceAtLeast(BUFFER_FRAMES * 4)

        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        }

        val track = try {
            builder.build()
        } catch (_: Exception) {
            isRunning = false
            return
        }

        val mixL = FloatArray(BUFFER_FRAMES)
        val mixR = FloatArray(BUFFER_FRAMES)
        val pcmOut = ShortArray(BUFFER_FRAMES * 2)

        try {
            track.play()
            while (isRunning) {
                drainTriggerQueue()
                mixL.fill(0f)
                mixR.fill(0f)

                for (v in voices) {
                    if (!v.active) continue
                    val sample = v.sample ?: continue
                    val sL = sample.left
                    val sR = sample.right
                    val maxFrames = sample.frameCount
                    var pos = v.position
                    val step = v.step
                    val gL = v.gainL
                    val gR = v.gainR

                    for (i in 0 until BUFFER_FRAMES) {
                        val idx0 = pos.toInt()
                        if (idx0 >= maxFrames) {
                            v.active = false
                            break
                        }
                        val idx1 = if (idx0 + 1 < maxFrames) idx0 + 1 else idx0
                        val frac = (pos - idx0).toFloat()
                        val interpL = sL[idx0] + (sL[idx1] - sL[idx0]) * frac
                        val interpR = sR[idx0] + (sR[idx1] - sR[idx0]) * frac
                        mixL[i] += interpL * gL
                        mixR[i] += interpR * gR
                        pos += step
                    }
                    if (v.active) {
                        v.position = pos
                    }
                }

                // Process DSP chain (EQ -> Echo/Delay -> Reverb -> Master Volume + Soft Clip)
                effectsProcessor.processStereoBuffer(mixL, mixR, BUFFER_FRAMES)

                for (i in 0 until BUFFER_FRAMES) {
                    val sL = (mixL[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                    val sR = (mixR[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                    pcmOut[i * 2] = sL
                    pcmOut[i * 2 + 1] = sR
                }

                track.write(pcmOut, 0, pcmOut.size)
            }
        } catch (_: Exception) {
            // AudioTrack shutdown safely
        } finally {
            runCatching { track.pause() }
            runCatching { track.flush() }
            runCatching { track.release() }
        }
    }

    private fun drainTriggerQueue() {
        while (true) {
            val trigger = triggerQueue.poll() ?: break
            var target: ActiveVoice? = null
            for (v in voices) {
                if (!v.active) {
                    target = v
                    break
                }
            }
            if (target == null) {
                target = voices[nextStealSlot]
                nextStealSlot = (nextStealSlot + 1) % voices.size
            }
            target.sample = trigger.sample
            target.position = 0.0
            target.step = trigger.pitchRatio
            target.gainL = trigger.gainL
            target.gainR = trigger.gainR
            target.active = true
        }
    }

    companion object {
        const val SAMPLE_RATE = 44100
        const val BUFFER_FRAMES = 256
        const val MAX_POLYPHONY = 32
    }
}
