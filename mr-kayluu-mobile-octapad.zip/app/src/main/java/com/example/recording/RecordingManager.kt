package com.example.recording

import com.example.data.RecordingDao
import com.example.data.RecordingEntity
import com.example.model.OctapadRecording
import com.example.model.RecordedEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class RecordingTransportState {
    IDLE,
    RECORDING,
    PAUSED,
}

data class RecorderUiState(
    val transportState: RecordingTransportState = RecordingTransportState.IDLE,
    val elapsedMs: Long = 0L,
    val capturedEventCount: Int = 0,
    val isPlaying: Boolean = false,
    val activePlayingRecordingId: Long? = null,
    val isLoopingPlayback: Boolean = false,
    val hasUnsavedTakes: Boolean = false,
)

class RecordingManager(private val recordingDao: RecordingDao) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val savedRecordings: Flow<List<OctapadRecording>> =
        recordingDao.observeRecordings().map { list -> list.map { it.toDomain() } }

    private val _state = MutableStateFlow(RecorderUiState())
    val state: StateFlow<RecorderUiState> = _state.asStateFlow()

    private val recordedEvents = mutableListOf<RecordedEvent>()
    private var recordingPatchId: Long = 0L
    private var recordingPatchName: String = ""
    private var segmentStartTimeMs: Long = 0L
    private var accumulatedActiveMs: Long = 0L
    private var timerJob: Job? = null
    private var playbackJob: Job? = null

    fun startRecording(patchId: Long, patchName: String) {
        stopPlayback()
        recordedEvents.clear()
        recordingPatchId = patchId
        recordingPatchName = patchName
        accumulatedActiveMs = 0L
        segmentStartTimeMs = System.currentTimeMillis()
        _state.update {
            it.copy(
                transportState = RecordingTransportState.RECORDING,
                elapsedMs = 0L,
                capturedEventCount = 0,
                hasUnsavedTakes = false,
            )
        }
        startClockTicker()
    }

    fun pauseRecording() {
        if (_state.value.transportState != RecordingTransportState.RECORDING) return
        accumulatedActiveMs += (System.currentTimeMillis() - segmentStartTimeMs).coerceAtLeast(0L)
        timerJob?.cancel()
        _state.update {
            it.copy(
                transportState = RecordingTransportState.PAUSED,
                elapsedMs = accumulatedActiveMs,
            )
        }
    }

    fun resumeRecording() {
        if (_state.value.transportState != RecordingTransportState.PAUSED) return
        segmentStartTimeMs = System.currentTimeMillis()
        _state.update { it.copy(transportState = RecordingTransportState.RECORDING) }
        startClockTicker()
    }

    fun stopRecording() {
        val current = _state.value.transportState
        if (current == RecordingTransportState.IDLE) return
        if (current == RecordingTransportState.RECORDING) {
            accumulatedActiveMs += (System.currentTimeMillis() - segmentStartTimeMs).coerceAtLeast(0L)
        }
        timerJob?.cancel()
        _state.update {
            it.copy(
                transportState = RecordingTransportState.IDLE,
                elapsedMs = accumulatedActiveMs,
                hasUnsavedTakes = recordedEvents.isNotEmpty(),
            )
        }
    }

    fun recordHit(padIndex: Int, velocity: Float, midiNote: Int) {
        if (_state.value.transportState != RecordingTransportState.RECORDING) return
        val currentMs = accumulatedActiveMs + (System.currentTimeMillis() - segmentStartTimeMs).coerceAtLeast(0L)
        recordedEvents.add(
            RecordedEvent(
                padIndex = padIndex,
                timestampMs = currentMs,
                velocity = velocity.coerceIn(0.05f, 1.0f),
                midiNote = midiNote.coerceIn(0, 127),
            )
        )
        _state.update {
            it.copy(
                capturedEventCount = recordedEvents.size,
                elapsedMs = currentMs,
            )
        }
    }

    fun playUnsavedTake(onTriggerPad: (padIndex: Int, velocity: Float) -> Unit) {
        if (recordedEvents.isEmpty()) return
        val take = OctapadRecording(
            id = -1L,
            name = "Current Take",
            patchId = recordingPatchId,
            patchName = recordingPatchName,
            events = recordedEvents.toList(),
            durationMs = accumulatedActiveMs.coerceAtLeast(recordedEvents.last().timestampMs + 250L),
            isLooping = _state.value.isLoopingPlayback,
        )
        playRecording(take, onTriggerPad)
    }

    fun playRecording(
        recording: OctapadRecording,
        onTriggerPad: (padIndex: Int, velocity: Float) -> Unit,
    ) {
        if (_state.value.transportState != RecordingTransportState.IDLE) {
            stopRecording()
        }
        stopPlayback()
        if (recording.events.isEmpty()) return

        _state.update {
            it.copy(
                isPlaying = true,
                activePlayingRecordingId = recording.id,
            )
        }

        playbackJob = scope.launch {
            val sortedEvents = recording.events.sortedBy { it.timestampMs }
            val totalDuration = recording.durationMs.coerceAtLeast((sortedEvents.lastOrNull()?.timestampMs ?: 0L) + 150L)

            do {
                var prevTime = 0L
                for (event in sortedEvents) {
                    if (!isActive) break
                    val delta = (event.timestampMs - prevTime).coerceAtLeast(0L)
                    if (delta > 0L) delay(delta)
                    if (!isActive) break
                    onTriggerPad(event.padIndex, event.velocity)
                    prevTime = event.timestampMs
                }
                val tail = (totalDuration - prevTime).coerceAtLeast(80L)
                if (_state.value.isLoopingPlayback || recording.isLooping) {
                    delay(tail)
                }
            } while (isActive && (_state.value.isLoopingPlayback || recording.isLooping))

            _state.update {
                it.copy(isPlaying = false, activePlayingRecordingId = null)
            }
        }
    }

    fun stopPlayback() {
        playbackJob?.cancel()
        playbackJob = null
        _state.update { it.copy(isPlaying = false, activePlayingRecordingId = null) }
    }

    fun setLoopingPlayback(looping: Boolean) {
        _state.update { it.copy(isLoopingPlayback = looping) }
    }

    suspend fun saveCurrentTake(name: String): Long? {
        if (recordedEvents.isEmpty()) return null
        val finalName = name.trim().ifBlank {
            "Take ${System.currentTimeMillis() % 10000}"
        }
        val duration = accumulatedActiveMs.coerceAtLeast((recordedEvents.lastOrNull()?.timestampMs ?: 0L) + 200L)
        val entity = RecordingEntity.fromDomain(
            OctapadRecording(
                name = finalName,
                patchId = recordingPatchId,
                patchName = recordingPatchName,
                events = recordedEvents.toList(),
                durationMs = duration,
                isLooping = _state.value.isLoopingPlayback,
            )
        )
        val id = recordingDao.insertRecording(entity)
        _state.update { it.copy(hasUnsavedTakes = false) }
        return id
    }

    suspend fun renameRecording(id: Long, newName: String) {
        val clean = newName.trim()
        if (clean.isNotEmpty()) {
            recordingDao.renameRecording(id, clean)
        }
    }

    suspend fun toggleSavedLoop(recording: OctapadRecording) {
        recordingDao.updateLooping(recording.id, !recording.isLooping)
    }

    suspend fun deleteRecording(id: Long) {
        if (_state.value.activePlayingRecordingId == id) {
            stopPlayback()
        }
        recordingDao.deleteRecording(id)
    }

    private fun startClockTicker() {
        timerJob?.cancel()
        timerJob = scope.launch {
            while (isActive && _state.value.transportState == RecordingTransportState.RECORDING) {
                val nowElapsed = accumulatedActiveMs + (System.currentTimeMillis() - segmentStartTimeMs).coerceAtLeast(0L)
                _state.update { it.copy(elapsedMs = nowElapsed) }
                delay(50L)
            }
        }
    }
}
