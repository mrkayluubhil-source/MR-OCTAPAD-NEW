package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioEngine
import com.example.data.OctapadDatabase
import com.example.data.SettingsStore
import com.example.data.StorageManager
import com.example.importer.KitManager
import com.example.importer.PatchManager
import com.example.importer.PhonePatchImporter
import com.example.midi.MidiManager
import com.example.model.ActivePanel
import com.example.model.EffectsSettings
import com.example.model.ImportProgress
import com.example.model.MidiStatus
import com.example.model.OctapadPatch
import com.example.model.OctapadRecording
import com.example.model.PadAssignment
import com.example.model.PatchSourceType
import com.example.recording.RecorderUiState
import com.example.recording.RecordingManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OctapadUiState(
    val patches: List<OctapadPatch> = emptyList(),
    val filteredPatches: List<OctapadPatch> = emptyList(),
    val activePatch: OctapadPatch? = null,
    val workingDraftPatch: OctapadPatch? = null,
    val activePanel: ActivePanel = ActivePanel.PATCH_LIST,
    val isEditMode: Boolean = false,
    val selectedEditPadIndex: Int = 0,
    val searchQuery: String = "",
    val pressedPads: Set<Int> = emptySet(),
    val hitFlashTick: Map<Int, Long> = emptyMap(),
    val effects: EffectsSettings = EffectsSettings(),
    val importProgress: ImportProgress = ImportProgress(),
    val midiStatus: MidiStatus = MidiStatus(),
    val recorderState: RecorderUiState = RecorderUiState(),
    val savedRecordings: List<OctapadRecording> = emptyList(),
    val statusMessage: String? = null,
    val showMyImportedFilter: Boolean = false,
    val pendingDeletePatch: OctapadPatch? = null,
)

class OctapadViewModel(application: Application) : AndroidViewModel(application) {

    private val database = OctapadDatabase.getInstance(application)
    private val storageManager = StorageManager(application)
    private val settingsStore = SettingsStore(application)
    private val patchManager = PatchManager(database.patchDao(), storageManager, settingsStore)
    private val kitManager = KitManager()
    private val phonePatchImporter = PhonePatchImporter(
        context = application,
        storageManager = storageManager,
        patchManager = patchManager,
        kitManager = kitManager,
    )
    val audioEngine = AudioEngine()
    private val recordingManager = RecordingManager(database.recordingDao())
    private val midiManager = MidiManager(application) { incomingNote, velocity ->
        handleIncomingMidiNote(incomingNote, velocity)
    }

    private val _localState = MutableStateFlow(OctapadUiState())
    private var importJob: Job? = null
    private var statusClearJob: Job? = null
    private val padHitReleaseJobs = HashMap<Int, Job>()

    val uiState: StateFlow<OctapadUiState> = combine(
        patchManager.patchesFlow,
        _localState,
        phonePatchImporter.progress,
        midiManager.status,
        recordingManager.state,
        recordingManager.savedRecordings,
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val patches = values[0] as List<OctapadPatch>
        val local = values[1] as OctapadUiState
        val importProgress = values[2] as ImportProgress
        val midiStatus = values[3] as MidiStatus
        val recorderState = values[4] as RecorderUiState
        @Suppress("UNCHECKED_CAST")
        val recordings = values[5] as List<OctapadRecording>

        val resolvedActive = local.activePatch?.let { cur ->
            patches.firstOrNull { it.id == cur.id } ?: patches.firstOrNull()
        } ?: patches.firstOrNull()

        val draft = local.workingDraftPatch ?: resolvedActive
        val query = local.searchQuery.trim()
        val filtered = patches.filter { p ->
            val matchesSearch = query.isEmpty() ||
                p.name.contains(query, ignoreCase = true) ||
                p.formattedNumber == query ||
                p.sourceFolder.contains(query, ignoreCase = true)
            val matchesImportFilter = !local.showMyImportedFilter || p.sourceType != PatchSourceType.USER_CUSTOM
            matchesSearch && matchesImportFilter
        }

        local.copy(
            patches = patches,
            filteredPatches = filtered,
            activePatch = resolvedActive,
            workingDraftPatch = draft,
            importProgress = importProgress,
            midiStatus = midiStatus,
            recorderState = recorderState,
            savedRecordings = recordings,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = OctapadUiState(),
    )

    init {
        audioEngine.start()
        midiManager.start()
        initializePersistentState()
    }

    private fun initializePersistentState() {
        viewModelScope.launch {
            val savedEffects = settingsStore.effectsSettings.first()
            audioEngine.updateEffects(savedEffects)
            val (midiCh, midiIn, midiOut) = settingsStore.midiPreferences.first()
            midiManager.setChannel(midiCh)
            midiManager.setInputEnabled(midiIn)
            midiManager.setOutputEnabled(midiOut)

            _localState.update { it.copy(effects = savedEffects) }

            val existingPatches = patchManager.getAllPatches()
            if (existingPatches.isEmpty()) {
                // Only imports if New Ton 2026.zip is bundled in APK assets; otherwise waits for SAF import
                phonePatchImporter.importBundledArchiveIfPresent()
            }

            val patchesAfterCheck = patchManager.getAllPatches()
            val savedActiveId = settingsStore.activePatchId.first()
            val initialActive = patchesAfterCheck.firstOrNull { it.id == savedActiveId }
                ?: patchesAfterCheck.firstOrNull()

            if (initialActive != null) {
                activatePatchInternal(initialActive, patchesAfterCheck, persistSelection = false)
            }
        }
    }

    // --- Pad Multitouch & Playback ---

    fun onPadPressed(padIndex: Int, velocity: Float = 1.0f) {
        val current = uiState.value
        if (current.isEditMode) {
            // Rule 6: In Edit Mode, pad taps must NOT trigger drum sounds; select pad independently for editing
            _localState.update {
                it.copy(
                    selectedEditPadIndex = padIndex.coerceIn(0, 7),
                    activePanel = ActivePanel.PAD_EDIT,
                )
            }
            return
        }

        // Visual press highlight
        _localState.update {
            it.copy(
                pressedPads = it.pressedPads + padIndex,
                hitFlashTick = it.hitFlashTick + (padIndex to System.nanoTime()),
            )
        }

        triggerPadAudioAndMidi(padIndex, velocity)
    }

    fun onPadReleased(padIndex: Int) {
        _localState.update { it.copy(pressedPads = it.pressedPads - padIndex) }
    }

    private fun triggerPadAudioAndMidi(padIndex: Int, velocity: Float) {
        audioEngine.triggerPad(padIndex, velocity)
        val activePad = (uiState.value.workingDraftPatch ?: uiState.value.activePatch)
            ?.pads?.getOrNull(padIndex)
        val midiNote = activePad?.midiNote ?: PadAssignment.defaultMidiNoteForPad(padIndex)
        midiManager.sendNoteOn(midiNote, velocity)
        recordingManager.recordHit(padIndex, velocity, midiNote)
    }

    private fun handleIncomingMidiNote(note: Int, velocity: Float) {
        val patch = uiState.value.workingDraftPatch ?: uiState.value.activePatch ?: return
        val matchedPads = patch.pads.filter { it.midiNote == note }
        if (matchedPads.isEmpty()) return

        for (pad in matchedPads) {
            audioEngine.triggerPad(pad.padIndex, velocity)
            recordingManager.recordHit(pad.padIndex, velocity, note)
            flashPadTemporarily(pad.padIndex)
        }
    }

    private fun flashPadTemporarily(padIndex: Int) {
        _localState.update {
            it.copy(
                pressedPads = it.pressedPads + padIndex,
                hitFlashTick = it.hitFlashTick + (padIndex to System.nanoTime()),
            )
        }
        padHitReleaseJobs[padIndex]?.cancel()
        padHitReleaseJobs[padIndex] = viewModelScope.launch {
            delay(95L)
            _localState.update { it.copy(pressedPads = it.pressedPads - padIndex) }
        }
    }

    // --- Patch Navigation & Save ---

    fun selectPatch(patch: OctapadPatch) {
        activatePatchInternal(patch, uiState.value.patches, persistSelection = true)
    }

    fun previousPatch() {
        val patches = uiState.value.patches
        if (patches.isEmpty()) return
        val currentId = uiState.value.activePatch?.id
        val prev = kitManager.resolvePreviousPatch(patches, currentId) ?: return
        activatePatchInternal(prev, patches, persistSelection = true)
    }

    fun nextPatch() {
        val patches = uiState.value.patches
        if (patches.isEmpty()) return
        val currentId = uiState.value.activePatch?.id
        val next = kitManager.resolveNextPatch(patches, currentId) ?: return
        activatePatchInternal(next, patches, persistSelection = true)
    }

    fun saveCurrentPatch() {
        viewModelScope.launch {
            val currentEffects = _localState.value.effects
            val draft = uiState.value.workingDraftPatch ?: uiState.value.activePatch
            val toSave = if (draft != null) {
                draft.copy(effects = currentEffects)
            } else {
                OctapadPatch(
                    patchNumber = 0,
                    name = "Custom Kit 1",
                    sourceType = PatchSourceType.USER_CUSTOM,
                    pads = PadAssignment.defaultPads(),
                    effects = currentEffects,
                )
            }
            val saved = patchManager.savePatch(toSave)
            settingsStore.saveEffects(currentEffects)
            _localState.update { it.copy(activePatch = saved, workingDraftPatch = saved) }
            audioEngine.loadPatch(saved)
            showTemporaryStatus("Saved Patch ${saved.formattedNumber}: ${saved.name}")
        }
    }

    private fun activatePatchInternal(
        patch: OctapadPatch,
        allPatches: List<OctapadPatch>,
        persistSelection: Boolean,
    ) {
        val (prev, next) = kitManager.resolveAdjacentPatches(allPatches, patch.id)
        val mergedEffects = _localState.value.effects
        val patchWithFx = patch.copy(effects = mergedEffects)
        _localState.update {
            it.copy(
                activePatch = patchWithFx,
                workingDraftPatch = patchWithFx,
            )
        }
        audioEngine.loadPatch(patchWithFx, prev, next)
        if (persistSelection && patch.id > 0L) {
            viewModelScope.launch { settingsStore.saveActivePatchId(patch.id) }
        }
    }

    // --- Main Control Row Panels (PATCH LOAD | MIDI | EDIT | EFFECTS) & REC ---

    fun openPanel(panel: ActivePanel) {
        when (panel) {
            ActivePanel.PAD_EDIT -> {
                toggleEditMode()
            }
            else -> {
                val nextPanel = if (_localState.value.activePanel == panel && !_localState.value.isEditMode) {
                    ActivePanel.PATCH_LIST
                } else {
                    panel
                }
                _localState.update {
                    it.copy(
                        activePanel = nextPanel,
                        isEditMode = false,
                        showMyImportedFilter = false,
                    )
                }
            }
        }
    }

    fun returnToPatchList() {
        _localState.update {
            it.copy(
                activePanel = ActivePanel.PATCH_LIST,
                isEditMode = false,
                showMyImportedFilter = false,
                pendingDeletePatch = null,
            )
        }
    }

    fun toggleEditMode() {
        val currentlyEditing = _localState.value.isEditMode
        if (currentlyEditing) {
            exitEditMode()
        } else {
            val basePatch = uiState.value.workingDraftPatch ?: uiState.value.activePatch ?: OctapadPatch(
                patchNumber = (uiState.value.patches.size + 1),
                name = "Custom Kit ${uiState.value.patches.size + 1}",
                sourceType = PatchSourceType.USER_CUSTOM,
                pads = PadAssignment.defaultPads(),
                effects = _localState.value.effects,
            )
            _localState.update {
                it.copy(
                    isEditMode = true,
                    activePanel = ActivePanel.PAD_EDIT,
                    workingDraftPatch = basePatch,
                )
            }
        }
    }

    fun exitEditMode() {
        _localState.update {
            it.copy(
                isEditMode = false,
                activePanel = ActivePanel.PATCH_LIST,
            )
        }
    }

    fun selectEditPad(padIndex: Int) {
        _localState.update { it.copy(selectedEditPadIndex = padIndex.coerceIn(0, 7)) }
    }

    // --- Pad Editing Actions ---

    fun assignSampleToSelectedPad(uri: Uri) {
        val padIndex = _localState.value.selectedEditPadIndex
        viewModelScope.launch {
            val result = storageManager.persistUriSample(uri)
            result.onSuccess { file ->
                val basePatch = uiState.value.workingDraftPatch ?: uiState.value.activePatch ?: OctapadPatch(
                    patchNumber = uiState.value.patches.size + 1,
                    name = "Custom Kit ${uiState.value.patches.size + 1}",
                    sourceType = PatchSourceType.USER_CUSTOM,
                    pads = PadAssignment.defaultPads(),
                    effects = _localState.value.effects,
                )
                val updated = kitManager.updatePadInPatch(basePatch, padIndex) { pad ->
                    pad.copy(
                        samplePath = file.absolutePath,
                        sampleName = file.nameWithoutExtension,
                    )
                }
                _localState.update { it.copy(workingDraftPatch = updated) }
                audioEngine.loadPatch(updated)
                audioEngine.previewSample(file.absolutePath, updated.pads[padIndex].volume, updated.pads[padIndex].pitchSemitones)
                showTemporaryStatus("Pad ${padIndex + 1}: ${file.nameWithoutExtension}")
            }.onFailure { err ->
                showTemporaryStatus(err.message ?: "Failed to assign sample")
            }
        }
    }

    fun previewSelectedPadSample() {
        val padIndex = _localState.value.selectedEditPadIndex
        val patch = uiState.value.workingDraftPatch ?: uiState.value.activePatch ?: return
        val pad = patch.pads.getOrNull(padIndex) ?: return
        if (!pad.hasSample) {
            showTemporaryStatus("Pad ${padIndex + 1} has no sample assigned")
            return
        }
        audioEngine.previewSample(pad.samplePath, pad.volume, pad.pitchSemitones)
    }

    fun updateSelectedPadVolume(volume: Float) {
        val padIndex = _localState.value.selectedEditPadIndex
        val patch = uiState.value.workingDraftPatch ?: uiState.value.activePatch ?: return
        val updated = kitManager.updatePadInPatch(patch, padIndex) {
            it.copy(volume = volume.coerceIn(0f, 1.5f))
        }
        _localState.update { it.copy(workingDraftPatch = updated) }
        audioEngine.loadPatch(updated)
    }

    fun updateSelectedPadPitch(pitchSemitones: Float) {
        val padIndex = _localState.value.selectedEditPadIndex
        val patch = uiState.value.workingDraftPatch ?: uiState.value.activePatch ?: return
        val updated = kitManager.updatePadInPatch(patch, padIndex) {
            it.copy(pitchSemitones = pitchSemitones.coerceIn(-12f, 12f))
        }
        _localState.update { it.copy(workingDraftPatch = updated) }
        audioEngine.loadPatch(updated)
    }

    fun updateSelectedPadMidiNote(midiNote: Int) {
        val padIndex = _localState.value.selectedEditPadIndex
        val patch = uiState.value.workingDraftPatch ?: uiState.value.activePatch ?: return
        val updated = kitManager.updatePadInPatch(patch, padIndex) {
            it.copy(midiNote = midiNote.coerceIn(0, 127))
        }
        _localState.update { it.copy(workingDraftPatch = updated) }
        audioEngine.loadPatch(updated)
    }

    fun saveEditedPadPatch() {
        saveCurrentPatch()
    }

    // --- Patch Search, Rename, Delete ---

    fun updateSearchQuery(query: String) {
        _localState.update { it.copy(searchQuery = query) }
    }

    fun toggleMyImportedPatchesView(showImportedOnly: Boolean) {
        _localState.update {
            it.copy(
                activePanel = ActivePanel.PATCH_LIST,
                showMyImportedFilter = showImportedOnly,
            )
        }
    }

    fun renamePatch(patchId: Long, newName: String) {
        viewModelScope.launch {
            patchManager.renamePatch(patchId, newName)
            showTemporaryStatus("Renamed patch to $newName")
        }
    }

    fun requestDeletePatch(patch: OctapadPatch?) {
        _localState.update { it.copy(pendingDeletePatch = patch) }
    }

    fun confirmDeletePatch() {
        val target = _localState.value.pendingDeletePatch ?: return
        _localState.update { it.copy(pendingDeletePatch = null) }
        viewModelScope.launch {
            patchManager.deletePatch(target.id)
            showTemporaryStatus("Deleted patch ${target.formattedNumber}")
        }
    }

    // --- Imports (ZIP, WAV, MP3, JSON, .MCN, Roland SPD-30) ---

    fun importWavSamples(uris: List<Uri>) {
        if (uris.isEmpty()) return
        launchImportJob { phonePatchImporter.importAudioFiles(uris, "WAV") }
    }

    fun importMp3Samples(uris: List<Uri>) {
        if (uris.isEmpty()) return
        launchImportJob { phonePatchImporter.importAudioFiles(uris, "MP3") }
    }

    fun importZipCollection(uri: Uri) {
        launchImportJob { phonePatchImporter.importZipUri(uri) }
    }

    fun importJsonPatchFile(uri: Uri) {
        launchImportJob { phonePatchImporter.importJsonFile(uri) }
    }

    fun importMcnFolderTree(treeUri: Uri) {
        launchImportJob { phonePatchImporter.importDocumentTree(treeUri, expectSpd30 = false) }
    }

    fun importSpd30BackupTree(treeUri: Uri) {
        launchImportJob { phonePatchImporter.importDocumentTree(treeUri, expectSpd30 = true) }
    }

    fun cancelActiveImport() {
        importJob?.cancel()
        importJob = null
    }

    fun dismissImportSummary() {
        phonePatchImporter.resetProgress()
    }

    private fun launchImportJob(block: suspend () -> Unit) {
        importJob?.cancel()
        importJob = viewModelScope.launch {
            block()
            val after = patchManager.getAllPatches()
            if (uiState.value.activePatch == null && after.isNotEmpty()) {
                activatePatchInternal(after.first(), after, persistSelection = true)
            }
        }
    }

    // --- Real-Time Audio Effects ---

    fun updateEffects(transform: (EffectsSettings) -> EffectsSettings) {
        val updated = transform(_localState.value.effects)
        _localState.update { it.copy(effects = updated) }
        audioEngine.updateEffects(updated)
    }

    fun saveEffectsSettings() {
        viewModelScope.launch {
            val fx = _localState.value.effects
            settingsStore.saveEffects(fx)
            val draft = uiState.value.workingDraftPatch ?: uiState.value.activePatch
            if (draft != null && draft.id > 0L) {
                patchManager.savePatch(draft.copy(effects = fx))
            }
            showTemporaryStatus("Effects saved")
        }
    }

    fun resetEffects() {
        val defaults = EffectsSettings()
        _localState.update { it.copy(effects = defaults) }
        audioEngine.updateEffects(defaults)
        viewModelScope.launch { settingsStore.saveEffects(defaults) }
    }

    // --- USB MIDI Controls ---

    fun refreshMidiDevices() = midiManager.refreshDevices()

    fun selectMidiInput(deviceId: Int) = midiManager.selectInputDevice(deviceId)

    fun selectMidiOutput(deviceId: Int) = midiManager.selectOutputDevice(deviceId)

    fun setMidiChannel(channel: Int) {
        midiManager.setChannel(channel)
        viewModelScope.launch {
            val s = uiState.value.midiStatus
            settingsStore.saveMidiPreferences(channel, s.isInputEnabled, s.isOutputEnabled)
        }
    }

    fun setMidiInputEnabled(enabled: Boolean) {
        midiManager.setInputEnabled(enabled)
        viewModelScope.launch {
            val s = uiState.value.midiStatus
            settingsStore.saveMidiPreferences(s.midiChannel, enabled, s.isOutputEnabled)
        }
    }

    fun setMidiOutputEnabled(enabled: Boolean) {
        midiManager.setOutputEnabled(enabled)
        viewModelScope.launch {
            val s = uiState.value.midiStatus
            settingsStore.saveMidiPreferences(s.midiChannel, s.isInputEnabled, enabled)
        }
    }

    // --- Recording System ---

    fun startRecording() {
        val active = uiState.value.activePatch
        recordingManager.startRecording(
            patchId = active?.id ?: 0L,
            patchName = active?.name ?: "Custom Kit",
        )
    }

    fun pauseRecording() = recordingManager.pauseRecording()

    fun resumeRecording() = recordingManager.resumeRecording()

    fun stopRecording() = recordingManager.stopRecording()

    fun playCurrentTake() {
        recordingManager.playUnsavedTake { padIdx, vel ->
            flashPadTemporarily(padIdx)
            triggerPadAudioAndMidi(padIdx, vel)
        }
    }

    fun playSavedRecording(recording: OctapadRecording) {
        recordingManager.playRecording(recording) { padIdx, vel ->
            flashPadTemporarily(padIdx)
            triggerPadAudioAndMidi(padIdx, vel)
        }
    }

    fun stopRecordingPlayback() = recordingManager.stopPlayback()

    fun setLoopPlayback(looping: Boolean) = recordingManager.setLoopingPlayback(looping)

    fun saveCurrentTake(name: String) {
        viewModelScope.launch {
            val id = recordingManager.saveCurrentTake(name)
            if (id != null) {
                showTemporaryStatus("Recording saved")
            }
        }
    }

    fun renameRecording(id: Long, newName: String) {
        viewModelScope.launch { recordingManager.renameRecording(id, newName) }
    }

    fun toggleSavedRecordingLoop(recording: OctapadRecording) {
        viewModelScope.launch { recordingManager.toggleSavedLoop(recording) }
    }

    fun deleteRecording(id: Long) {
        viewModelScope.launch { recordingManager.deleteRecording(id) }
    }

    private fun showTemporaryStatus(msg: String) {
        _localState.update { it.copy(statusMessage = msg) }
        statusClearJob?.cancel()
        statusClearJob = viewModelScope.launch {
            delay(2600L)
            _localState.update { it.copy(statusMessage = null) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.stop()
        midiManager.stop()
        recordingManager.stopPlayback()
    }
}
