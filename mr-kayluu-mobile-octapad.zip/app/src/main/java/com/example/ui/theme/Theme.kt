package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val OctapadColorScheme = darkColorScheme(
    primary = PadGlowCyan,
    onPrimary = Color(0xFF041326),
    primaryContainer = LcdBlueMid,
    onPrimaryContainer = LcdTextPrimary,
    secondary = PadEditAmber,
    onSecondary = Color(0xFF1F1400),
    secondaryContainer = PadEditAmberBg,
    onSecondaryContainer = PadEditAmber,
    tertiary = LedGreen,
    background = ChassisBezelDark,
    onBackground = LcdTextPrimary,
    surface = GlossPanelMid,
    onSurface = LcdTextPrimary,
    surfaceVariant = HardwareButtonTop,
    onSurfaceVariant = LcdTextSecondary,
    outline = LcdBorderGlow,
    error = LedRed,
    onError = Color.White,
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = OctapadColorScheme,
        typography = Typography,
        content = content,
    )
}
