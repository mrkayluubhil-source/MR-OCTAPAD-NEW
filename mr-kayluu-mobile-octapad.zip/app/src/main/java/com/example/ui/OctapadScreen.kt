package com.example.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.ActivePanel
import com.example.model.PadAssignment
import com.example.viewmodel.OctapadViewModel

@Composable
fun OctapadScreen(
    viewModel: OctapadViewModel,
    modifier: Modifier = Modifier,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    // Real Android Storage Access Framework (SAF) Launchers
    val wavPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) viewModel.importWavSamples(uris)
    }

    val mp3PickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) viewModel.importMp3Samples(uris)
    }

    val zipPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) viewModel.importZipCollection(uri)
    }

    val jsonPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) viewModel.importJsonPatchFile(uri)
    }

    val mcnFolderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) viewModel.importMcnFolderTree(treeUri)
    }

    val spd30FolderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) viewModel.importSpd30BackupTree(treeUri)
    }

    val singlePadSamplePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) viewModel.assignSampleToSelectedPad(uri)
    }

    // Back press closes active sub-panel or Edit Mode back to permanent Patch List
    BackHandler(enabled = state.activePanel != ActivePanel.PATCH_LIST || state.isEditMode) {
        viewModel.returnToPatchList()
    }

    val displayPads = (state.workingDraftPatch ?: state.activePatch)?.pads ?: PadAssignment.defaultPads()

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0D12))
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(6.dp)
            .testTag("octapad_root"),
    ) {
        val outerPadding = if (maxWidth < 720.dp) 4.dp else 8.dp
        val padSectionWeight = if (maxWidth < 680.dp) 0.58f else 0.63f
        val controlSectionWeight = 1f - padSectionWeight

        SilverHardwareBody(
            modifier = Modifier.fillMaxSize(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(outerPadding),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                // Left Hardware Section: Brand Trim + 8 Large Dark Drum Pads (4x2)
                Column(
                    modifier = Modifier
                        .weight(padSectionWeight)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    OctapadBrandHeader()
                    RecessedPadBay(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize(),
                    ) {
                        OctapadPadGrid(
                            pads = displayPads,
                            pressedPads = state.pressedPads,
                            isEditMode = state.isEditMode,
                            selectedEditPadIndex = state.selectedEditPadIndex,
                            onPadPressed = viewModel::onPadPressed,
                            onPadReleased = viewModel::onPadReleased,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }

                // Right Hardware Section: Black Glossy Control Panel + Blue LCD + Controls
                ControlPanel(
                    state = state,
                    onSelectPatch = viewModel::selectPatch,
                    onPreviousPatch = viewModel::previousPatch,
                    onSavePatch = viewModel::saveCurrentPatch,
                    onNextPatch = viewModel::nextPatch,
                    onOpenPanel = viewModel::openPanel,
                    onReturnToPatchList = viewModel::returnToPatchList,
                    onSearchQueryChange = viewModel::updateSearchQuery,
                    onRenamePatch = viewModel::renamePatch,
                    onRequestDeletePatch = viewModel::requestDeletePatch,
                    onConfirmDeletePatch = viewModel::confirmDeletePatch,
                    onShowMyImportedPatches = { viewModel.toggleMyImportedPatchesView(true) },
                    onPickWavSamples = {
                        wavPickerLauncher.launch(arrayOf("audio/wav", "audio/x-wav", "audio/wave", "audio/*"))
                    },
                    onPickMp3Samples = {
                        mp3PickerLauncher.launch(arrayOf("audio/mpeg", "audio/mp3", "audio/ogg", "audio/*"))
                    },
                    onPickZipCollection = {
                        zipPickerLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*"))
                    },
                    onPickJsonFile = {
                        jsonPickerLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                    },
                    onPickMcnFolder = {
                        mcnFolderPickerLauncher.launch(null)
                    },
                    onPickSpd30Backup = {
                        spd30FolderPickerLauncher.launch(null)
                    },
                    onCancelImport = viewModel::cancelActiveImport,
                    onDismissImportSummary = viewModel::dismissImportSummary,
                    onSelectEditPad = viewModel::selectEditPad,
                    onPickPadSample = {
                        singlePadSamplePickerLauncher.launch(arrayOf("audio/*", "audio/wav", "audio/mpeg", "audio/ogg"))
                    },
                    onPreviewPadSample = viewModel::previewSelectedPadSample,
                    onPadVolumeChange = viewModel::updateSelectedPadVolume,
                    onPadPitchChange = viewModel::updateSelectedPadPitch,
                    onPadMidiNoteChange = viewModel::updateSelectedPadMidiNote,
                    onSaveEditedPad = viewModel::saveEditedPadPatch,
                    onDoneEditMode = viewModel::exitEditMode,
                    onEffectsChange = viewModel::updateEffects,
                    onSaveEffects = viewModel::saveEffectsSettings,
                    onResetEffects = viewModel::resetEffects,
                    onRefreshMidi = viewModel::refreshMidiDevices,
                    onSelectMidiInput = viewModel::selectMidiInput,
                    onSelectMidiOutput = viewModel::selectMidiOutput,
                    onSetMidiChannel = viewModel::setMidiChannel,
                    onToggleMidiInput = viewModel::setMidiInputEnabled,
                    onToggleMidiOutput = viewModel::setMidiOutputEnabled,
                    onStartRecording = viewModel::startRecording,
                    onPauseRecording = viewModel::pauseRecording,
                    onResumeRecording = viewModel::resumeRecording,
                    onStopRecording = viewModel::stopRecording,
                    onPlayCurrentTake = viewModel::playCurrentTake,
                    onStopPlayback = viewModel::stopRecordingPlayback,
                    onLoopToggle = viewModel::setLoopPlayback,
                    onSaveTake = viewModel::saveCurrentTake,
                    onPlaySavedRecording = viewModel::playSavedRecording,
                    onRenameRecording = viewModel::renameRecording,
                    onToggleSavedLoop = viewModel::toggleSavedRecordingLoop,
                    onDeleteRecording = viewModel::deleteRecording,
                    modifier = Modifier.weight(controlSectionWeight),
                )
            }
        }
    }
}
