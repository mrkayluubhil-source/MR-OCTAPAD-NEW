package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChassisBezelDark
import com.example.ui.theme.ChassisEdgeHighlight
import com.example.ui.theme.ChassisSilverDark
import com.example.ui.theme.ChassisSilverLight
import com.example.ui.theme.ChassisSilverMid
import com.example.ui.theme.HardwareButtonActiveBottom
import com.example.ui.theme.HardwareButtonActiveTop
import com.example.ui.theme.HardwareButtonBottom
import com.example.ui.theme.HardwareButtonTop
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LcdBlueBottom
import com.example.ui.theme.LcdBlueMid
import com.example.ui.theme.LcdBlueTop
import com.example.ui.theme.LcdBorderGlow
import com.example.ui.theme.LcdTextPrimary
import com.example.ui.theme.LcdTextSecondary
import com.example.ui.theme.LedAmber
import com.example.ui.theme.LedCyan
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.PadGlowCyan

@Composable
fun HardwareScrew(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(9.dp)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(listOf(Color(0xFF8C97A4), Color(0xFF424B57)))
            )
            .border(0.75.dp, Color(0xFF282E36), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.65f)
                .height(1.dp)
                .background(Color(0xFF20242A))
        )
    }
}

@Composable
fun OctapadBrandHeader(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            HardwareScrew()
            Text(
                text = "MR KAYLUU",
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                letterSpacing = 1.6.sp,
                color = Color(0xFF1A222D),
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF18202B))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            ) {
                Text(
                    text = "MR OCTAPAD",
                    fontFamily = OrbitronFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    letterSpacing = 1.sp,
                    color = PadGlowCyan,
                )
            }
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = "8-PAD PERCUSSION WORKSTATION",
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 8.sp,
                letterSpacing = 0.8.sp,
                color = Color(0xFF475464),
            )
            HardwareScrew()
        }
    }
}

@Composable
fun SilverHardwareBody(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(ChassisSilverLight, ChassisSilverMid, ChassisSilverDark)
                )
            )
            .border(1.5.dp, ChassisEdgeHighlight.copy(alpha = 0.8f), RoundedCornerShape(14.dp))
            .padding(6.dp),
    ) {
        content()
    }
}

@Composable
fun RecessedPadBay(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(11.dp))
            .background(ChassisBezelDark)
            .border(1.5.dp, Color(0xFF394452), RoundedCornerShape(11.dp))
            .padding(7.dp),
    ) {
        content()
    }
}

@Composable
fun BlueLcdScreenContainer(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(LcdBlueTop, LcdBlueMid, LcdBlueBottom)
                )
            )
            .border(1.8.dp, LcdBorderGlow.copy(alpha = 0.85f), RoundedCornerShape(8.dp))
            .padding(7.dp),
    ) {
        content()
    }
}

/**
 * Strictly icon-only hardware button used for Previous (⏪), Save (💾), Next (⏩).
 * Contains NO text, NO captions, and NO labels beside the icon.
 */
@Composable
fun IconOnlyHardwareButton(
    icon: ImageVector,
    contentDescription: String,
    testTag: String,
    accentColor: Color = PadGlowCyan,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(7.dp)
    Box(
        modifier = modifier
            .testTag(testTag)
            .minimumInteractiveComponentSize()
            .defaultMinSize(minHeight = 42.dp)
            .clip(shape)
            .background(
                Brush.verticalGradient(listOf(HardwareButtonTop, HardwareButtonBottom))
            )
            .border(1.2.dp, accentColor.copy(alpha = 0.65f), shape)
            .clickable(role = Role.Button, onClickLabel = contentDescription, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = accentColor,
            modifier = Modifier.size(22.dp),
        )
    }
}

/**
 * Hardware button for the 4 main controls: PATCH LOAD | MIDI | EDIT | EFFECTS
 */
@Composable
fun MainControlButton(
    label: String,
    isActive: Boolean,
    isWarningLed: Boolean = false,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(7.dp)
    val ledColor = when {
        isActive && isWarningLed -> LedAmber
        isActive -> LedCyan
        else -> Color(0xFF333D4B)
    }
    Box(
        modifier = modifier
            .testTag(testTag)
            .minimumInteractiveComponentSize()
            .defaultMinSize(minHeight = 44.dp)
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    if (isActive) listOf(HardwareButtonActiveTop, HardwareButtonActiveBottom)
                    else listOf(HardwareButtonTop, HardwareButtonBottom)
                )
            )
            .border(
                width = if (isActive) 1.5.dp else 1.dp,
                color = if (isActive) ledColor else Color(0xFF434E5E),
                shape = shape,
            )
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.55f)
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(ledColor)
            )
            Text(
                text = label,
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (isActive) Color.White else Color(0xFFD0DAE5),
            )
        }
    }
}

@Composable
fun LcdCompactButton(
    text: String,
    isPrimary: Boolean = false,
    tint: Color = PadGlowCyan,
    testTag: String? = null,
    enabled: Boolean = true,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(5.dp)
    val mod = if (testTag != null) modifier.testTag(testTag) else modifier
    Box(
        modifier = mod
            .defaultMinSize(minHeight = 32.dp)
            .clip(shape)
            .background(
                if (!enabled) Color(0xFF142844)
                else if (isPrimary) tint
                else Color(0xFF0E3E7A)
            )
            .border(1.dp, tint.copy(alpha = if (enabled) 0.75f else 0.3f), shape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = if (!enabled) Color(0xFF6B8BB3)
            else if (isPrimary) Color(0xFF041326)
            else LcdTextPrimary,
        )
    }
}

@Composable
fun LcdParamSlider(
    label: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = label,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = LcdTextSecondary,
            )
            Text(
                text = valueText,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = LcdTextPrimary,
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = PadGlowCyan,
                activeTrackColor = PadGlowCyan,
                inactiveTrackColor = Color(0xFF17457E),
            ),
            modifier = Modifier.height(26.dp),
        )
    }
}
