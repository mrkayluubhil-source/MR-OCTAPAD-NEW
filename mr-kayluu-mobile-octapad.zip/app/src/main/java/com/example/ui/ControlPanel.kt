package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActivePanel
import com.example.model.EffectsSettings
import com.example.model.ImportProgress
import com.example.model.MidiStatus
import com.example.model.OctapadPatch
import com.example.model.OctapadRecording
import com.example.model.PadAssignment
import com.example.model.gmDrumName
import com.example.recording.RecorderUiState
import com.example.recording.RecordingTransportState
import com.example.ui.theme.GlossPanelBottom
import com.example.ui.theme.GlossPanelMid
import com.example.ui.theme.GlossPanelTop
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LcdHighlightBg
import com.example.ui.theme.LcdHighlightText
import com.example.ui.theme.LcdTextPrimary
import com.example.ui.theme.LcdTextSecondary
import com.example.ui.theme.LedAmber
import com.example.ui.theme.LedGreen
import com.example.ui.theme.LedRed
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.PadEditAmber
import com.example.ui.theme.PadGlowCyan
import com.example.viewmodel.OctapadUiState
import java.util.Locale

@Composable
fun ControlPanel(
    state: OctapadUiState,
    onSelectPatch: (OctapadPatch) -> Unit,
    onPreviousPatch: () -> Unit,
    onSavePatch: () -> Unit,
    onNextPatch: () -> Unit,
    onOpenPanel: (ActivePanel) -> Unit,
    onReturnToPatchList: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onRenamePatch: (Long, String) -> Unit,
    onRequestDeletePatch: (OctapadPatch?) -> Unit,
    onConfirmDeletePatch: () -> Unit,
    onShowMyImportedPatches: () -> Unit,
    // Patch Load Pickers
    onPickWavSamples: () -> Unit,
    onPickMp3Samples: () -> Unit,
    onPickZipCollection: () -> Unit,
    onPickJsonFile: () -> Unit,
    onPickMcnFolder: () -> Unit,
    onPickSpd30Backup: () -> Unit,
    onCancelImport: () -> Unit,
    onDismissImportSummary: () -> Unit,
    // Edit Mode
    onSelectEditPad: (Int) -> Unit,
    onPickPadSample: () -> Unit,
    onPreviewPadSample: () -> Unit,
    onPadVolumeChange: (Float) -> Unit,
    onPadPitchChange: (Float) -> Unit,
    onPadMidiNoteChange: (Int) -> Unit,
    onSaveEditedPad: () -> Unit,
    onDoneEditMode: () -> Unit,
    // Effects
    onEffectsChange: ((EffectsSettings) -> EffectsSettings) -> Unit,
    onSaveEffects: () -> Unit,
    onResetEffects: () -> Unit,
    // MIDI
    onRefreshMidi: () -> Unit,
    onSelectMidiInput: (Int) -> Unit,
    onSelectMidiOutput: (Int) -> Unit,
    onSetMidiChannel: (Int) -> Unit,
    onToggleMidiInput: (Boolean) -> Unit,
    onToggleMidiOutput: (Boolean) -> Unit,
    // Recording
    onStartRecording: () -> Unit,
    onPauseRecording: () -> Unit,
    onResumeRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onPlayCurrentTake: () -> Unit,
    onStopPlayback: () -> Unit,
    onLoopToggle: (Boolean) -> Unit,
    onSaveTake: (String) -> Unit,
    onPlaySavedRecording: (OctapadRecording) -> Unit,
    onRenameRecording: (Long, String) -> Unit,
    onToggleSavedLoop: (OctapadRecording) -> Unit,
    onDeleteRecording: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.verticalGradient(listOf(GlossPanelTop, GlossPanelMid, GlossPanelBottom))
            )
            .border(1.2.dp, Color(0xFF2D3542), RoundedCornerShape(12.dp))
            .padding(8.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            // 1. Hardware Header Bar: Current Patch # (NO leading zeros) + Name + USB MIDI LED + REC button
            HardwarePanelTopBar(
                activePatch = state.activePatch,
                totalPatches = state.patches.size,
                midiStatus = state.midiStatus,
                recorderState = state.recorderState,
                isRecPanelOpen = state.activePanel == ActivePanel.RECORDING,
                statusMessage = state.statusMessage,
                onToggleRecPanel = { onOpenPanel(ActivePanel.RECORDING) },
            )

            // 2. Permanent Blue Backlit Hardware LCD Display
            BlueLcdScreenContainer(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("hardware_lcd_display"),
            ) {
                when (state.activePanel) {
                    ActivePanel.PATCH_LIST -> LcdPatchListContent(
                        state = state,
                        onSelectPatch = onSelectPatch,
                        onSearchQueryChange = onSearchQueryChange,
                        onRenamePatch = onRenamePatch,
                        onRequestDeletePatch = onRequestDeletePatch,
                        onConfirmDeletePatch = onConfirmDeletePatch,
                        onClearImportedFilter = { onOpenPanel(ActivePanel.PATCH_LIST) },
                        onOpenPatchLoad = { onOpenPanel(ActivePanel.PATCH_LOAD) },
                    )
                    ActivePanel.PATCH_LOAD -> LcdPatchLoadContent(
                        progress = state.importProgress,
                        patchCount = state.patches.size,
                        onBackToList = onReturnToPatchList,
                        onPickWavSamples = onPickWavSamples,
                        onPickMp3Samples = onPickMp3Samples,
                        onPickZipCollection = onPickZipCollection,
                        onPickJsonFile = onPickJsonFile,
                        onPickMcnFolder = onPickMcnFolder,
                        onPickSpd30Backup = onPickSpd30Backup,
                        onShowMyImportedPatches = onShowMyImportedPatches,
                        onCancelImport = onCancelImport,
                        onDismissImportSummary = onDismissImportSummary,
                    )
                    ActivePanel.MIDI -> LcdMidiContent(
                        midiStatus = state.midiStatus,
                        onBackToList = onReturnToPatchList,
                        onRefreshMidi = onRefreshMidi,
                        onSelectMidiInput = onSelectMidiInput,
                        onSelectMidiOutput = onSelectMidiOutput,
                        onSetMidiChannel = onSetMidiChannel,
                        onToggleMidiInput = onToggleMidiInput,
                        onToggleMidiOutput = onToggleMidiOutput,
                    )
                    ActivePanel.PAD_EDIT -> LcdPadEditContent(
                        draftPatch = state.workingDraftPatch ?: state.activePatch,
                        selectedPadIndex = state.selectedEditPadIndex,
                        onSelectPad = onSelectEditPad,
                        onAddOrChangeSample = onPickPadSample,
                        onPreviewSample = onPreviewPadSample,
                        onVolumeChange = onPadVolumeChange,
                        onPitchChange = onPadPitchChange,
                        onMidiNoteChange = onPadMidiNoteChange,
                        onSave = onSaveEditedPad,
                        onDone = onDoneEditMode,
                    )
                    ActivePanel.EFFECTS -> LcdEffectsContent(
                        effects = state.effects,
                        onBackToList = onReturnToPatchList,
                        onEffectsChange = onEffectsChange,
                        onSaveEffects = onSaveEffects,
                        onResetEffects = onResetEffects,
                    )
                    ActivePanel.RECORDING -> LcdRecordingContent(
                        recorderState = state.recorderState,
                        recordings = state.savedRecordings,
                        onBackToList = onReturnToPatchList,
                        onStartRecording = onStartRecording,
                        onPauseRecording = onPauseRecording,
                        onResumeRecording = onResumeRecording,
                        onStopRecording = onStopRecording,
                        onPlayCurrentTake = onPlayCurrentTake,
                        onStopPlayback = onStopPlayback,
                        onLoopToggle = onLoopToggle,
                        onSaveTake = onSaveTake,
                        onPlaySavedRecording = onPlaySavedRecording,
                        onRenameRecording = onRenameRecording,
                        onToggleSavedLoop = onToggleSavedLoop,
                        onDeleteRecording = onDeleteRecording,
                    )
                }
            }

            // 3. STRICT RULE: Icon-Only Navigation & Save Row (ONLY ⏪ 💾 ⏩ — ZERO text!)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("patch_nav_icon_row"),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                IconOnlyHardwareButton(
                    icon = Icons.Filled.FastRewind,
                    contentDescription = "Previous Patch",
                    testTag = "btn_prev_patch",
                    accentColor = PadGlowCyan,
                    onClick = onPreviousPatch,
                    modifier = Modifier.weight(1f),
                )
                IconOnlyHardwareButton(
                    icon = Icons.Filled.Save,
                    contentDescription = "Save Patch",
                    testTag = "btn_save_patch",
                    accentColor = LedGreen,
                    onClick = onSavePatch,
                    modifier = Modifier.weight(1f),
                )
                IconOnlyHardwareButton(
                    icon = Icons.Filled.FastForward,
                    contentDescription = "Next Patch",
                    testTag = "btn_next_patch",
                    accentColor = PadGlowCyan,
                    onClick = onNextPatch,
                    modifier = Modifier.weight(1f),
                )
            }

            // 4. STRICT RULE: Exactly 4 Main Control Buttons in exact order: PATCH LOAD | MIDI | EDIT | EFFECTS
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("main_control_row"),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                MainControlButton(
                    label = "PATCH LOAD",
                    isActive = state.activePanel == ActivePanel.PATCH_LOAD,
                    testTag = "btn_patch_load",
                    onClick = { onOpenPanel(ActivePanel.PATCH_LOAD) },
                    modifier = Modifier.weight(1f),
                )
                MainControlButton(
                    label = "MIDI",
                    isActive = state.activePanel == ActivePanel.MIDI,
                    testTag = "btn_midi",
                    onClick = { onOpenPanel(ActivePanel.MIDI) },
                    modifier = Modifier.weight(1f),
                )
                MainControlButton(
                    label = "EDIT",
                    isActive = state.isEditMode,
                    isWarningLed = true,
                    testTag = "btn_edit",
                    onClick = { onOpenPanel(ActivePanel.PAD_EDIT) },
                    modifier = Modifier.weight(1f),
                )
                MainControlButton(
                    label = "EFFECTS",
                    isActive = state.activePanel == ActivePanel.EFFECTS,
                    testTag = "btn_effects",
                    onClick = { onOpenPanel(ActivePanel.EFFECTS) },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun HardwarePanelTopBar(
    activePatch: OctapadPatch?,
    totalPatches: Int,
    midiStatus: MidiStatus,
    recorderState: RecorderUiState,
    isRecPanelOpen: Boolean,
    statusMessage: String?,
    onToggleRecPanel: () -> Unit,
) {
    val isMidiConnected = midiStatus.isInputConnected || midiStatus.isOutputConnected
    val isRecording = recorderState.transportState == RecordingTransportState.RECORDING

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            val headerText = statusMessage ?: if (activePatch != null) {
                "${activePatch.formattedNumber}  ${activePatch.name}"
            } else {
                "NO PATCH LOADED ($totalPatches)"
            }
            Text(
                text = headerText,
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (statusMessage != null) LedGreen else PadGlowCyan,
                modifier = Modifier.testTag("current_patch_display"),
            )
            Text(
                text = if (activePatch != null) {
                    "PATCH ${activePatch.formattedNumber}/$totalPatches • ${activePatch.assignedPadCount}/8 PADS"
                } else {
                    "LIBRARY: $totalPatches PATCHES"
                },
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 9.sp,
                color = Color(0xFF7D92AC),
                maxLines = 1,
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            // Real USB MIDI Hardware Indicator
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF141922))
                    .border(
                        1.dp,
                        if (isMidiConnected) LedGreen else Color(0xFF2D3644),
                        RoundedCornerShape(4.dp),
                    )
                    .padding(horizontal = 5.dp, vertical = 3.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Usb,
                        contentDescription = if (isMidiConnected) "USB MIDI Connected" else "USB MIDI Disconnected",
                        tint = if (isMidiConnected) LedGreen else Color(0xFF566374),
                        modifier = Modifier.size(12.dp),
                    )
                    Text(
                        text = if (isMidiConnected) "MIDI" else "NO MIDI",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isMidiConnected) LedGreen else Color(0xFF6B7788),
                    )
                }
            }

            // Compact REC hardware button
            Box(
                modifier = Modifier
                    .testTag("btn_rec_panel")
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        when {
                            isRecording -> Color(0xFF4F0E19)
                            isRecPanelOpen -> Color(0xFF193C66)
                            else -> Color(0xFF1D232D)
                        }
                    )
                    .border(
                        1.dp,
                        when {
                            isRecording -> LedRed
                            isRecPanelOpen -> PadGlowCyan
                            else -> Color(0xFF424C5C)
                        },
                        RoundedCornerShape(4.dp),
                    )
                    .clickable(onClick = onToggleRecPanel)
                    .padding(horizontal = 6.dp, vertical = 3.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.FiberManualRecord,
                        contentDescription = "Recorder",
                        tint = if (isRecording) LedRed else Color(0xFFFF6E7F),
                        modifier = Modifier.size(10.dp),
                    )
                    Text(
                        text = "REC",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        color = Color.White,
                    )
                }
            }
        }
    }
}

@Composable
private fun LcdPatchListContent(
    state: OctapadUiState,
    onSelectPatch: (OctapadPatch) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onRenamePatch: (Long, String) -> Unit,
    onRequestDeletePatch: (OctapadPatch?) -> Unit,
    onConfirmDeletePatch: () -> Unit,
    onClearImportedFilter: () -> Unit,
    onOpenPatchLoad: () -> Unit,
) {
    var renamingPatch by remember { mutableStateOf<OctapadPatch?>(null) }
    var renameText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val activeIdx = remember(state.filteredPatches, state.activePatch?.id) {
        state.filteredPatches.indexOfFirst { it.id == state.activePatch?.id }
    }
    LaunchedEffect(state.activePatch?.id) {
        if (activeIdx >= 0) {
            listState.animateScrollToItem(activeIdx)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("lcd_patch_list"),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        // Search Bar + Count Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF062147))
                    .border(1.dp, Color(0xFF286BB8), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = "Search Patches",
                    tint = LcdTextSecondary,
                    modifier = Modifier.size(13.dp),
                )
                Spacer(Modifier.width(4.dp))
                Box(modifier = Modifier.weight(1f)) {
                    if (state.searchQuery.isEmpty()) {
                        Text(
                            text = if (state.showMyImportedFilter) "Filter imported..." else "Search patches...",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = LcdTextSecondary.copy(alpha = 0.6f),
                        )
                    }
                    BasicTextField(
                        value = state.searchQuery,
                        onValueChange = onSearchQueryChange,
                        singleLine = true,
                        textStyle = TextStyle(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = LcdTextPrimary,
                        ),
                        cursorBrush = SolidColor(PadGlowCyan),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("patch_search_input"),
                    )
                }
                if (state.searchQuery.isNotEmpty()) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Clear Search",
                        tint = LcdTextSecondary,
                        modifier = Modifier
                            .size(13.dp)
                            .clickable { onSearchQueryChange("") },
                    )
                }
            }

            if (state.showMyImportedFilter) {
                LcdCompactButton(
                    text = "ALL",
                    tint = PadGlowCyan,
                    onClick = onClearImportedFilter,
                )
            }
            Text(
                text = "${state.filteredPatches.size}",
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = LcdTextSecondary,
            )
        }

        // Inline Delete Confirmation Banner inside LCD
        state.pendingDeletePatch?.let { target ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF4A101D))
                    .border(1.dp, LedRed, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "Delete ${target.formattedNumber} ${target.name}?",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 9.sp,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    LcdCompactButton(text = "DEL", isPrimary = true, tint = LedRed, onClick = onConfirmDeletePatch)
                    LcdCompactButton(text = "NO", onClick = { onRequestDeletePatch(null) })
                }
            }
        }

        // Inline Rename Banner inside LCD
        renamingPatch?.let { target ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF0A326A))
                    .border(1.dp, PadGlowCyan, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                BasicTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    singleLine = true,
                    textStyle = TextStyle(
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        color = Color.White,
                    ),
                    cursorBrush = SolidColor(PadGlowCyan),
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFF051C3E), RoundedCornerShape(3.dp))
                        .padding(horizontal = 5.dp, vertical = 3.dp),
                )
                LcdCompactButton(
                    text = "OK",
                    isPrimary = true,
                    onClick = {
                        onRenamePatch(target.id, renameText)
                        renamingPatch = null
                    },
                )
                LcdCompactButton(text = "X", onClick = { renamingPatch = null })
            }
        }

        // Scrollable Patch List
        if (state.filteredPatches.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(horizontal = 8.dp),
                ) {
                    Text(
                        text = if (state.patches.isEmpty()) {
                            "NO PATCHES IMPORTED YET"
                        } else {
                            "NO MATCHING PATCHES"
                        },
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = LcdTextPrimary,
                    )
                    if (state.patches.isEmpty()) {
                        Text(
                            text = "Import New Ton 2026.zip, .MCN, WAV/MP3 or Roland SPD-30 Backup.",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 9.sp,
                            color = LcdTextSecondary,
                        )
                        LcdCompactButton(
                            text = "OPEN PATCH LOAD",
                            isPrimary = true,
                            onClick = onOpenPatchLoad,
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("patch_lazy_list"),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                items(state.filteredPatches, key = { it.id }) { patch ->
                    val isSelected = patch.id == state.activePatch?.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("patch_row_${patch.formattedNumber}")
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) LcdHighlightBg else Color(0xFF082652))
                            .clickable { onSelectPatch(patch) }
                            .padding(horizontal = 6.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        // STRICT: Normal sequential number WITHOUT leading zeros
                        Text(
                            text = patch.formattedNumber,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (isSelected) LcdHighlightText else PadGlowCyan,
                            modifier = Modifier.width(30.dp),
                        )
                        Text(
                            text = patch.name,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = if (isSelected) LcdHighlightText else LcdTextPrimary,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            text = "${patch.assignedPadCount}P",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 9.sp,
                            color = if (isSelected) LcdHighlightText.copy(alpha = 0.8f) else LcdTextSecondary,
                        )
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Filled.Edit,
                                contentDescription = "Rename Patch",
                                tint = LcdHighlightText,
                                modifier = Modifier
                                    .size(13.dp)
                                    .clickable {
                                        renameText = patch.name
                                        renamingPatch = patch
                                    },
                            )
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Delete Patch",
                                tint = Color(0xFF6B0018),
                                modifier = Modifier
                                    .size(13.dp)
                                    .clickable { onRequestDeletePatch(patch) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LcdPatchLoadContent(
    progress: ImportProgress,
    patchCount: Int,
    onBackToList: () -> Unit,
    onPickWavSamples: () -> Unit,
    onPickMp3Samples: () -> Unit,
    onPickZipCollection: () -> Unit,
    onPickJsonFile: () -> Unit,
    onPickMcnFolder: () -> Unit,
    onPickSpd30Backup: () -> Unit,
    onShowMyImportedPatches: () -> Unit,
    onCancelImport: () -> Unit,
    onDismissImportSummary: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .testTag("lcd_patch_load_panel"),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "PATCH LOAD",
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = PadGlowCyan,
            )
            LcdCompactButton(text = "LIST", onClick = onBackToList)
        }

        if (progress.isImporting) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color(0xFF062147))
                    .border(1.dp, PadGlowCyan, RoundedCornerShape(5.dp))
                    .padding(7.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = progress.stage,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = LcdTextPrimary,
                )
                if (progress.totalEntries > 0) {
                    LinearProgressIndicator(
                        progress = { (progress.processedEntries.toFloat() / progress.totalEntries.toFloat()).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                        color = PadGlowCyan,
                        trackColor = Color(0xFF143C70),
                    )
                } else {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth(),
                        color = PadGlowCyan,
                        trackColor = Color(0xFF143C70),
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "Entries: ${progress.processedEntries} | Patches: ${progress.importedPatches}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 9.sp,
                        color = LcdTextSecondary,
                    )
                    LcdCompactButton(text = "CANCEL", tint = LedRed, onClick = onCancelImport)
                }
            }
        } else if (progress.isCompleted) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(5.dp))
                    .background(
                        if (progress.errorMessage != null) Color(0xFF47121E) else Color(0xFF083254)
                    )
                    .border(
                        1.dp,
                        if (progress.errorMessage != null) LedRed else LedGreen,
                        RoundedCornerShape(5.dp),
                    )
                    .padding(6.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = progress.errorMessage ?: "Imported ${progress.importedPatches} patch(es) (${progress.processedEntries} entries)",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        color = Color.White,
                        modifier = Modifier.weight(1f),
                    )
                    LcdCompactButton(text = "OK", onClick = onDismissImportSummary)
                }
                if (progress.skippedDuplicates > 0) {
                    Text(
                        text = "Skipped duplicates: ${progress.skippedDuplicates}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 8.sp,
                        color = LcdTextSecondary,
                    )
                }
                if (progress.missingSamples.isNotEmpty()) {
                    Text(
                        text = "Missing samples (${progress.missingSamples.size}): ${progress.missingSamples.take(3).joinToString(", ")}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 8.sp,
                        color = PadEditAmber,
                    )
                }
                if (progress.unsupportedFiles.isNotEmpty()) {
                    Text(
                        text = "Unsupported/Preserved (${progress.unsupportedFiles.size}): ${progress.unsupportedFiles.first()}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 8.sp,
                        color = PadEditAmber,
                    )
                }
            }
        }

        // All 7 required Patch Load Options
        PatchLoadOptionRow("Load WAV Samples", "Multi-select .wav", onPickWavSamples, "opt_load_wav")
        PatchLoadOptionRow("Load MP3 Samples", "Multi-select .mp3/.ogg", onPickMp3Samples, "opt_load_mp3")
        PatchLoadOptionRow("Load ZIP Patch Collection", "New Ton 2026.zip / Large ZIP", onPickZipCollection, "opt_load_zip")
        PatchLoadOptionRow("Load JSON Patch File", "JSON kit / bank", onPickJsonFile, "opt_load_json")
        PatchLoadOptionRow("Load .MCN Patch Collection", "Folder w/ .mcn & machine.cfg", onPickMcnFolder, "opt_load_mcn")
        PatchLoadOptionRow("Load Roland SPD-30 Backup", "ROLAND/SPD-30/DATA01", onPickSpd30Backup, "opt_load_spd30")
        PatchLoadOptionRow("My Imported Patches", "$patchCount total in library", onShowMyImportedPatches, "opt_my_imported")
    }
}

@Composable
private fun PatchLoadOptionRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
            .clip(RoundedCornerShape(5.dp))
            .background(Color(0xFF0A326A))
            .border(1.dp, Color(0xFF286BB8), RoundedCornerShape(5.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 7.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = LcdTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = subtitle,
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 8.sp,
                color = LcdTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Icon(
            imageVector = Icons.Filled.FolderOpen,
            contentDescription = title,
            tint = PadGlowCyan,
            modifier = Modifier.size(15.dp),
        )
    }
}

@Composable
private fun LcdPadEditContent(
    draftPatch: OctapadPatch?,
    selectedPadIndex: Int,
    onSelectPad: (Int) -> Unit,
    onAddOrChangeSample: () -> Unit,
    onPreviewSample: () -> Unit,
    onVolumeChange: (Float) -> Unit,
    onPitchChange: (Float) -> Unit,
    onMidiNoteChange: (Int) -> Unit,
    onSave: () -> Unit,
    onDone: () -> Unit,
) {
    val pad = draftPatch?.pads?.getOrNull(selectedPadIndex) ?: PadAssignment(padIndex = selectedPadIndex)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .testTag("lcd_pad_edit_panel"),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "PAD ${pad.displayNumber} EDITOR",
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = PadEditAmber,
            )
            LcdCompactButton(
                text = "DONE",
                isPrimary = true,
                tint = PadEditAmber,
                testTag = "btn_edit_done",
                onClick = onDone,
            )
        }

        // Quick Pad 1..8 selector tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            for (i in 0 until 8) {
                val active = i == selectedPadIndex
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (active) PadEditAmber else Color(0xFF0A326A))
                        .clickable { onSelectPad(i) }
                        .padding(vertical = 3.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = "${i + 1}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = if (active) Color(0xFF1A1100) else LcdTextPrimary,
                    )
                }
            }
        }

        // Current Sample Info
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF062147))
                .border(1.dp, Color(0xFF286BB8), RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 4.dp),
        ) {
            Text(
                text = if (pad.hasSample) "SAMPLE: ${pad.sampleName}" else "SAMPLE: (None assigned)",
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (pad.hasSample) LcdTextPrimary else LcdTextSecondary,
            )
        }

        // ADD SAMPLE / CHANGE SAMPLE / PREVIEW SAMPLE / SAVE
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            LcdCompactButton(
                text = "ADD SAMPLE",
                isPrimary = !pad.hasSample,
                testTag = "btn_add_sample",
                onClick = onAddOrChangeSample,
                modifier = Modifier.weight(1f),
            )
            LcdCompactButton(
                text = "CHANGE SAMPLE",
                isPrimary = pad.hasSample,
                testTag = "btn_change_sample",
                onClick = onAddOrChangeSample,
                modifier = Modifier.weight(1f),
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            LcdCompactButton(
                text = "PREVIEW SAMPLE",
                enabled = pad.hasSample,
                testTag = "btn_preview_sample",
                onClick = onPreviewSample,
                modifier = Modifier.weight(1f),
            )
            LcdCompactButton(
                text = "SAVE",
                isPrimary = true,
                tint = LedGreen,
                testTag = "btn_edit_save",
                onClick = onSave,
                modifier = Modifier.weight(0.7f),
            )
        }

        // Volume & Pitch Sliders
        LcdParamSlider(
            label = "VOLUME",
            valueText = "${(pad.volume * 100).toInt()}%",
            value = pad.volume,
            valueRange = 0f..1.5f,
            onValueChange = onVolumeChange,
        )
        LcdParamSlider(
            label = "PITCH",
            valueText = String.format(Locale.US, "%+.1f st", pad.pitchSemitones),
            value = pad.pitchSemitones,
            valueRange = -12f..12f,
            onValueChange = onPitchChange,
        )

        // MIDI Note Assignment
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "MIDI NOTE: ${pad.midiNote}",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = LcdTextPrimary,
                )
                Text(
                    text = gmDrumName(pad.midiNote),
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 9.sp,
                    color = LcdTextSecondary,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                LcdCompactButton(text = "-", onClick = { onMidiNoteChange(pad.midiNote - 1) })
                LcdCompactButton(text = "+", onClick = { onMidiNoteChange(pad.midiNote + 1) })
            }
        }
    }
}

@Composable
private fun LcdEffectsContent(
    effects: EffectsSettings,
    onBackToList: () -> Unit,
    onEffectsChange: ((EffectsSettings) -> EffectsSettings) -> Unit,
    onSaveEffects: () -> Unit,
    onResetEffects: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .testTag("lcd_effects_panel"),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "DSP EFFECTS",
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = PadGlowCyan,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                LcdCompactButton(text = "RESET", onClick = onResetEffects)
                LcdCompactButton(text = "SAVE", isPrimary = true, tint = LedGreen, onClick = onSaveEffects)
                LcdCompactButton(text = "LIST", onClick = onBackToList)
            }
        }

        LcdParamSlider(
            label = "MASTER VOLUME",
            valueText = "${(effects.masterVolume * 100).toInt()}%",
            value = effects.masterVolume,
            valueRange = 0f..1f,
            onValueChange = { v -> onEffectsChange { it.copy(masterVolume = v) } },
        )
        LcdParamSlider(
            label = "BASS",
            valueText = String.format(Locale.US, "%+.1f dB", effects.bassDb),
            value = effects.bassDb,
            valueRange = -12f..12f,
            onValueChange = { v -> onEffectsChange { it.copy(bassDb = v) } },
        )
        LcdParamSlider(
            label = "TREBLE",
            valueText = String.format(Locale.US, "%+.1f dB", effects.trebleDb),
            value = effects.trebleDb,
            valueRange = -12f..12f,
            onValueChange = { v -> onEffectsChange { it.copy(trebleDb = v) } },
        )
        LcdParamSlider(
            label = "PITCH",
            valueText = String.format(Locale.US, "%+.1f st", effects.masterPitchSemitones),
            value = effects.masterPitchSemitones,
            valueRange = -12f..12f,
            onValueChange = { v -> onEffectsChange { it.copy(masterPitchSemitones = v) } },
        )
        LcdParamSlider(
            label = "ECHO",
            valueText = "${(effects.echoLevel * 100).toInt()}%",
            value = effects.echoLevel,
            valueRange = 0f..1f,
            onValueChange = { v -> onEffectsChange { it.copy(echoLevel = v) } },
        )
        LcdParamSlider(
            label = "DELAY",
            valueText = "${effects.delayMs} ms",
            value = effects.delayMs.toFloat(),
            valueRange = 40f..800f,
            onValueChange = { v -> onEffectsChange { it.copy(delayMs = v.toInt()) } },
        )
        LcdParamSlider(
            label = "REVERB",
            valueText = "${(effects.reverbLevel * 100).toInt()}%",
            value = effects.reverbLevel,
            valueRange = 0f..1f,
            onValueChange = { v -> onEffectsChange { it.copy(reverbLevel = v) } },
        )
    }
}

@Composable
private fun LcdMidiContent(
    midiStatus: MidiStatus,
    onBackToList: () -> Unit,
    onRefreshMidi: () -> Unit,
    onSelectMidiInput: (Int) -> Unit,
    onSelectMidiOutput: (Int) -> Unit,
    onSetMidiChannel: (Int) -> Unit,
    onToggleMidiInput: (Boolean) -> Unit,
    onToggleMidiOutput: (Boolean) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .testTag("lcd_midi_panel"),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "USB MIDI",
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = PadGlowCyan,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(
                    imageVector = Icons.Filled.Refresh,
                    contentDescription = "Refresh USB MIDI Devices",
                    tint = PadGlowCyan,
                    modifier = Modifier
                        .size(20.dp)
                        .clickable(onClick = onRefreshMidi),
                )
                LcdCompactButton(text = "LIST", onClick = onBackToList)
            }
        }

        // Real Connection Status Banner (no fake status)
        val isConnected = midiStatus.isInputConnected || midiStatus.isOutputConnected
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(if (isConnected) Color(0xFF0A3C32) else Color(0xFF062147))
                .border(1.dp, if (isConnected) LedGreen else Color(0xFF286BB8), RoundedCornerShape(4.dp))
                .padding(6.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = if (isConnected) "USB MIDI CONNECTED" else "NO USB MIDI CONNECTED",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = if (isConnected) LedGreen else PadEditAmber,
                )
                Text(
                    text = midiStatus.lastEventLog,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 9.sp,
                    color = LcdTextPrimary,
                )
            }
        }

        // MIDI IN / OUT Toggles + Channel Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            LcdCompactButton(
                text = if (midiStatus.isInputEnabled) "MIDI IN: ON" else "MIDI IN: OFF",
                isPrimary = midiStatus.isInputEnabled,
                onClick = { onToggleMidiInput(!midiStatus.isInputEnabled) },
                modifier = Modifier.weight(1f),
            )
            LcdCompactButton(
                text = if (midiStatus.isOutputEnabled) "MIDI OUT: ON" else "MIDI OUT: OFF",
                isPrimary = midiStatus.isOutputEnabled,
                onClick = { onToggleMidiOutput(!midiStatus.isOutputEnabled) },
                modifier = Modifier.weight(1f),
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "CHANNEL: ${if (midiStatus.midiChannel == 0) "OMNI" else midiStatus.midiChannel.toString()}",
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = LcdTextPrimary,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                LcdCompactButton(text = "OMNI", isPrimary = midiStatus.midiChannel == 0, onClick = { onSetMidiChannel(0) })
                LcdCompactButton(text = "-", onClick = { onSetMidiChannel((midiStatus.midiChannel - 1).coerceAtLeast(0)) })
                LcdCompactButton(text = "+", onClick = { onSetMidiChannel((midiStatus.midiChannel + 1).coerceAtMost(16)) })
            }
        }

        Text(
            text = "USB DEVICES (${midiStatus.connectedDevices.size})",
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp,
            color = LcdTextSecondary,
        )

        if (midiStatus.connectedDevices.isEmpty()) {
            Text(
                text = "Connect an external USB MIDI drum pad/controller via USB-OTG to enable MIDI IN/OUT.",
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 9.sp,
                color = LcdTextSecondary,
            )
        } else {
            midiStatus.connectedDevices.forEach { dev ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF0A326A))
                        .padding(5.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = dev.name,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 9.sp,
                        color = LcdTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        if (dev.hasInput) {
                            LcdCompactButton(
                                text = "IN",
                                isPrimary = midiStatus.selectedInputDeviceId == dev.id && midiStatus.isInputConnected,
                                onClick = { onSelectMidiInput(dev.id) },
                            )
                        }
                        if (dev.hasOutput) {
                            LcdCompactButton(
                                text = "OUT",
                                isPrimary = midiStatus.selectedOutputDeviceId == dev.id && midiStatus.isOutputConnected,
                                onClick = { onSelectMidiOutput(dev.id) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LcdRecordingContent(
    recorderState: RecorderUiState,
    recordings: List<OctapadRecording>,
    onBackToList: () -> Unit,
    onStartRecording: () -> Unit,
    onPauseRecording: () -> Unit,
    onResumeRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onPlayCurrentTake: () -> Unit,
    onStopPlayback: () -> Unit,
    onLoopToggle: (Boolean) -> Unit,
    onSaveTake: (String) -> Unit,
    onPlaySavedRecording: (OctapadRecording) -> Unit,
    onRenameRecording: (Long, String) -> Unit,
    onToggleSavedLoop: (OctapadRecording) -> Unit,
    onDeleteRecording: (Long) -> Unit,
) {
    var saveName by remember { mutableStateOf("") }
    var renamingRec by remember { mutableStateOf<OctapadRecording?>(null) }
    var renameText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .testTag("lcd_recording_panel"),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "RECORDER",
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = LedRed,
            )
            LcdCompactButton(text = "LIST", onClick = onBackToList)
        }

        // Transport status & timer
        val sec = recorderState.elapsedMs / 1000
        val msTenths = (recorderState.elapsedMs % 1000) / 100
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF062147))
                .border(1.dp, Color(0xFF286BB8), RoundedCornerShape(4.dp))
                .padding(6.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "${recorderState.transportState.name} • ${sec}.${msTenths}s",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = if (recorderState.transportState == RecordingTransportState.RECORDING) LedRed else LcdTextPrimary,
                )
                Text(
                    text = "${recorderState.capturedEventCount} hits",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 9.sp,
                    color = LcdTextSecondary,
                )
            }
        }

        // Transport Controls: Start, Pause/Resume, Stop, Play, Loop
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            when (recorderState.transportState) {
                RecordingTransportState.IDLE -> {
                    LcdCompactButton(
                        text = "REC",
                        isPrimary = true,
                        tint = LedRed,
                        onClick = onStartRecording,
                        modifier = Modifier.weight(1f),
                    )
                }
                RecordingTransportState.RECORDING -> {
                    LcdCompactButton(
                        text = "PAUSE",
                        isPrimary = true,
                        tint = LedAmber,
                        onClick = onPauseRecording,
                        modifier = Modifier.weight(1f),
                    )
                    LcdCompactButton(
                        text = "STOP",
                        onClick = onStopRecording,
                        modifier = Modifier.weight(1f),
                    )
                }
                RecordingTransportState.PAUSED -> {
                    LcdCompactButton(
                        text = "RESUME",
                        isPrimary = true,
                        tint = LedRed,
                        onClick = onResumeRecording,
                        modifier = Modifier.weight(1f),
                    )
                    LcdCompactButton(
                        text = "STOP",
                        onClick = onStopRecording,
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            if (recorderState.isPlaying) {
                LcdCompactButton(
                    text = "STOP PLAY",
                    isPrimary = true,
                    onClick = onStopPlayback,
                    modifier = Modifier.weight(1f),
                )
            } else {
                LcdCompactButton(
                    text = "PLAY",
                    enabled = recorderState.capturedEventCount > 0 && recorderState.transportState == RecordingTransportState.IDLE,
                    onClick = onPlayCurrentTake,
                    modifier = Modifier.weight(0.9f),
                )
            }

            LcdCompactButton(
                text = "LOOP",
                isPrimary = recorderState.isLoopingPlayback,
                onClick = { onLoopToggle(!recorderState.isLoopingPlayback) },
            )
        }

        // Save current take row
        if (recorderState.hasUnsavedTakes) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF062147))
                        .border(1.dp, PadGlowCyan, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 5.dp),
                ) {
                    if (saveName.isEmpty()) {
                        Text(
                            text = "Take name...",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = LcdTextSecondary.copy(alpha = 0.6f),
                        )
                    }
                    BasicTextField(
                        value = saveName,
                        onValueChange = { saveName = it },
                        singleLine = true,
                        textStyle = TextStyle(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = LcdTextPrimary,
                        ),
                        cursorBrush = SolidColor(PadGlowCyan),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                LcdCompactButton(
                    text = "SAVE",
                    isPrimary = true,
                    tint = LedGreen,
                    onClick = {
                        onSaveTake(saveName)
                        saveName = ""
                    },
                )
            }
        }

        renamingRec?.let { target ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BasicTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    singleLine = true,
                    textStyle = TextStyle(fontFamily = JetBrainsMonoFontFamily, fontSize = 10.sp, color = Color.White),
                    cursorBrush = SolidColor(PadGlowCyan),
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFF062147), RoundedCornerShape(4.dp))
                        .padding(5.dp),
                )
                LcdCompactButton(
                    text = "OK",
                    isPrimary = true,
                    onClick = {
                        onRenameRecording(target.id, renameText)
                        renamingRec = null
                    },
                )
                LcdCompactButton(text = "X", onClick = { renamingRec = null })
            }
        }

        Text(
            text = "SAVED RECORDINGS (${recordings.size})",
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp,
            color = LcdTextSecondary,
        )

        recordings.forEach { rec ->
            val playingThis = recorderState.isPlaying && recorderState.activePlayingRecordingId == rec.id
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (playingThis) Color(0xFF124D78) else Color(0xFF0A326A))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = rec.name,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = LcdTextPrimary,
                    )
                    Text(
                        text = "${rec.events.size} hits • ${rec.durationMs / 1000}s",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 8.sp,
                        color = LcdTextSecondary,
                    )
                }
                Icon(
                    imageVector = if (playingThis) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                    contentDescription = if (playingThis) "Stop" else "Play",
                    tint = if (playingThis) LedRed else LedGreen,
                    modifier = Modifier
                        .size(18.dp)
                        .clickable {
                            if (playingThis) onStopPlayback() else onPlaySavedRecording(rec)
                        },
                )
                Icon(
                    imageVector = Icons.Filled.Loop,
                    contentDescription = "Loop Recording",
                    tint = if (rec.isLooping) PadGlowCyan else Color(0xFF5D7A9C),
                    modifier = Modifier
                        .size(16.dp)
                        .clickable { onToggleSavedLoop(rec) },
                )
                Icon(
                    imageVector = Icons.Filled.Edit,
                    contentDescription = "Rename Recording",
                    tint = LcdTextSecondary,
                    modifier = Modifier
                        .size(15.dp)
                        .clickable {
                            renameText = rec.name
                            renamingRec = rec
                        },
                )
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = "Delete Recording",
                    tint = LedRed,
                    modifier = Modifier
                        .size(15.dp)
                        .clickable { onDeleteRecording(rec.id) },
                )
            }
        }
    }
}
