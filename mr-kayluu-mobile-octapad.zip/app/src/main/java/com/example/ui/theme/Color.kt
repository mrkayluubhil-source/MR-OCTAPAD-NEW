package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Hardware Chassis & Metallic Palette (Roland SPD-30 Inspired White/Silver + Glossy Black + Blue LCD)
val ChassisSilverLight = Color(0xFFF2F5F8)
val ChassisSilverMid = Color(0xFFDCE2E9)
val ChassisSilverDark = Color(0xFFB8C2CE)
val ChassisEdgeHighlight = Color(0xFFFFFFFF)
val ChassisBezelDark = Color(0xFF151920)

val GlossPanelTop = Color(0xFF181D26)
val GlossPanelMid = Color(0xFF0E1117)
val GlossPanelBottom = Color(0xFF07090D)

// Drum Pad Surfaces & Electric Cyan Glow
val PadSurfaceIdleTop = Color(0xFF232933)
val PadSurfaceIdleBottom = Color(0xFF14181F)
val PadSurfacePressed = Color(0xFF1A3A52)
val PadGlowCyan = Color(0xFF00D4FF)
val PadGlowCyanBright = Color(0xFF7CEBFF)
val PadGlowBlueDim = Color(0xFF0D5C8A)
val PadEditAmber = Color(0xFFFFAB00)
val PadEditAmberBg = Color(0xFF3A2800)

// Backlit Blue Hardware LCD
val LcdBlueTop = Color(0xFF0C3B7A)
val LcdBlueMid = Color(0xFF092B5C)
val LcdBlueBottom = Color(0xFF051C3E)
val LcdTextPrimary = Color(0xFFE6F4FF)
val LcdTextSecondary = Color(0xFF8CC4FF)
val LcdHighlightBg = Color(0xFF1FA6FF)
val LcdHighlightText = Color(0xFF041326)
val LcdBorderGlow = Color(0xFF3588D8)

// Hardware LED Accents
val LedGreen = Color(0xFF00E676)
val LedRed = Color(0xFFFF3D57)
val LedAmber = Color(0xFFFFB300)
val LedCyan = Color(0xFF00E5FF)

// Hardware Button Surfaces
val HardwareButtonTop = Color(0xFF2E3542)
val HardwareButtonBottom = Color(0xFF1A1F28)
val HardwareButtonActiveTop = Color(0xFF104A7A)
val HardwareButtonActiveBottom = Color(0xFF092A47)
