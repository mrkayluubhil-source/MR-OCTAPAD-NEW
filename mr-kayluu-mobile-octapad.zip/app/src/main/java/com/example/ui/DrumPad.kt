package com.example.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInParent
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PadAssignment
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.PadEditAmber
import com.example.ui.theme.PadEditAmberBg
import com.example.ui.theme.PadGlowBlueDim
import com.example.ui.theme.PadGlowCyan
import com.example.ui.theme.PadGlowCyanBright
import com.example.ui.theme.PadSurfaceIdleBottom
import com.example.ui.theme.PadSurfaceIdleTop
import com.example.ui.theme.PadSurfacePressed

/**
 * 8-Pad (4x2) Hardware Drum Pad Grid with true simultaneous multi-finger pointer tracking.
 * Independent PointerId -> padIndex tracking allows 2, 4, and 8 simultaneous touches
 * without any global pressed lock.
 */
@Composable
fun OctapadPadGrid(
    pads: List<PadAssignment>,
    pressedPads: Set<Int>,
    isEditMode: Boolean,
    selectedEditPadIndex: Int,
    onPadPressed: (padIndex: Int, velocity: Float) -> Unit,
    onPadReleased: (padIndex: Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val padBounds = remember { mutableStateMapOf<Int, Rect>() }
    val activePointers = remember { mutableMapOf<PointerId, Int>() }

    fun findPadAt(position: Offset): Int? {
        for (entry in padBounds.entries) {
            if (entry.value.contains(position)) return entry.key
        }
        return null
    }

    BoxWithConstraints(
        modifier = modifier
            .pointerInput(isEditMode) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        when (event.type) {
                            PointerEventType.Press -> {
                                for (change in event.changes) {
                                    if (change.pressed && !change.previousPressed) {
                                        val hitPad = findPadAt(change.position)
                                        if (hitPad != null) {
                                            activePointers[change.id] = hitPad
                                            val pressureVel = change.pressure.takeIf { it > 0f }?.coerceIn(0.35f, 1.0f) ?: 1.0f
                                            onPadPressed(hitPad, pressureVel)
                                            change.consume()
                                        }
                                    }
                                }
                            }
                            PointerEventType.Release, PointerEventType.Exit -> {
                                for (change in event.changes) {
                                    if (!change.pressed) {
                                        val prevPad = activePointers.remove(change.id)
                                        if (prevPad != null && !activePointers.containsValue(prevPad)) {
                                            onPadReleased(prevPad)
                                        }
                                        change.consume()
                                    }
                                }
                            }
                            else -> {
                                // Handle cancelled/up pointers cleanly
                                val toRemove = activePointers.keys.filter { ptrId ->
                                    event.changes.none { it.id == ptrId && it.pressed }
                                }
                                for (ptrId in toRemove) {
                                    val prevPad = activePointers.remove(ptrId)
                                    if (prevPad != null && !activePointers.containsValue(prevPad)) {
                                        onPadReleased(prevPad)
                                    }
                                }
                            }
                        }
                    }
                }
            }
    ) {
        val spacing = if (maxWidth < 460.dp) 6.dp else 10.dp

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(spacing),
        ) {
            for (row in 0 until 2) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(spacing),
                ) {
                    for (col in 0 until 4) {
                        val padIdx = row * 4 + col
                        val assignment = pads.getOrNull(padIdx) ?: PadAssignment(padIndex = padIdx)
                        DrumPad(
                            assignment = assignment,
                            isPressed = padIdx in pressedPads,
                            isEditMode = isEditMode,
                            isSelectedForEdit = isEditMode && selectedEditPadIndex == padIdx,
                            onActivateSemantic = {
                                onPadPressed(padIdx, 1.0f)
                                onPadReleased(padIdx)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .onGloballyPositioned { coords ->
                                    padBounds[padIdx] = coords.boundsInParent()
                                },
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DrumPad(
    assignment: PadAssignment,
    isPressed: Boolean,
    isEditMode: Boolean,
    isSelectedForEdit: Boolean,
    onActivateSemantic: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val padShape = RoundedCornerShape(10.dp)
    val glowColor by animateColorAsState(
        targetValue = when {
            isSelectedForEdit -> PadEditAmber
            isPressed -> PadGlowCyanBright
            isEditMode -> PadEditAmber.copy(alpha = 0.72f)
            assignment.hasSample -> PadGlowCyan
            else -> PadGlowBlueDim
        },
        animationSpec = tween(durationMillis = if (isPressed) 25 else 130),
        label = "padGlow",
    )

    val fillTop by animateColorAsState(
        targetValue = when {
            isPressed -> PadSurfacePressed
            isSelectedForEdit -> Color(0xFF2B2314)
            else -> PadSurfaceIdleTop
        },
        animationSpec = tween(durationMillis = if (isPressed) 25 else 130),
        label = "padFillTop",
    )

    val padNumber = assignment.displayNumber
    val padDesc = "Drum Pad $padNumber ${assignment.sampleName.ifBlank { "Empty" }}"

    Box(
        modifier = modifier
            .testTag("drum_pad_$padNumber")
            .semantics {
                role = Role.Button
                contentDescription = padDesc
                onClick(label = "Trigger Pad $padNumber") {
                    onActivateSemantic()
                    true
                }
            }
            .drawBehind {
                // Subtle outer neon halo around pad
                val haloAlpha = if (isPressed) 0.55f else if (isSelectedForEdit) 0.45f else 0.18f
                drawRoundRect(
                    color = glowColor.copy(alpha = haloAlpha),
                    cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx()),
                    style = Stroke(width = if (isPressed || isSelectedForEdit) 6.dp.toPx() else 3.dp.toPx()),
                )
            }
            .clip(padShape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(fillTop, PadSurfaceIdleBottom)
                )
            )
            .border(
                width = if (isPressed || isSelectedForEdit) 2.5.dp else 1.6.dp,
                color = glowColor,
                shape = padShape,
            )
            .padding(horizontal = 7.dp, vertical = 6.dp),
    ) {
        // Top row: Pad Number (1..8) + EDIT badge on ALL 8 pads when Edit Mode is active
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = padNumber,
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = if (isSelectedForEdit) PadEditAmber else PadGlowCyanBright,
            )

            if (isEditMode) {
                Box(
                    modifier = Modifier
                        .testTag("pad_edit_badge_$padNumber")
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelectedForEdit) PadEditAmber else PadEditAmberBg)
                        .border(1.dp, PadEditAmber, RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 1.dp),
                ) {
                    Text(
                        text = "EDIT",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 8.sp,
                        color = if (isSelectedForEdit) Color(0xFF1A1100) else PadEditAmber,
                    )
                }
            } else {
                Text(
                    text = "N${assignment.midiNote}",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 9.sp,
                    color = Color(0xFF7CA7C9),
                )
            }
        }

        // Center pad strike indicator dot
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(0.32f)
                .clip(RoundedCornerShape(2.dp))
                .background(
                    if (isPressed) PadGlowCyanBright.copy(alpha = 0.7f)
                    else if (assignment.hasSample) PadGlowCyan.copy(alpha = 0.25f)
                    else Color(0xFF28303D)
                )
                .padding(vertical = 1.dp)
        )

        // Bottom sample label
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomStart),
        ) {
            Text(
                text = if (assignment.hasSample) assignment.sampleName else "—",
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (assignment.hasSample) Color(0xFFE5F4FF) else Color(0xFF5D6A7B),
            )
            if (isEditMode) {
                Text(
                    text = "V:${(assignment.volume * 100).toInt()}% P:${assignment.pitchSemitones.toInt()}",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 8.sp,
                    maxLines = 1,
                    color = PadEditAmber.copy(alpha = 0.85f),
                )
            }
        }
    }
}
