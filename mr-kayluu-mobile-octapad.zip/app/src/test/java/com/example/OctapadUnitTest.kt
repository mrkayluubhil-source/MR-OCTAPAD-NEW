package com.example

import com.example.audio.EffectsProcessor
import com.example.audio.SoundImportManager
import com.example.importer.AudioArchiveIndex
import com.example.importer.KitManager
import com.example.importer.McnPatchParser
import com.example.model.EffectsSettings
import com.example.model.OctapadPatch
import com.example.model.PadAssignment
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.file.Files

class OctapadUnitTest {

    private fun createWavBytes(freqHz: Double = 220.0): ByteArray {
        val sampleRate = 44100
        val numSamples = 882 // 20ms
        val dataSize = numSamples * 2
        val bb = ByteBuffer.allocate(44 + dataSize).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray(Charsets.US_ASCII))
        bb.putInt(36 + dataSize)
        bb.put("WAVE".toByteArray(Charsets.US_ASCII))
        bb.put("fmt ".toByteArray(Charsets.US_ASCII))
        bb.putInt(16)
        bb.putShort(1) // PCM
        bb.putShort(1) // Mono
        bb.putInt(sampleRate)
        bb.putInt(sampleRate * 2)
        bb.putShort(2)
        bb.putShort(16)
        bb.put("data".toByteArray(Charsets.US_ASCII))
        bb.putInt(dataSize)
        for (i in 0 until numSamples) {
            val v = (kotlin.math.sin(2.0 * Math.PI * freqHz * i / sampleRate) * 16000.0).toInt().toShort()
            bb.putShort(v)
        }
        return bb.array()
    }

    @Test
    fun `mcn parser parses 39 mcn folders and 106 machine cfg files and reports missing samples`() {
        val root = Files.createTempDirectory("mcn_test").toFile()
        try {
            val wavBytes = createWavBytes()
            val allAudio = mutableListOf<File>()
            val cfgFiles = mutableListOf<File>()
            var counter = 0

            for (mcnIdx in 1..39) {
                val banks = if (mcnIdx <= 28) 3 else 2
                for (b in 1..banks) {
                    counter++
                    val bankDir = File(root, "Kit_${mcnIdx}.mcn/Bank_$b").apply { mkdirs() }
                    val cfg = File(bankDir, "machine.cfg")
                    cfg.writeText(
                        buildString {
                            appendLine("name = Ton Kit $counter")
                            for (p in 1..8) {
                                appendLine("pad$p = s_${counter}_$p.wav")
                            }
                        }
                    )
                    cfgFiles.add(cfg)
                    for (p in 1..8) {
                        // Intentionally leave pad 8 missing on kit #106 to verify missing sample reporting
                        if (!(counter == 106 && p == 8)) {
                            val wav = File(bankDir, "s_${counter}_$p.wav").apply { writeBytes(wavBytes) }
                            allAudio.add(wav)
                        }
                    }
                }
            }

            assertEquals(106, cfgFiles.size)
            val index = AudioArchiveIndex(root, allAudio)
            val parser = McnPatchParser()

            val results = cfgFiles.map { parser.parseMachineConfig(it, root, index) }
            assertEquals(106, results.size)
            assertEquals("Ton Kit 1", results.first().patchName)
            assertEquals("Ton Kit 106", results.last().patchName)
            assertEquals(8, results.first().padAssignments.count { it.hasSample })
            assertEquals(7, results.last().padAssignments.count { it.hasSample })
            assertEquals(1, results.last().missingSamples.size)
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun `patch numbering is strictly sequential without leading zeros`() {
        val patches = (1..1005).map { num ->
            OctapadPatch(id = num.toLong(), patchNumber = num, name = "Kit $num")
        }
        assertEquals("1", patches[0].formattedNumber)
        assertEquals("9", patches[8].formattedNumber)
        assertEquals("10", patches[9].formattedNumber)
        assertEquals("100", patches[99].formattedNumber)
        assertEquals("1005", patches[1004].formattedNumber)
        assertFalse(patches.any { it.formattedNumber.startsWith("0") })

        val kitMgr = KitManager()
        assertEquals(1005, kitMgr.resolvePreviousPatch(patches, 1L)?.patchNumber)
        assertEquals(2, kitMgr.resolveNextPatch(patches, 1L)?.patchNumber)
        assertEquals(1, kitMgr.resolveNextPatch(patches, 1005L)?.patchNumber)
    }

    @Test
    fun `wav decoder and effects processor process real pcm audio`() {
        val tempWav = Files.createTempFile("unit_tone", ".wav").toFile()
        try {
            tempWav.writeBytes(createWavBytes(440.0))
            val decoder = SoundImportManager(44100)
            val sample = decoder.decodeWavFast(tempWav)
            assertNotNull(sample)
            assertTrue(sample!!.frameCount == 882)

            val fx = EffectsProcessor(44100)
            fx.updateSettings(
                EffectsSettings(
                    masterVolume = 0.9f,
                    bassDb = 8.0f,
                    trebleDb = 4.0f,
                    echoLevel = 0.6f,
                    delayMs = 150,
                    reverbLevel = 0.5f,
                )
            )
            val left = sample.left.copyOf()
            val right = sample.right.copyOf()
            val orig = left[100]
            fx.processStereoBuffer(left, right, left.size)
            assertNotEquals(orig, left[100])
        } finally {
            tempWav.delete()
        }
    }

    @Test
    fun `kit manager updates independent pads cleanly`() {
        val kitMgr = KitManager()
        val initial = OctapadPatch(id = 1L, patchNumber = 1, name = "Test", pads = PadAssignment.defaultPads())
        val updated = kitMgr.updatePadInPatch(initial, 4) { pad ->
            pad.copy(samplePath = "/tmp/tom.wav", sampleName = "Tom", volume = 1.2f, pitchSemitones = -3f, midiNote = 45)
        }
        assertEquals("Tom", updated.pads[4].sampleName)
        assertEquals(1.2f, updated.pads[4].volume)
        assertEquals(-3f, updated.pads[4].pitchSemitones)
        assertEquals(45, updated.pads[4].midiNote)
        assertFalse(updated.pads[0].hasSample)
    }
}
