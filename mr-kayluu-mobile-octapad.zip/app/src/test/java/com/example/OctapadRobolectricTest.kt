package com.example

import android.content.Context
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.audio.EffectsProcessor
import com.example.audio.SoundImportManager
import com.example.data.OctapadDatabase
import com.example.data.SettingsStore
import com.example.data.StorageManager
import com.example.importer.KitManager
import com.example.importer.PatchManager
import com.example.importer.PhonePatchImporter
import com.example.importer.Spd30BackupImporter
import com.example.model.ActivePanel
import com.example.model.EffectsSettings
import com.example.model.OctapadPatch
import com.example.model.PadAssignment
import com.example.ui.ControlPanel
import com.example.ui.OctapadPadGrid
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.OctapadUiState
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class OctapadRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private fun createMinimalWavBytes(freqHz: Double = 220.0): ByteArray {
        val sampleRate = 44100
        val numSamples = 441 // 10ms
        val dataSize = numSamples * 2
        val bb = ByteBuffer.allocate(44 + dataSize).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray(Charsets.US_ASCII))
        bb.putInt(36 + dataSize)
        bb.put("WAVE".toByteArray(Charsets.US_ASCII))
        bb.put("fmt ".toByteArray(Charsets.US_ASCII))
        bb.putInt(16)
        bb.putShort(1) // PCM
        bb.putShort(1) // Mono
        bb.putInt(sampleRate)
        bb.putInt(sampleRate * 2)
        bb.putShort(2)
        bb.putShort(16)
        bb.put("data".toByteArray(Charsets.US_ASCII))
        bb.putInt(dataSize)
        for (i in 0 until numSamples) {
            val v = (kotlin.math.sin(2.0 * Math.PI * freqHz * i / sampleRate) * 16000.0).toInt().toShort()
            bb.putShort(v)
        }
        return bb.array()
    }

    @Test
    fun `large zip over 1341 entries with 39 mcn folders and 106 machine cfg imports completely without leading zeros`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, OctapadDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val storage = StorageManager(context)
        val settings = SettingsStore(context)
        val patchManager = PatchManager(db.patchDao(), storage, settings)
        val kitManager = KitManager()
        val importer = PhonePatchImporter(context, storage, patchManager, kitManager)

        val wavBytes = createMinimalWavBytes()
        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            // Create 39 .mcn folders totaling 106 machine.cfg files and >1,341 total entries (no 1,000-entry limit!)
            var cfgCounter = 0
            for (mcnIdx in 1..39) {
                val banksInMcn = if (mcnIdx <= 28) 3 else 2 // 28*3 + 11*2 = 84 + 22 = 106 machine.cfg
                for (bank in 1..banksInMcn) {
                    cfgCounter++
                    val folder = "Kit_${mcnIdx}.mcn/Bank_$bank"
                    val cfgContent = buildString {
                        appendLine("name = Ton Kit $cfgCounter")
                        for (p in 1..8) {
                            appendLine("pad$p = s_${cfgCounter}_$p.wav")
                        }
                        appendLine("vol1 = 1.1")
                        appendLine("pitch1 = 2.0")
                        appendLine("midi1 = 36")
                    }
                    zos.putNextEntry(ZipEntry("$folder/machine.cfg"))
                    zos.write(cfgContent.toByteArray(Charsets.UTF_8))
                    zos.closeEntry()

                    for (p in 1..8) {
                        zos.putNextEntry(ZipEntry("$folder/s_${cfgCounter}_$p.wav"))
                        zos.write(wavBytes)
                        zos.closeEntry()
                    }
                }
            }
            // Add extra entries to exceed 1,341 total entries cleanly
            for (extra in 1..400) {
                zos.putNextEntry(ZipEntry("Extras/notes_$extra.txt"))
                zos.write("meta $extra".toByteArray())
                zos.closeEntry()
            }
        }

        val zipBytes = baos.toByteArray()
        importer.importZipStream(ByteArrayInputStream(zipBytes), "New Ton 2026.zip")

        val progress = importer.progress.value
        assertTrue(progress.isCompleted)
        assertEquals(null, progress.errorMessage)
        assertTrue("Expected >1341 entries processed, got ${progress.processedEntries}", progress.processedEntries > 1341)
        assertEquals(106, progress.importedPatches)

        val patches = patchManager.getAllPatches()
        assertEquals(106, patches.size)
        assertEquals("1", patches.first().formattedNumber)
        assertEquals("10", patches[9].formattedNumber)
        assertEquals("106", patches.last().formattedNumber)
        assertFalse(patches.any { it.formattedNumber.startsWith("0") })
        assertTrue(patches.all { it.assignedPadCount == 8 })

        // Test repeated additional ZIP import adds sequentially without overwriting existing patches
        val baos2 = ByteArrayOutputStream()
        ZipOutputStream(baos2).use { zos ->
            zos.putNextEntry(ZipEntry("ExtraPack.mcn/machine.cfg"))
            zos.write("name = Extra Pack\npad1 = kick.wav\n".toByteArray())
            zos.closeEntry()
            zos.putNextEntry(ZipEntry("ExtraPack.mcn/kick.wav"))
            zos.write(wavBytes)
            zos.closeEntry()
        }
        importer.importZipStream(ByteArrayInputStream(baos2.toByteArray()), "ExtraPack.zip")

        val afterSecond = patchManager.getAllPatches()
        assertEquals(107, afterSecond.size)
        assertEquals("107", afterSecond.last().formattedNumber)
        assertEquals("Extra Pack", afterSecond.last().name)

        // Test delete renumbers sequentially without leading zeros
        patchManager.deletePatch(afterSecond[0].id)
        val afterDelete = patchManager.getAllPatches()
        assertEquals(106, afterDelete.size)
        assertEquals("1", afterDelete.first().formattedNumber)
        assertEquals("106", afterDelete.last().formattedNumber)

        db.close()
    }

    @Test
    fun `spd30 backup importer detects genuine structure and does not confuse ordinary zips`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val storage = StorageManager(context)
        val importer = Spd30BackupImporter(storage, KitManager())

        val ordinaryDir = File(context.cacheDir, "ordinary_zip_test").apply {
            deleteRecursively()
            mkdirs()
            File(this, "kick.wav").writeBytes(createMinimalWavBytes())
        }
        assertFalse(importer.detectSpd30Structure(ordinaryDir).isSpd30Backup)

        val spdDir = File(context.cacheDir, "spd30_test").apply {
            deleteRecursively()
            mkdirs()
            val backupDir = File(this, "ROLAND/SPD-30/DATA01/BACKUP").apply { mkdirs() }
            File(backupDir, "BKUP_001.SPD").writeBytes(byteArrayOf(0x01, 0x02, 0x03, 0x04))
            val kitDir = File(this, "ROLAND/SPD-30/DATA01/KIT").apply { mkdirs() }
            File(kitDir, "KIT001.SPD").writeBytes(byteArrayOf(0x10, 0x20, 0x30))
        }
        val detected = importer.detectSpd30Structure(spdDir)
        assertTrue(detected.isSpd30Backup)
        assertTrue(detected.hasBackupAllFolder)
        assertTrue(detected.hasKitFolder)

        val result = importer.importDetectedBackup(spdDir, detected, "test_spd")
        assertEquals(2, result.preservedRawPaths.size)
        assertEquals(2, result.unsupportedFiles.size)
    }

    @Test
    fun `wav decoder and dsp effects processor transform audio buffers cleanly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val wavFile = File(context.cacheDir, "test_tone.wav").apply {
            writeBytes(createMinimalWavBytes(440.0))
        }
        val soundMgr = SoundImportManager()
        val sample = soundMgr.getCachedOrDecode(wavFile.absolutePath)
        assertTrue(sample != null && sample.frameCount > 0)

        val fx = EffectsProcessor(44100)
        fx.updateSettings(
            EffectsSettings(
                masterVolume = 0.9f,
                bassDb = 6f,
                trebleDb = -3f,
                echoLevel = 0.5f,
                delayMs = 120,
                reverbLevel = 0.4f,
            )
        )
        val left = sample!!.left.copyOf()
        val right = sample.right.copyOf()
        val beforeFirst = left[50]
        fx.processStereoBuffer(left, right, left.size)
        assertNotEquals(beforeFirst, left[50])
    }

    @Test
    fun `ui shows permanent patch list, 4 main controls, icon-only nav row, and all-pad EDIT badges only in edit mode`() {
        val samplePatch = OctapadPatch(
            id = 1L,
            patchNumber = 1,
            name = "Live Percussion",
            pads = PadAssignment.defaultPads(),
        )
        var isEditMode = false

        composeTestRule.setContent {
            MyApplicationTheme {
                Row(modifier = Modifier.fillMaxSize()) {
                    OctapadPadGrid(
                        pads = samplePatch.pads,
                        pressedPads = emptySet(),
                        isEditMode = isEditMode,
                        selectedEditPadIndex = 0,
                        onPadPressed = { _, _ -> },
                        onPadReleased = {},
                        modifier = Modifier.weight(0.6f),
                    )
                    ControlPanel(
                        state = OctapadUiState(
                            patches = listOf(samplePatch),
                            filteredPatches = listOf(samplePatch),
                            activePatch = samplePatch,
                            workingDraftPatch = samplePatch,
                            activePanel = ActivePanel.PATCH_LIST,
                            isEditMode = false,
                        ),
                        onSelectPatch = {},
                        onPreviousPatch = {},
                        onSavePatch = {},
                        onNextPatch = {},
                        onOpenPanel = {},
                        onReturnToPatchList = {},
                        onSearchQueryChange = {},
                        onRenamePatch = { _, _ -> },
                        onRequestDeletePatch = {},
                        onConfirmDeletePatch = {},
                        onShowMyImportedPatches = {},
                        onPickWavSamples = {},
                        onPickMp3Samples = {},
                        onPickZipCollection = {},
                        onPickJsonFile = {},
                        onPickMcnFolder = {},
                        onPickSpd30Backup = {},
                        onCancelImport = {},
                        onDismissImportSummary = {},
                        onSelectEditPad = {},
                        onPickPadSample = {},
                        onPreviewPadSample = {},
                        onPadVolumeChange = {},
                        onPadPitchChange = {},
                        onPadMidiNoteChange = {},
                        onSaveEditedPad = {},
                        onDoneEditMode = {},
                        onEffectsChange = {},
                        onSaveEffects = {},
                        onResetEffects = {},
                        onRefreshMidi = {},
                        onSelectMidiInput = {},
                        onSelectMidiOutput = {},
                        onSetMidiChannel = {},
                        onToggleMidiInput = {},
                        onToggleMidiOutput = {},
                        onStartRecording = {},
                        onPauseRecording = {},
                        onResumeRecording = {},
                        onStopRecording = {},
                        onPlayCurrentTake = {},
                        onStopPlayback = {},
                        onLoopToggle = {},
                        onSaveTake = {},
                        onPlaySavedRecording = {},
                        onRenameRecording = { _, _ -> },
                        onToggleSavedLoop = {},
                        onDeleteRecording = {},
                        modifier = Modifier.weight(0.4f),
                    )
                }
            }
        }
        composeTestRule.waitForIdle()

        // Permanent patch list visible on startup
        composeTestRule.onNodeWithTag("lcd_patch_list").assertIsDisplayed()
        composeTestRule.onNodeWithTag("patch_row_1").assertIsDisplayed()

        // Exactly 4 main buttons, no EQ or QUALITY
        composeTestRule.onNodeWithTag("btn_patch_load").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_midi").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_edit").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_effects").assertIsDisplayed()
        assertEquals(0, composeTestRule.onAllNodesWithText("EQ").fetchSemanticsNodes().size)
        assertEquals(0, composeTestRule.onAllNodesWithText("QUALITY").fetchSemanticsNodes().size)

        // Icon-only nav row has NO Previous/Save/Next text
        composeTestRule.onNodeWithTag("btn_prev_patch").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_save_patch").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_next_patch").assertIsDisplayed()
        assertEquals(0, composeTestRule.onAllNodesWithText("Previous").fetchSemanticsNodes().size)
        assertEquals(0, composeTestRule.onAllNodesWithText("Save").fetchSemanticsNodes().size)
        assertEquals(0, composeTestRule.onAllNodesWithText("Next").fetchSemanticsNodes().size)

        // Play Mode: NO EDIT badges on any pad (only the main EDIT button itself exists)
        for (i in 1..8) {
            composeTestRule.onNodeWithTag("pad_edit_badge_$i").assertDoesNotExist()
        }
        assertEquals(1, composeTestRule.onAllNodesWithText("EDIT").fetchSemanticsNodes().size)
    }

    @Test
    fun `edit mode shows EDIT badge on all 8 pads and pad editor displays required controls`() {
        val samplePatch = OctapadPatch(
            id = 1L,
            patchNumber = 1,
            name = "Edit Kit",
            pads = PadAssignment.defaultPads(),
        )
        composeTestRule.setContent {
            MyApplicationTheme {
                Row(modifier = Modifier.fillMaxSize()) {
                    OctapadPadGrid(
                        pads = samplePatch.pads,
                        pressedPads = emptySet(),
                        isEditMode = true,
                        selectedEditPadIndex = 3,
                        onPadPressed = { _, _ -> },
                        onPadReleased = {},
                        modifier = Modifier.weight(0.6f),
                    )
                    ControlPanel(
                        state = OctapadUiState(
                            patches = listOf(samplePatch),
                            filteredPatches = listOf(samplePatch),
                            activePatch = samplePatch,
                            workingDraftPatch = samplePatch,
                            activePanel = ActivePanel.PAD_EDIT,
                            isEditMode = true,
                            selectedEditPadIndex = 3,
                        ),
                        onSelectPatch = {},
                        onPreviousPatch = {},
                        onSavePatch = {},
                        onNextPatch = {},
                        onOpenPanel = {},
                        onReturnToPatchList = {},
                        onSearchQueryChange = {},
                        onRenamePatch = { _, _ -> },
                        onRequestDeletePatch = {},
                        onConfirmDeletePatch = {},
                        onShowMyImportedPatches = {},
                        onPickWavSamples = {},
                        onPickMp3Samples = {},
                        onPickZipCollection = {},
                        onPickJsonFile = {},
                        onPickMcnFolder = {},
                        onPickSpd30Backup = {},
                        onCancelImport = {},
                        onDismissImportSummary = {},
                        onSelectEditPad = {},
                        onPickPadSample = {},
                        onPreviewPadSample = {},
                        onPadVolumeChange = {},
                        onPadPitchChange = {},
                        onPadMidiNoteChange = {},
                        onSaveEditedPad = {},
                        onDoneEditMode = {},
                        onEffectsChange = {},
                        onSaveEffects = {},
                        onResetEffects = {},
                        onRefreshMidi = {},
                        onSelectMidiInput = {},
                        onSelectMidiOutput = {},
                        onSetMidiChannel = {},
                        onToggleMidiInput = {},
                        onToggleMidiOutput = {},
                        onStartRecording = {},
                        onPauseRecording = {},
                        onResumeRecording = {},
                        onStopRecording = {},
                        onPlayCurrentTake = {},
                        onStopPlayback = {},
                        onLoopToggle = {},
                        onSaveTake = {},
                        onPlaySavedRecording = {},
                        onRenameRecording = { _, _ -> },
                        onToggleSavedLoop = {},
                        onDeleteRecording = {},
                        modifier = androidx.compose.ui.Modifier.weight(0.4f),
                    )
                }
            }
        }
        composeTestRule.waitForIdle()

        for (i in 1..8) {
            composeTestRule.onNodeWithTag("drum_pad_$i").assertIsDisplayed()
            composeTestRule.onNodeWithTag("pad_edit_badge_$i").assertIsDisplayed()
        }
        composeTestRule.onNodeWithTag("lcd_pad_edit_panel").assertIsDisplayed()
        composeTestRule.onNodeWithText("PAD 4 EDITOR").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_add_sample").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_change_sample").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_preview_sample").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_edit_save").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_edit_done").assertIsDisplayed()
    }
}
